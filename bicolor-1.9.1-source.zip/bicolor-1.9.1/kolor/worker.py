"""Resident process: cancellation kills computation and releases Metal memory."""
import json
import sys
import traceback
from .engine import Engine
from .runtime import configure
from .batch import run_batch
from .memory_guard import MemoryGuard

def emit(event):
    print('KOLOR:'+json.dumps(event,ensure_ascii=False),flush=True)

def main():
    configure()
    engine=Engine(emit)
    try:
        for line in sys.stdin:
            try:
                request=json.loads(line)
                action=request.pop('action')
                # An acknowledgement is a control message, not a render job.
                # It must not start memory sampling or emit a busy/done event.
                if action=='release_previews':
                    engine.release_previews(request.get('tokens',[]));continue
                with MemoryGuard(emit):
                    if action=='colorize':engine.colorize(**request)
                    elif action=='save_positive':engine.save_positive(**request)
                    elif action=='render':engine.render(**request)
                    elif action=='batch':
                        def batch_emit(e):
                            emit({**e,'type':'batch_file_done' if e['type']=='done' else e['type']})
                        engine.emit=batch_emit
                        try:
                            result=run_batch(engine,emit=emit,**request)
                            emit({'type':'batch_done','completed':len(result['completed']),'errors':result['errors']})
                        finally:engine.emit=emit
                    else:raise ValueError('Neznámý příkaz.')
            except Exception as exc:
                traceback.print_exc(file=sys.stderr)
                emit({'type':'error','message':str(exc)})
    finally:
        engine.close_preview_buffers()

if __name__=='__main__':main()
