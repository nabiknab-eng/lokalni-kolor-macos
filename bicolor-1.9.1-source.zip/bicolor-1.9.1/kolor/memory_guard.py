"""Stop only the disposable worker under sustained memory pressure."""
import os
import threading
import psutil


class MemoryGuard:
    def __init__(self,emit):
        self.emit=emit;self.stop=threading.Event();self.thread=None
        self.baseline_swap=psutil.swap_memory().used
    def __enter__(self):
        def sample():
            count=0
            while not self.stop.wait(.25):
                pressure=(psutil.virtual_memory().available<600*1024**2 or
                    psutil.swap_memory().used-self.baseline_swap>768*1024**2)
                count=count+1 if pressure else 0
                if count>=4:
                    self.emit({'type':'error','code':'memory_limit','message':
                        'Výpočet byl zastaven kvůli nedostatku paměti. Zavřete nepotřebné aplikace nebo zvolte menší návrh. Hotové soubory zůstávají zachované.'})
                    os._exit(86)
        self.thread=threading.Thread(target=sample,daemon=True);self.thread.start();return self
    def __exit__(self,*args):
        self.stop.set()
        if self.thread:self.thread.join(timeout=1)
