import re
from pathlib import Path
from .photos import EXTENSIONS
GENERATED = re.compile(r'_(?:(?:kolor|upraveno)(?:_v\d+)?(?:_\d+)?|pozitiv(?:_\d+)?|film_.+|flux_seed\d+(?:_\d+)?|nahled_(?:(?:film|upravy)_)?v\d+(?:_\d+)?)$')

def input_files(directory):
    return sorted((p for p in Path(directory).iterdir() if p.is_file() and p.suffix.lower() in EXTENSIONS
        and not GENERATED.search(p.stem)),key=lambda p:p.name.casefold())

def run_batch(engine,input_dir,output_dir,cancel=None,emit=None,**options):
    files=input_files(input_dir)
    if not files: raise ValueError('Složka neobsahuje žádné vstupní fotografie.')
    # Batch export is always clean colorization at the base saturation; local
    # brightness/contrast/temperature controls apply only to an individual image.
    options={**options,'saturation':1.,'adjustments':None,'save_all':True,'final_only':True}
    result={'completed':[],'errors':[]}
    for index,path in enumerate(files):
        if cancel and cancel(): raise InterruptedError('Dávka zrušena.')
        if emit: emit({'type':'batch_progress','index':index,'total':len(files),'file':str(path)})
        try:
            report=engine.colorize(source=path,output_dir=output_dir,**options)
            result['completed'].append(report)
        except (InterruptedError,KeyboardInterrupt): raise
        except Exception as exc:
            result['errors'].append({'source':str(path),'message':str(exc)})
            if emit: emit({'type':'batch_error','source':str(path),'message':str(exc)})
    return result
