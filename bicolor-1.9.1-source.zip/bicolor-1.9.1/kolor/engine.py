"""Verified MFLUX 0.23.0 API; native Qwen3 encoder, resident 4bit weights."""
import gc
import json
import os
from pathlib import Path
import tempfile
import threading
import time
import uuid
import cv2
import numpy as np
import psutil
from PIL import Image
from .runtime import configure, ROOT, MODEL_PATH, MODEL_REPO, MODEL_REVISION, DEFAULT_PROMPT, RESOLUTIONS
from .color import rgb_to_lab, gamut_rgb, prepare_colors, render_colors
from .photos import load_photo, save_photo
from .package_info import package_version
from .profiles import export_profile
from .seeds import DEFAULT_SEEDS,validate_seeds
from .negative import prepare_input
from .adjustments import DEFAULT_ADJUSTMENTS,validate_adjustments,apply_adjustments
from .view_render import render_view,validate_view_spec
from .preview_transport import PreviewBufferStore,memory_path


class RSSMonitor:
    def __enter__(self):
        self.peak = psutil.Process().memory_info().rss
        self.stop = threading.Event()
        def sample():
            while not self.stop.wait(.05):
                self.peak = max(self.peak,psutil.Process().memory_info().rss)
        self.thread = threading.Thread(target=sample,daemon=True); self.thread.start()
        return self
    def __exit__(self,*args):
        self.peak = max(self.peak,psutil.Process().memory_info().rss)
        self.stop.set(); self.thread.join()


class Engine:
    def __init__(self, emit=None):
        configure()
        self.emit = emit or (lambda event: None)
        self.model = None
        self.preview_maps = []
        self.original = None
        self.source = None
        self.load_stats = {}
        self._base_cache=None
        self._preview_buffers=None

    def load(self):
        if self.model is not None: return
        if not (MODEL_PATH/'REVISION.json').exists():
            raise FileNotFoundError('Model není kompletní. Spusťte Instalovat.command pro stažení a ověření vah.')
        self.emit({'type':'progress','fraction':0.,'text':'Načítám 4bitový FLUX.2 Klein do Metal GPU…'})
        started = time.perf_counter()
        import mlx.core as mx
        if not mx.metal.is_available():
            raise RuntimeError('Metal GPU není dostupné. Spusťte aplikaci přímo na Apple Silicon Macu.')
        mx.set_default_device(mx.gpu)
        mx.set_cache_limit(256*1024**2)
        mx.set_memory_limit(9*1024**3)
        from mflux.models.common.config import ModelConfig
        from mflux.models.flux2.variants import Flux2KleinEdit
        from mflux.callbacks.instances.memory_saver import MemorySaver
        with RSSMonitor() as monitor:
            class ResidentEdit(Flux2KleinEdit):
                def _encode_prompt_pair(self, **kwargs):
                    key=(kwargs['prompt'],kwargs.get('negative_prompt'),kwargs['guidance'])
                    if getattr(self,'_encoded_key',None)==key:
                        return self._encoded_pair
                    pair=super()._encode_prompt_pair(**kwargs)
                    mx.eval([value for value in pair if value is not None])
                    self._encoded_key=key; self._encoded_pair=pair
                    self.text_encoder=None
                    gc.collect(); mx.clear_cache()
                    return pair
            candidate = ResidentEdit(model_config=ModelConfig.flux2_klein_4b(),
                                       model_path=str(MODEL_PATH), quantize=4)
            candidate.callbacks.register(MemorySaver(model=candidate,keep_transformer=True,
                keep_text_encoder=True,num_seeds=3,cache_limit_bytes=256*1024**2))
            # Explicitly evaluate lazy loaded weights before timing inference.
            mx.eval(candidate.parameters())
        mlx_version, mlx_version_source = package_version('mlx')
        mflux_version, mflux_version_source = package_version('mflux')
        stats = {'load_seconds':time.perf_counter()-started,
            'load_peak_rss_bytes':monitor.peak,'device':str(mx.default_device()),
            'metal_available':mx.metal.is_available(),'metal_device':dict(mx.device_info()),
            'mlx_version':mlx_version,'mlx_version_source':mlx_version_source,
            'mflux_version':mflux_version,'mflux_version_source':mflux_version_source,
            'model_repo':MODEL_REPO,'model_revision':MODEL_REVISION,'quantization_bits':candidate.bits,'prompt_cache_low_ram':True,'mflux_commit':'a3b21fcaa88726b2267bd42bfc2e2d722f7d5a47'}
        # Publish ready state only after initialization and diagnostics finish.
        self.load_stats = stats
        self.model = candidate
        self.emit({'type':'loaded',**self.load_stats})

    def colorize(self, source, output_dir, resolution=512, seeds=DEFAULT_SEEDS, prompt=DEFAULT_PROMPT,
                 saturation=1., extension='.png', save_all=True, color_space='srgb',negative=False,
                 adjustments=None,final_only=False,preview_spec=None,preview_transport=None):
        self._validate_preview_transport(preview_transport)
        if resolution not in RESOLUTIONS: raise ValueError('Rozlišení musí být 512, 768 nebo 1024.')
        export_profile(color_space)
        if not prompt.strip(): raise ValueError('Prompt nesmí být prázdný.')
        seeds=validate_seeds(seeds)
        settings=validate_adjustments(**adjustments) if adjustments is not None else None
        if settings is not None:saturation=1.
        self.close_preview_buffers()
        self._base_cache=None;self.input_negative=negative
        self.original = prepare_input(load_photo(source),negative); self.source = str(Path(source).resolve())
        self.preview_maps = []
        output_dir = Path(output_dir); output_dir.mkdir(parents=True,exist_ok=True)
        # A batch target contains only the selected final variants. GUI previews
        # and diagnostics stay in the application's private runtime folder.
        artifact_dir=ROOT/'runtime'/'sessions'/uuid.uuid4().hex if final_only else output_dir
        artifact_dir.mkdir(parents=True,exist_ok=True)
        if self.model is not None and self.model.text_encoder is None:
            if getattr(self.model,'_encoded_key',(None,))[0]!=prompt:
                # A changed prompt needs the native encoder again. Reinitialize
                # only in this case, never between photos sharing the prompt.
                self.model=None
                gc.collect()
                import mlx.core as mx
                mx.clear_cache()
        self.load()
        import mlx.core as mx
        h,w = self.original.shape[:2]
        interactive_spec=validate_view_spec((w,h),preview_spec) if not save_all else None
        scale = min(resolution/w,resolution/h)
        rw,rh = max(16,round(w*scale)),max(16,round(h*scale))
        pw,ph = ((rw+15)//16)*16,((rh+15)//16)*16
        small = cv2.resize(self.original,(rw,rh),interpolation=cv2.INTER_AREA if scale<1 else cv2.INTER_LINEAR)
        neutral,_ = gamut_rgb(rgb_to_lab(small)[...,0],np.zeros_like(small[...,:2]))
        reference = np.pad(neutral,((0,ph-rh),(0,pw-rw),(0,0)),mode='edge')
        results = []
        with tempfile.TemporaryDirectory(prefix='reference-',dir=ROOT/'runtime') as temp:
            ref = Path(temp)/'reference.png'
            Image.fromarray(np.rint(reference*255).astype(np.uint8)).save(ref)
            for index,seed in enumerate(seeds):
                self.emit({'type':'progress','fraction':index/len(seeds),
                    'text':f'Barevný návrh {index+1}/{len(seeds)}, seed {seed}…'})
                mx.clear_cache(); mx.reset_peak_memory(); gc.collect()
                started = time.perf_counter()
                engine = self
                class Progress:
                    def call_in_loop(self, t, **kwargs):
                        engine.emit({'type':'progress','fraction':(index+.1+.7*(int(t)+1)/4)/len(seeds),
                            'text':f'Varianta {index+1}/{len(seeds)} · krok {int(t)+1}/4'})
                callback = Progress(); self.model.callbacks.register(callback)
                try:
                    with RSSMonitor() as monitor:
                        generated = self.model.generate_image(seed=seed,prompt=prompt,num_inference_steps=4,
                            width=pw,height=ph,guidance=1.,image_paths=[str(ref)])
                        mx.synchronize()
                    generation_seconds = time.perf_counter()-started
                    peak = mx.get_peak_memory()
                finally:
                    self.model.callbacks.in_loop.remove(callback)
                proposal = np.asarray(generated.image.convert('RGB'),dtype=np.float32)[:rh,:rw]/255
                raw_path = None if final_only else save_photo(proposal,source,artifact_dir,'.png',f'_flux_seed{seed}')
                color_map = prepare_colors(self.original,proposal)
                self.preview_maps.append(color_map)
                self.emit({'type':'progress','fraction':(index+.85)/len(seeds),'text':
                    'Přenáším pouze barvy v původním rozlišení…' if save_all else 'Připravuji rychlý barevný náhled…'})
                final_started = time.perf_counter()
                preview_buffers=None
                if save_all:
                    # The export/batch path remains the original exact full render.
                    base, metrics = render_colors(self.original,color_map,saturation)
                    self._base_cache=((index,float(saturation)),base,metrics)
                    final=apply_adjustments(base,settings)
                    final_path = save_photo(final,source,output_dir,extension,
                        ('_upraveno' if settings is not None else '_kolor')+(f'_v{index+1}' if index else ''),color_space=color_space)
                    size = (min(1400,w),max(1,round(h*min(1400,w)/w)))
                    preview = cv2.resize(base,size,interpolation=cv2.INTER_AREA)
                    preview_path = save_photo(preview,source,artifact_dir,'.png',f'_nahled_v{index+1}')
                    adjusted_preview_path=None
                    if settings is not None:
                        adjusted_preview_path=save_photo(cv2.resize(final,size,interpolation=cv2.INTER_AREA),source,artifact_dir,'.png',f'_nahled_upravy_v{index+1}')
                else:
                    # Interactive generation need not transfer colors onto every
                    # source pixel before showing the first display-sized result.
                    base,metrics=render_view(self.original,color_map,saturation,**interactive_spec)
                    final=apply_adjustments(base,settings);final_path=None
                    memory=self._memory_previews(base,final if settings is not None and settings!=DEFAULT_ADJUSTMENTS else None) if preview_transport=='memory' else None
                    if memory is not None:
                        preview_path,adjusted_path,preview_buffers=memory
                        adjusted_preview_path=adjusted_path if settings is not None else None
                    else:
                        preview_path=self._save_preview_unique(base,artifact_dir,Path(source).stem+f'_nahled_v{index+1}')
                        adjusted_preview_path=None
                        if settings is not None:
                            adjusted_preview_path=preview_path if settings==DEFAULT_ADJUSTMENTS else self._save_preview_unique(
                                final,artifact_dir,Path(source).stem+f'_nahled_upravy_v{index+1}')
                stats = {'seed':seed,'resolution':resolution,'inference_width':pw,'inference_height':ph,
                    'generation_seconds':generation_seconds,'transfer_seconds':time.perf_counter()-final_started,
                    'mlx_peak_bytes':peak,'rss_peak_bytes':monitor.peak,'output_color_space':color_space,
                    'input_negative':negative,**metrics,**color_map.diagnostics,'adjustments':settings}
                entry = {'variant':index,'raw':str(raw_path) if raw_path else None,'final':str(final_path) if final_path else None,
                         'preview':str(preview_path),'stats':stats,'saturation':saturation,'adjustments':settings,
                         'adjusted_preview':str(adjusted_preview_path) if adjusted_preview_path else None,
                         'source_size':[w,h]}
                if interactive_spec is not None:entry['preview_spec']=interactive_spec
                if preview_buffers is not None:entry['preview_buffers']=preview_buffers
                results.append(entry)
                self.emit({'type':'variant',**entry})
                del generated,proposal,final
                mx.clear_cache()
        report = {'source':self.source,'prompt':prompt,'saturation':saturation,'output_color_space':color_space,
            'seeds':seeds,'variant_count':len(seeds),'input_negative':negative,'adjustments':settings,
            'load':self.load_stats,'variants':results,'offline':True}
        self._save_json_unique(artifact_dir,Path(source).stem+'_mereni',report)
        self.emit({'type':'done','results':results})
        return report

    def _base(self,variant,saturation):
        if not 0 <= variant < len(self.preview_maps):raise ValueError('Varianta není připravena.')
        key=(variant,float(saturation))
        if self._base_cache is None or self._base_cache[0]!=key:
            rgb,stats=render_colors(self.original,self.preview_maps[variant],saturation)
            self._base_cache=(key,rgb,stats)
        return self._base_cache[1:]

    def render(self, variant, saturation, output_dir, extension='.png', preview_only=False, color_space='srgb',
               full_resolution=False,adjustments=None,preview_spec=None,preview_transport=None):
        self._validate_preview_transport(preview_transport)
        settings=validate_adjustments(**adjustments) if adjustments is not None else None
        # The adjustments tab always compares against the variant at exactly 100%.
        reference_saturation=1. if settings is not None else saturation
        if preview_only and preview_spec is not None:
            return self._render_view_preview(variant,reference_saturation,settings,preview_spec,preview_transport)
        base,stats=self._base(variant,reference_saturation)
        final=apply_adjustments(base,settings)
        if preview_only:
            h,w=base.shape[:2]
            if not full_resolution and max(h,w)>1400:
                scale=1400/max(h,w);size=(max(1,round(w*scale)),max(1,round(h*scale)))
                working=cv2.resize(base,size,interpolation=cv2.INTER_AREA)
                final=cv2.resize(final,size,interpolation=cv2.INTER_AREA)
            else:working=base
            tag='reference_' if settings is not None or reference_saturation==1. else ''
            base_path=ROOT/'runtime'/f'preview_{tag}v{variant}{"_full" if full_resolution else ""}.png'
            memory=self._memory_previews(working,final if settings is not None and settings!=DEFAULT_ADJUSTMENTS else None) if preview_transport=='memory' else None
            if memory is not None:base_path,path,preview_buffers=memory
            else:
                Image.fromarray(np.rint(working*255).astype(np.uint8)).save(base_path)
                path=base_path
                if settings is not None:
                    path=ROOT/'runtime'/f'preview_adjusted_v{variant}{"_full" if full_resolution else ""}.png'
                    Image.fromarray(np.rint(final*255).astype(np.uint8)).save(path)
        else:
            path=save_photo(final,self.source,output_dir,extension,
                suffix='_upraveno' if settings is not None else '_kolor',color_space=color_space)
        event={'type':'preview' if preview_only else 'saved','path':str(path),'stats':stats,
            'variant':variant,'saturation':reference_saturation,'adjustments':settings,
            'full_resolution':bool(preview_only and full_resolution),
            'output_color_space':'srgb' if preview_only else color_space}
        if preview_only:event['base_path']=str(base_path)
        if preview_only and memory is not None:event['preview_buffers']=preview_buffers
        self.emit(event);return event

    def _render_view_preview(self,variant,saturation,settings,spec,preview_transport=None):
        if not 0<=variant<len(self.preview_maps):raise ValueError('Varianta není připravena.')
        h,w=self.original.shape[:2];spec=validate_view_spec((w,h),spec)
        base,stats=render_view(self.original,self.preview_maps[variant],saturation,**spec)
        final=apply_adjustments(base,settings)
        tag='reference_' if settings is not None or saturation==1. else ''
        scope='fit' if spec['bounds'] is None else 'crop'
        directory=ROOT/'runtime';directory.mkdir(parents=True,exist_ok=True)
        base_path=directory/f'preview_view_{tag}v{variant}_{scope}.png'
        memory=self._memory_previews(base,final if settings is not None and settings!=DEFAULT_ADJUSTMENTS else None) if preview_transport=='memory' else None
        if memory is not None:base_path,path,preview_buffers=memory
        else:
            self._save_preview(base,base_path);path=base_path
            if settings is not None and settings!=DEFAULT_ADJUSTMENTS:
                path=directory/f'preview_view_adjusted_v{variant}_{scope}.png';self._save_preview(final,path)
        event={'type':'preview','path':str(path),'base_path':str(base_path),'stats':stats,
            'variant':variant,'saturation':saturation,'adjustments':settings,'full_resolution':False,
            'preview_spec':spec,'source_size':[w,h],'output_color_space':'srgb'}
        if memory is not None:event['preview_buffers']=preview_buffers
        self.emit(event);return event

    @staticmethod
    def _validate_preview_transport(value):
        if value not in (None,'memory'):raise ValueError('Neznámý přenos pracovního náhledu.')

    def _memory_previews(self,base,adjusted=None):
        if self._preview_buffers is None:
            self._preview_buffers=PreviewBufferStore(ROOT/'runtime'/'preview-buffers')
        buffers=[]
        try:
            buffers.append(self._preview_buffers.publish(base))
            if adjusted is not None:buffers.append(self._preview_buffers.publish(adjusted))
        except (OSError,BufferError):
            # Keep the disk preview available if a buffer budget or platform
            # restriction prevents mapping. Never publish a half-created pair.
            self._preview_buffers.release([item['token'] for item in buffers])
            return None
        return memory_path(buffers[0]),memory_path(buffers[-1]),buffers

    def release_previews(self,tokens):
        if self._preview_buffers is not None:self._preview_buffers.release(tokens)

    def close_preview_buffers(self):
        if self._preview_buffers is not None:
            self._preview_buffers.close();self._preview_buffers=None

    @staticmethod
    def _save_preview(rgb,path):
        Image.fromarray(np.rint(np.clip(rgb,0,1)*255).astype(np.uint8)).save(path,format='PNG')

    @staticmethod
    def _save_preview_unique(rgb,directory,stem):
        for index in range(100000):
            path=Path(directory)/(stem+(f'_{index+1}' if index else '')+'.png')
            try:
                with path.open('xb') as stream:Engine._save_preview(rgb,stream)
                return path
            except FileExistsError:continue
        raise OSError('Nepodařilo se najít volný název pracovního náhledu.')

    def save_positive(self,source,output_dir,extension='.png',color_space='srgb'):
        positive=prepare_input(load_photo(source),True)
        path=save_photo(positive,source,output_dir,extension,suffix='_pozitiv',color_space=color_space)
        self.emit({'type':'saved','path':str(path),'positive_only':True});return path

    @staticmethod
    def _save_json_unique(directory,stem,value):
        for i in range(100000):
            target = directory/(stem+(f'_{i+1}' if i else '')+'.json')
            try:
                with target.open('x') as out: json.dump(value,out,ensure_ascii=False,indent=2)
                return target
            except FileExistsError: continue
