"""Native Qt macOS UI. MLX runs only in a resident child process."""
import json
import math
from pathlib import Path
import sys
import time
import uuid
import numpy as np
from PIL import Image,ImageOps,ImageCms
import io
from PySide6.QtCore import Qt,QProcess,QTimer,QRect,QUrl,QPointF,Signal,QSettings,QSize
from PySide6.QtGui import QImage,QPainter,QColor,QPen,QDesktopServices,QAction,QIcon,QTextOption
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,
    QLabel,QPushButton,QComboBox,QLineEdit,QPlainTextEdit,QSlider,QProgressBar,QFileDialog,
    QMessageBox,QScrollArea,QTabBar,QFrame,QSpinBox,QGroupBox,QDialog,QSizePolicy,QGridLayout,QStyleFactory,QStyleOptionSlider,QStyle)
from .runtime import ROOT,DEFAULT_PROMPT,configure,RESOLUTIONS
from . import __version__
from .photos import EXTENSIONS,validate_input_image
from .seeds import DEFAULT_SEEDS,MAX_VARIANTS,parse_seeds,resize_seeds
from .adjustments import DEFAULT_ADJUSTMENTS,validate_adjustments
from .preview import FastPreview
from .batch_dialog import BatchDialog
from .image_cache import PreviewImageCache
from .preview_transport import read_preview_buffer,memory_path,cleanup_preview_buffers


def image_preview(path,max_size=1600):
    # Fit view uses thumbnails; zoom reads every source pixel. Export stays in the worker.
    with Image.open(path) as source:
        validate_input_image(source)
        if max_size:source.draft('RGB',(max_size,max_size))
        im=ImageOps.exif_transpose(source)
        icc=source.info.get('icc_profile')
        if max_size:im.thumbnail((max_size,max_size),Image.Resampling.LANCZOS)
        if im.mode.startswith('I'):
            im=Image.fromarray(np.rint(np.clip(np.asarray(im,dtype=np.float32)/65535,0,1)*255).astype(np.uint8))
        if icc:
            try:
                source_profile=ImageCms.ImageCmsProfile(io.BytesIO(icc))
                # The decoder can expose gray HEIC as RGB, or opaque alpha as
                # RGBA/LA. Match the profile's channels before CMS conversion.
                if source_profile.profile.xcolor_space.strip()=='GRAY':im=im.convert('L')
                elif im.mode not in {'RGB','CMYK','L'}:im=im.convert('RGB')
                im=ImageCms.profileToProfile(im,source_profile,ImageCms.createProfile('sRGB'),outputMode='RGB',renderingIntent=1)
            except Exception:im=im.convert('RGB')
        else:im=im.convert('RGB')
        arr=np.ascontiguousarray(im,dtype=np.uint8)
    return QImage(arr.data,arr.shape[1],arr.shape[0],arr.strides[0],QImage.Format.Format_RGB888).copy()


class FileNameLabel(QLabel):
    """A filename may be arbitrarily long without widening the control panel."""
    def __init__(self,text):
        super().__init__(text)
        self.setSizePolicy(QSizePolicy.Policy.Ignored,QSizePolicy.Policy.Fixed)
        self.setMinimumWidth(0);self.setFixedHeight(22);self.setToolTip(text)

    def setText(self,text):
        super().setText(text);self.setToolTip(text)

    def minimumSizeHint(self):return QSize(0,22)

    def paintEvent(self,event):
        painter=QPainter(self);painter.setPen(self.palette().color(self.foregroundRole()))
        text=self.fontMetrics().elidedText(self.text(),Qt.TextElideMode.ElideMiddle,self.contentsRect().width())
        painter.drawText(self.contentsRect(),Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter,text)


class ControlSlider(QSlider):
    """Paint a slim track; Qt still handles hit testing, keyboard input and values."""
    def paintEvent(self,event):
        option=QStyleOptionSlider();self.initStyleOption(option)
        handle=self.style().subControlRect(QStyle.ComplexControl.CC_Slider,option,QStyle.SubControl.SC_SliderHandle,self)
        inset=handle.width()/2;left,right=inset,self.width()-inset;y=self.height()/2
        x=handle.center().x();start=right if option.upsideDown else left
        painter=QPainter(self);painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(QPen(QColor('#465261'),4,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap))
        painter.drawLine(QPointF(left,y),QPointF(right,y))
        painter.setPen(QPen(QColor('#3d9cef' if self.isEnabled() else '#65778a'),4,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap))
        painter.drawLine(QPointF(start,y),QPointF(x,y))
        painter.setPen(QPen(QColor('#9acfff' if self.hasFocus() else '#5eaeef'),2 if self.hasFocus() else 1))
        painter.setBrush(QColor('#cce6ff' if self.isEnabled() else '#7d8995'));painter.drawEllipse(QPointF(x,y),6,6)


class CompareCanvas(QWidget):
    zoomRequested=Signal(object)
    viewChanged=Signal()
    ZOOM_STEPS=(.125,.25,.5,1.,2.,4.,8.)

    def __init__(self):
        super().__init__(); self.before=None; self.after=None; self.after_crop=None; self.overlay=False; self.position=.5
        self.before_bounds=None;self.after_bounds=None;self.before_fallback=None;self.after_fallback=None
        self.zoom=None;self.pan=QPointF();self.source_size=None;self.before_label="Originál";self.after_label="Kolorováno"
        self.drag_start=None;self.drag_pan=QPointF();self.drag_wipe=False
        self.empty_message="Přetáhněte sem fotografii\nnebo ji otevřete tlačítkem vlevo."
        self.setMinimumSize(400,320)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def image_area(self,index=0):
        if self.overlay:return self.rect().adjusted(16,40,-16,-16)
        half=self.width()//2
        return QRect(index*half+12,40,half-24,self.height()-56)

    def image_rect(self,image,area):
        w,h=self.source_size or (image.width(),image.height())
        scale=min(area.width()/w,area.height()/h) if self.zoom is None else self.zoom/self.devicePixelRatioF()
        width,height=max(1,round(w*scale)),max(1,round(h*scale))
        mx,my=max(0,(width-area.width())/2),max(0,(height-area.height())/2)
        dx,dy=np.clip(self.pan.x(),-mx,mx),np.clip(self.pan.y(),-my,my)
        return QRect(round(area.center().x()-width/2+dx),round(area.center().y()-height/2+dy),width,height)

    def current_zoom(self):
        if self.zoom is not None:return self.zoom
        if self.before is None:return 1.
        w,h=self.source_size or (self.before.width(),self.before.height())
        area=self.image_area()
        return min(area.width()/w,area.height()/h)*self.devicePixelRatioF()

    def next_zoom(self,direction):
        current=self.current_zoom()
        if direction>0:return next((v for v in self.ZOOM_STEPS if v>current+1e-6),self.ZOOM_STEPS[-1])
        return next((v for v in reversed(self.ZOOM_STEPS) if v<current-1e-6),self.ZOOM_STEPS[0])

    def set_zoom(self,value):
        if value is not None and not .125<=float(value)<=8:
            raise ValueError('Zoom musí být 12,5–800 %.')
        old=self.current_zoom()
        self.zoom=None if value is None else float(value)
        self.pan=QPointF() if value is None else self.pan*(float(value)/max(old,1e-6))
        self.clamp_pan()
        self.setCursor(Qt.CursorShape.ArrowCursor if value is None else Qt.CursorShape.OpenHandCursor)
        self.update()

    def clamp_pan(self):
        if self.before is None or self.zoom is None:self.pan=QPointF();return
        area=self.image_area();w,h=self.source_size or (self.before.width(),self.before.height())
        scale=self.zoom/self.devicePixelRatioF()
        mx,my=max(0,(round(w*scale)-area.width())/2),max(0,(round(h*scale)-area.height())/2)
        self.pan=QPointF(float(np.clip(self.pan.x(),-mx,mx)),float(np.clip(self.pan.y(),-my,my)))

    def resizeEvent(self,event):
        self.clamp_pan();super().resizeEvent(event);self.viewChanged.emit()

    def bounds_rect(self,rect,bounds):
        if bounds is None or self.source_size is None:return rect
        x0,y0,x1,y1=bounds;w,h=self.source_size
        left=rect.x()+round(x0*rect.width()/w);top=rect.y()+round(y0*rect.height()/h)
        return QRect(left,top,rect.x()+round(x1*rect.width()/w)-left,
            rect.y()+round(y1*rect.height()/h)-top)

    def draw_view(self,painter,rect,image,bounds=None,fallback=None):
        if fallback is not None:painter.drawImage(rect,fallback)
        painter.drawImage(self.bounds_rect(rect,bounds),image)

    def paintEvent(self,event):
        painter=QPainter(self); painter.fillRect(self.rect(),QColor('#1c2125'))
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        if self.before is None:
            painter.setPen(QColor('#c4cbd0'))
            painter.drawText(self.rect(),Qt.AlignmentFlag.AlignCenter,self.empty_message)
            return
        if self.overlay:
            area=self.image_area();rect=self.image_rect(self.before,area)
            x=area.left()+round(area.width()*self.position)
            painter.save();painter.setClipRect(area);painter.drawImage(rect,self.before)
            painter.setClipRect(QRect(x,area.top(),area.right()-x+1,area.height()))
            painter.drawImage(rect,self.after if self.after is not None else self.before);painter.restore()
            painter.setPen(QPen(QColor('#ffffff'),2));painter.drawLine(x,area.top(),x,area.bottom())
            painter.setBrush(QColor('white'));painter.drawEllipse(x-10,area.center().y()-10,20,20)
            painter.setPen(QColor('#dce1e4'))
            painter.drawText(20,26,self.before_label); painter.drawText(self.width()-180,26,self.after_label)
        else:
            half=self.width()//2
            for i,(image,label) in enumerate([(self.before,self.before_label),(self.after,self.after_label)]):
                area=self.image_area(i)
                painter.setPen(QColor('#dce1e4')); painter.drawText(i*half+20,26,label)
                if image is not None:
                    painter.save();painter.setClipRect(area)
                    rect=self.image_rect(image,area)
                    if i==1 and self.after_crop is not None and self.before is not None:
                        self.draw_view(painter,rect,self.before,self.before_bounds,self.before_fallback)
                        rect=self.bounds_rect(rect,self.before_bounds)
                        x0,y0,x1,y1=self.after_crop;w,h=self.before.width(),self.before.height()
                        target=QRect(rect.x()+round(x0*rect.width()/w),rect.y()+round(y0*rect.height()/h),
                            round(x1*rect.width()/w)-round(x0*rect.width()/w),round(y1*rect.height()/h)-round(y0*rect.height()/h))
                        painter.drawImage(target,image)
                    else:self.draw_view(painter,rect,image,
                        self.before_bounds if i==0 else self.after_bounds,
                        self.before_fallback if i==0 else self.after_fallback)
                    painter.restore()
                else:
                    painter.setPen(QColor('#84929b'))
                    painter.drawText(area,Qt.AlignmentFlag.AlignCenter,'Vytvořte barevné varianty.')
    def mousePressEvent(self,event):
        if event.button()!=Qt.MouseButton.LeftButton:return
        self.setFocus();self.drag_start=event.position();self.drag_pan=QPointF(self.pan)
        area=self.image_area();x=area.left()+area.width()*self.position
        self.drag_wipe=self.overlay and (self.zoom is None or abs(event.position().x()-x)<14)
        if self.zoom is not None and not self.drag_wipe:self.setCursor(Qt.CursorShape.ClosedHandCursor)
        self.mouseMoveEvent(event)
    def mouseMoveEvent(self,event):
        if self.drag_start is None or not event.buttons()&Qt.MouseButton.LeftButton:return
        if self.drag_wipe:
            area=self.image_area();self.position=max(0,min(1,(event.position().x()-area.left())/area.width()))
        elif self.zoom is not None:
            self.pan=self.drag_pan+event.position()-self.drag_start;self.clamp_pan()
            self.drag_pan=QPointF(self.pan);self.drag_start=event.position();self.viewChanged.emit()
        self.update()

    def mouseReleaseEvent(self,event):
        self.drag_start=None
        self.setCursor(Qt.CursorShape.OpenHandCursor if self.zoom is not None else Qt.CursorShape.ArrowCursor)

    def mouseDoubleClickEvent(self,event):
        self.zoomRequested.emit(1. if self.zoom is None else None)

    def wheelEvent(self,event):
        if self.before is None:return
        pixels=event.pixelDelta()
        if not pixels.isNull() and not event.modifiers()&(Qt.KeyboardModifier.ControlModifier|Qt.KeyboardModifier.MetaModifier):
            if self.zoom is not None:self.pan+=QPointF(pixels);self.clamp_pan();self.update();self.viewChanged.emit()
        else:
            delta=event.angleDelta().y() or pixels.y()
            if delta:self.zoomRequested.emit(self.next_zoom(1 if delta>0 else -1))
        event.accept()


class Window(QMainWindow):
    def __init__(self):
        super().__init__(); configure()
        self.setWindowTitle(f'bicolor {__version__}'); self.resize(1180,790); self.setMinimumSize(960,680)
        self.setWindowIcon(QIcon(str(ROOT/'bicolor.app/Contents/Resources/LokalniKolor-icon.png')))
        self.setAcceptDrops(True)
        self.settings=QSettings(str(ROOT/'runtime'/'bicolor.ini'),QSettings.Format.IniFormat)
        saved_directory=self.settings.value('photo/last_directory','',type=str)
        default_directory=Path.home()/'Pictures'
        self.last_photo_dir=Path(saved_directory) if saved_directory and Path(saved_directory).is_dir() else (default_directory if default_directory.is_dir() else Path.home())
        self.source=None; self.variants={}; self.selected=0; self.busy=False; self.batch_mode=False
        self._full_before=False;self._original_preview=None
        saved_output=self.settings.value('output/last_directory','',type=str)
        if saved_output and Path(saved_output).is_dir():self.result_dir=Path(saved_output)
        else:self.result_dir=ROOT/'vysledky';self.result_dir.mkdir(exist_ok=True)
        self.output_buffer=''; self.expected_stop=False; self.current_saturation=1.;self._worker_pid=0
        self.process=QProcess(self); self.process.setWorkingDirectory(str(ROOT))
        self.process.readyReadStandardOutput.connect(self.read_output)
        self.process.readyReadStandardError.connect(self.read_errors)
        self.process.finished.connect(self.worker_finished)
        self.process.errorOccurred.connect(self.process_error)
        self.debounce=QTimer(self); self.debounce.setSingleShot(True); self.debounce.setInterval(250)
        self.debounce.timeout.connect(self.update_saturation)
        self._image_cache=PreviewImageCache();self._local_preview=None;self._wanted_preview=None
        self.fast_preview=FastPreview(self);self.fast_preview.ready.connect(self.fast_preview_ready)
        self.fast_preview.failed.connect(lambda message:self.status.setText('Chyba náhledu: '+message))
        self.preview_timer=QTimer(self);self.preview_timer.setSingleShot(True);self.preview_timer.setInterval(25)
        self.preview_timer.timeout.connect(self.update_view_preview)
        # Use consistent handle geometry for the custom-painted horizontal sliders.
        self._slider_style=QStyleFactory.create('Fusion')
        self.build_ui()
        action=QAction('Otevřít fotografii…',self); action.setShortcut('Ctrl+O'); action.triggered.connect(self.choose_photo)
        self.menuBar().addMenu('Soubor').addAction(action)
        help_menu=self.menuBar().addMenu('Nápověda')
        guide=QAction('Český návod',self); guide.triggered.connect(lambda:QDesktopServices.openUrl(QUrl.fromLocalFile(str(ROOT/'NAVOD.md')))); help_menu.addAction(guide)
        outputs=QAction('Otevřít výsledky',self); outputs.triggered.connect(self.open_results); help_menu.addAction(outputs)

    def build_ui(self):
        central=QWidget();central.setObjectName('Workspace')
        main=QHBoxLayout(central);main.setContentsMargins(0,0,0,0);main.setSpacing(0);self.setCentralWidget(central)
        central.setStyleSheet("""
            QWidget#Workspace { background:#151a20; }
            QLabel, QGroupBox { color:#e3e9ef; }
            QLabel#SectionTitle { color:#aab8c5; font-size:11px; font-weight:600; }
            QLabel#FileName, QLabel#Note { color:#97a5b3; font-size:11px; }
            QWidget#Sidebar, QWidget#SidebarPanel, QScrollArea#SidebarScroll { background:#1b2027; }
            QWidget#SavePanel { background:#1b2027; border-top:1px solid #343e49; }
            QFrame#ControlCard { background:#232a33; border:1px solid #343e49; border-radius:10px; }
            QPushButton { color:#e3e9ef; background:#303a46; border:1px solid #455260;
                border-radius:6px; padding:6px 10px; min-height:18px; }
            QPushButton:hover { background:#3a4858; border-color:#68829c; }
            QPushButton:pressed { background:#26384a; }
            QPushButton:checked { color:#eff7ff; background:#205e95; border-color:#4cafff; }
            QPushButton:disabled { color:#84909e; background:#29313a; border-color:#35404c; }
            QPushButton#Primary { background:#167cdd; border-color:#3598f3; color:white; font-weight:600; }
            QPushButton#Primary:hover { background:#258aeb; }
            QPushButton#Primary:disabled { background:#294968; color:#9caebf; border-color:#36536f; }
            QComboBox, QLineEdit, QSpinBox, QPlainTextEdit { color:#edf2f7; background:#171d24;
                border:1px solid #475564; border-radius:5px; padding:5px 8px; selection-background-color:#226eb4; }
            QComboBox:focus, QLineEdit:focus, QSpinBox:focus, QPlainTextEdit:focus { border-color:#59aaff; }
            QComboBox:disabled, QLineEdit:disabled, QSpinBox:disabled, QPlainTextEdit:disabled { color:#83909d; border-color:#35404c; }
            QComboBox { min-height:20px; padding-right:26px; }
            QComboBox::drop-down { subcontrol-origin:padding; subcontrol-position:top right;
                width:22px; border:0; border-left:1px solid #394653; }
            QComboBox::down-arrow { image:url(ICON_DOWN); width:12px; height:8px; }
            QSpinBox { padding-right:20px; }
            QSpinBox::up-button { subcontrol-origin:border; subcontrol-position:top right;
                width:18px; height:15px; border-left:1px solid #394653; }
            QSpinBox::down-button { subcontrol-origin:border; subcontrol-position:bottom right;
                width:18px; height:15px; border-left:1px solid #394653; }
            QSpinBox::up-arrow { image:url(ICON_UP); width:8px; height:6px; }
            QSpinBox::down-arrow { image:url(ICON_DOWN); width:8px; height:6px; }
            QGroupBox { border:1px solid #435160; border-radius:7px; margin-top:12px; padding-top:10px; }
            QGroupBox::title { subcontrol-origin:margin; left:10px; padding:0 4px; }
            QSlider { background:transparent; border:0; min-height:20px; max-height:20px; }
            QTabBar::tab { color:#b6c2ce; background:#242c36; border:1px solid #3c4957;
                padding:8px 12px; min-height:18px; }
            QTabBar::tab:selected { color:#f1f7fc; background:#244767; border-bottom:2px solid #60b0ff; }
            QTabBar::tab:hover { background:#304052; }
            QScrollBar:vertical { width:10px; background:#1b2027; margin:5px 1px; }
            QScrollBar::handle:vertical { background:#526174; min-height:32px; border-radius:4px; }
            QScrollBar::handle:vertical:hover { background:#71869e; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0; }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background:none; }
            QProgressBar { background:#252e38; border:1px solid #3b4754; border-radius:4px; max-height:8px; }
            QProgressBar::chunk { background:#439fe9; border-radius:3px; }
        """.replace('ICON_DOWN',(ROOT/'assets/ui/chevron-down.svg').as_posix())
            .replace('ICON_UP',(ROOT/'assets/ui/chevron-up.svg').as_posix()))
        self.sidebar_panel=QWidget();self.sidebar_panel.setObjectName('SidebarPanel');self.sidebar_panel.setFixedWidth(360)
        sidebar_column=QVBoxLayout(self.sidebar_panel);sidebar_column.setContentsMargins(0,0,0,0);sidebar_column.setSpacing(0)
        scroll=QScrollArea();self.sidebar_scroll=scroll;scroll.setObjectName('SidebarScroll')
        scroll.setWidgetResizable(True);scroll.setFixedWidth(360);scroll.setFrameShape(QFrame.Shape.NoFrame)
        # A permanent vertical gutter keeps control widths stable when a tab becomes taller.
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        sidebar=QWidget();self.sidebar=sidebar;sidebar.setObjectName('Sidebar');sidebar.setMinimumWidth(0)
        sidebar.setSizePolicy(QSizePolicy.Policy.Ignored,QSizePolicy.Policy.Preferred)
        layout=QVBoxLayout(sidebar);layout.setContentsMargins(16,18,16,18);layout.setSpacing(12)
        title=QLabel('bicolor');title.setStyleSheet('font-size:26px;font-weight:600;color:#f0f5fa;');layout.addWidget(title)
        photo_buttons=QHBoxLayout();photo_buttons.setSpacing(6)
        self.open_button=QPushButton('Otevřít fotografii…');self.open_button.clicked.connect(self.choose_photo);photo_buttons.addWidget(self.open_button,1)
        self.batch_button=QPushButton('Dávkové zpracování…');self.batch_button.clicked.connect(self.choose_batch);photo_buttons.addWidget(self.batch_button,1)
        layout.addLayout(photo_buttons)
        self.file_label=FileNameLabel('JPEG, PNG, TIFF, HEIC, WebP, AVIF, BMP');self.file_label.setObjectName('FileName');layout.addWidget(self.file_label)
        self.build_adjustment_controls(layout)

        def card(title,target=None):
            frame=QFrame();frame.setObjectName('ControlCard')
            contents=QVBoxLayout(frame);contents.setContentsMargins(12,12,12,12);contents.setSpacing(8)
            heading=QLabel(title);heading.setObjectName('SectionTitle');contents.addWidget(heading)
            (layout if target is None else target).addWidget(frame);return contents

        controls=card('NASTAVENÍ KOLOROVÁNÍ')
        sample_row=QGridLayout();sample_row.setContentsMargins(0,0,0,0);sample_row.setHorizontalSpacing(10);sample_row.setVerticalSpacing(4)
        self.sample_label=QLabel('Barevný vzor');sample_row.addWidget(self.sample_label,0,1)
        self.negative_button=QPushButton('Negativ');self.negative_button.setCheckable(True)
        self.negative_button.setToolTip('Vratné převrácení černobílého negativu. Oranžovou masku barevného filmu neodstraňuje.')
        self.negative_button.toggled.connect(self.toggle_negative);self.negative_button.setFixedSize(104,32)
        self.resolution=QComboBox();self.resolution.addItems(['512 px','768 px','1024 px']);self.resolution.setFixedHeight(32)
        self.resolution.setMinimumWidth(0);self.resolution.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Fixed)
        sample_row.addWidget(self.negative_button,1,0);sample_row.addWidget(self.resolution,1,1);sample_row.setColumnStretch(1,1)
        controls.addLayout(sample_row)
        self.resolution.setToolTip('Velikost barevného vzoru AI, nejvýše 1024 px. Doporučeno 512 px. Výstup má plné rozlišení originálu.')
        seeds_row=QGridLayout();seeds_row.setContentsMargins(0,0,0,0);seeds_row.setHorizontalSpacing(10);seeds_row.setVerticalSpacing(4)
        seeds_row.addWidget(QLabel('Počet variant'),0,0);seeds_row.addWidget(QLabel('Seedy'),0,1)
        self.seed_count=QSpinBox();self.seed_count.setRange(1,MAX_VARIANTS);self.seed_count.setValue(len(DEFAULT_SEEDS));self.seed_count.setFixedSize(90,34)
        self.seed_count.setToolTip('Každý seed vytvoří jednu barevnou variantu. Více variant znamená delší výpočet.')
        self.seeds=QLineEdit(', '.join(map(str,DEFAULT_SEEDS)));self.seeds.setMinimumWidth(0);self.seeds.setFixedHeight(34)
        seeds_row.addWidget(self.seed_count,1,0);seeds_row.addWidget(self.seeds,1,1);seeds_row.setColumnStretch(1,1);controls.addLayout(seeds_row)
        self.seeds.setToolTip('Čísla lze upravit ručně. Při změně počtu se seznam automaticky doplní nebo zkrátí.')
        self.generate_button=QPushButton('Vytvořit 3 varianty');self.generate_button.setObjectName('Primary');self.generate_button.setDefault(True)
        self.generate_button.clicked.connect(self.generate);controls.addWidget(self.generate_button)
        self.saturation_label=QLabel('Sytost · 100 %');controls.addWidget(self.saturation_label)
        self.saturation=ControlSlider(Qt.Orientation.Horizontal);self.saturation.setStyle(self._slider_style);self.saturation.setRange(0,150);self.saturation.setValue(100)
        self.saturation.valueChanged.connect(self.saturation_changed);controls.addWidget(self.saturation)
        controls.addWidget(QLabel('Pokyny a doložené barvy'))
        self.prompt=QPlainTextEdit(DEFAULT_PROMPT);self.prompt.setMinimumWidth(0);self.prompt.setMinimumHeight(110);self.prompt.setMaximumHeight(140)
        self.prompt.setWordWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere);controls.addWidget(self.prompt)
        self.seed_count.valueChanged.connect(self.seed_count_changed)
        note=QLabel('Barvy jsou odhad. Doložené barvy doplňte do pokynů. Pro přesný jas ukládejte PNG nebo TIFF.')
        note.setObjectName('Note');note.setWordWrap(True);note.setMinimumWidth(0)
        note.setSizePolicy(QSizePolicy.Policy.Ignored,QSizePolicy.Policy.Preferred);layout.addWidget(note);layout.addStretch()
        scroll.setWidget(sidebar);sidebar_column.addWidget(scroll,1)
        # Export controls are siblings of the scrolling settings, so they stay reachable.
        self.save_panel=QWidget();self.save_panel.setObjectName('SavePanel')
        self.save_panel.setSizePolicy(QSizePolicy.Policy.Preferred,QSizePolicy.Policy.Fixed)
        save_layout=QVBoxLayout(self.save_panel);save_layout.setContentsMargins(16,10,26,16);save_layout.setSpacing(0)
        export=card('ULOŽENÍ',save_layout);export.setSpacing(6);self.export_box=export.parentWidget()
        self.color_space=QComboBox();self.color_space.addItems(['Adobe RGB (1998)','sRGB']);self.color_space.setMinimumWidth(0)
        self.color_space.setAccessibleName('Barevný prostor při uložení');self.color_space.setToolTip('Barevný prostor při uložení výsledku. Vybraný ICC profil se vloží do souboru.');export.addWidget(self.color_space)
        self.format=QComboBox();self.format.addItems(['PNG · 16 bitů','TIFF · 16 bitů','JPEG · 8 bitů','HEIC · 8 bitů']);self.format.setMinimumWidth(0)
        self.format.setAccessibleName('Formát výsledku');export.addWidget(self.format)
        self.save_button=QPushButton('Uložit…');self.save_button.setObjectName('Primary');self.save_button.clicked.connect(self.save_selected);self.save_button.setEnabled(False);export.addWidget(self.save_button)
        self.open_results_button=QPushButton('Otevřít výsledky');self.open_results_button.clicked.connect(self.open_results);export.addWidget(self.open_results_button)
        sidebar_column.addWidget(self.save_panel);main.addWidget(self.sidebar_panel)
        right=QWidget(); body=QVBoxLayout(right); body.setContentsMargins(18,16,18,16); body.setSpacing(12)
        self.tabs=QTabBar();self.tabs.setExpanding(True);self.tabs.setDrawBase(False); self.tabs.addTab('Kolorování'); self.tabs.addTab('Úpravy'); self.tabs.currentChanged.connect(self.change_mode); body.addWidget(self.tabs)
        self.preview_toolbar=QWidget();self.preview_toolbar.setObjectName('PreviewToolbar')
        zoom_row=QHBoxLayout(self.preview_toolbar);zoom_row.setContentsMargins(0,0,0,0);zoom_row.setSpacing(6)
        zoom_row.addWidget(QLabel('Zoom náhledu'))
        self.zoom_out=QPushButton('−');self.zoom_out.setFixedWidth(36);zoom_row.addWidget(self.zoom_out)
        self.zoom_combo=QComboBox();self.zoom_combo.addItem('Přizpůsobit oknu',None)
        for value in CompareCanvas.ZOOM_STEPS:self.zoom_combo.addItem(f'{value*100:g} %'.replace('.',','),value)
        self.zoom_combo.setToolTip('100 %: jeden pixel fotografie na jeden pixel displeje. Kolečko mění zoom, tažení posouvá obraz. Dvojklik přepíná 100 % a přizpůsobení oknu.')
        zoom_row.addWidget(self.zoom_combo)
        self.zoom_in=QPushButton('+');self.zoom_in.setFixedWidth(36);zoom_row.addWidget(self.zoom_in);zoom_row.addStretch(1)
        self.variant_picker=QWidget();self.variant_picker.setObjectName('VariantPicker')
        self.variant_picker.setSizePolicy(QSizePolicy.Policy.Fixed,QSizePolicy.Policy.Fixed)
        variant_row=QHBoxLayout(self.variant_picker);variant_row.setContentsMargins(0,0,0,0);variant_row.setSpacing(4)
        self.variant_label=QLabel('Varianta');self.variant_label.setContentsMargins(0,0,4,0);variant_row.addWidget(self.variant_label)
        self.variant_buttons=[]
        for index in range(MAX_VARIANTS):
            button=QPushButton(str(index+1));button.setCheckable(True);button.setEnabled(False);button.setFixedSize(32,32)
            button.setAccessibleName(f'Barevná varianta {index+1}');button.setVisible(index<self.seed_count.value())
            button.clicked.connect(lambda checked=False,i=index:self.select_variant(i));self.variant_buttons.append(button);variant_row.addWidget(button)
        zoom_row.addWidget(self.variant_picker);body.addWidget(self.preview_toolbar)
        self.canvas=CompareCanvas();self.canvas.viewChanged.connect(self.schedule_fast_preview); body.addWidget(self.canvas,1)
        self.zoom_combo.currentIndexChanged.connect(lambda index:self.apply_zoom(self.zoom_combo.itemData(index)))
        self.zoom_out.clicked.connect(lambda:self.apply_zoom(self.canvas.next_zoom(-1)))
        self.zoom_in.clicked.connect(lambda:self.apply_zoom(self.canvas.next_zoom(1)))
        self.canvas.zoomRequested.connect(self.apply_zoom)
        self.status=QLabel('Připraveno · všechny fotografie se zpracovávají v tomto Macu.');self.status.setObjectName('Note'); self.status.setWordWrap(True);self.status.setMinimumWidth(0);self.status.setSizePolicy(QSizePolicy.Policy.Ignored,QSizePolicy.Policy.Preferred);body.addWidget(self.status)
        bottom=QHBoxLayout(); self.progress=QProgressBar(); self.progress.setRange(0,100); self.progress.setValue(0); self.progress.setTextVisible(False); bottom.addWidget(self.progress,1)
        self.cancel_button=QPushButton('Zrušit'); self.cancel_button.setEnabled(False); self.cancel_button.clicked.connect(self.cancel); bottom.addWidget(self.cancel_button); body.addLayout(bottom)
        main.addWidget(right,1)
        self.controls=[self.open_button,self.batch_button,self.generate_button,self.resolution,self.seed_count,self.seeds,self.prompt,
                       self.format,self.color_space,self.saturation,self.negative_button,*self.adjustment_controls]
        self.change_mode(0)

    def build_adjustment_controls(self,layout):
        box=QGroupBox('Úpravy vybrané varianty');self.adjustment_box=box;body=QVBoxLayout(box)
        self.adjustment_labels={};self.adjustment_sliders={}
        for name,title,low,high,value in [('saturation','Sytost',0,150,100),('brightness','Jas',-50,50,0),
                ('contrast','Kontrast',-100,100,0),('temperature','Teplota',-100,100,0)]:
            label=QLabel();body.addWidget(label);self.adjustment_labels[name]=label
            slider=ControlSlider(Qt.Orientation.Horizontal);slider.setStyle(self._slider_style);slider.setRange(low,high);slider.setValue(value)
            slider.valueChanged.connect(self.adjustments_changed);body.addWidget(slider);self.adjustment_sliders[name]=slider
        self.adjustment_sliders['temperature'].setToolTip('Doleva chladnější, doprava teplejší barvy. Nula zachovává původní barevné podání.')
        self.adjustment_controls=list(self.adjustment_sliders.values())
        self.adjustments_changed();layout.addWidget(box)

    def adjustment_settings(self):
        values={name:slider.value() for name,slider in self.adjustment_sliders.items()}
        values['saturation']/=100
        return validate_adjustments(**values)

    def adjustments_changed(self,*args):
        for name,title in [('saturation','Sytost'),('brightness','Jas'),('contrast','Kontrast'),('temperature','Teplota')]:
            value=self.adjustment_sliders[name].value();suffix=' %' if name in {'saturation','contrast'} else ''
            self.adjustment_labels[name].setText(f'{title} · {value}{suffix}')
        tabs=getattr(self,'tabs',None)
        if tabs is not None and tabs.currentIndex()==1:self.schedule_fast_preview()

    def render_options(self):
        if self.tabs.currentIndex()==1:return {'saturation':1.,'adjustments':self.adjustment_settings()}
        return {'saturation':self.saturation.value()/100,'adjustments':None}

    def cached_image(self,path,full=False):
        if str(path).startswith('memory://'):return self._image_cache.peek(path,full)
        return self._image_cache.get(path,full,
            lambda source,full:image_preview(source,max_size=None if full else 1600))

    def accept_preview_buffers(self,event):
        """Copy mapped RGB frames into Qt, then release the worker's buffers."""
        descriptors=event.get('preview_buffers',[])
        tokens=[]
        try:
            for descriptor in descriptors:
                # Validate before retaining a token or touching a buffer file.
                pixels=read_preview_buffer(descriptor,ROOT/'runtime'/'preview-buffers')
                tokens.append(descriptor['token'])
                h,w=pixels.shape[:2]
                image=QImage(pixels.data,w,h,pixels.strides[0],QImage.Format.Format_RGB888).copy()
                spec=event.get('preview_spec')
                full=bool(event.get('full_resolution',False) or spec and spec['bounds'] is not None)
                self._image_cache.put(memory_path(descriptor),full,image)
        finally:
            if tokens and self.process.state()==QProcess.ProcessState.Running:
                self.process.write((json.dumps({'action':'release_previews','tokens':tokens})+'\n').encode())

    def clear_preview_memory(self):
        self.fast_preview.clear();self._image_cache.clear()
        self._local_preview=None;self._wanted_preview=None

    def fit_view_spec(self):
        if self.canvas.source_size is None:return None
        w,h=self.canvas.source_size;area=self.canvas.image_area(1)
        scale=min(1.,1400/max(w,h),max(1,area.width())*self.canvas.devicePixelRatioF()/w,
            max(1,area.height())*self.canvas.devicePixelRatioF()/h)
        return {'bounds':None,'size':[max(1,round(w*scale)),max(1,round(h*scale))]}

    def requested_view_spec(self):
        if self.canvas.source_size is None:return None
        w,h=self.canvas.source_size;area=self.canvas.image_area(1)
        if self.canvas.zoom is None:
            return self.fit_view_spec()
        rect=self.canvas.image_rect(self.canvas.before,area)
        x0=max(0,min(w-1,math.floor((area.left()-rect.left())*w/rect.width())))
        y0=max(0,min(h-1,math.floor((area.top()-rect.top())*h/rect.height())))
        x1=min(w,max(x0+1,math.ceil((area.right()+1-rect.left())*w/rect.width())))
        y1=min(h,max(y0+1,math.ceil((area.bottom()+1-rect.top())*h/rect.height())))
        scale=min(1.,self.canvas.zoom)
        bounds=None if (x0,y0,x1,y1)==(0,0,w,h) else [x0,y0,x1,y1]
        return {'bounds':bounds,'size':[max(1,round((x1-x0)*scale)),max(1,round((y1-y0)*scale))]}

    def view_matches(self,entry,spec):
        if str(entry.get('path','')).startswith('memory://') and self.cached_image(entry['path'],entry.get('full',False)) is None:return False
        prepared=entry.get('spec')
        if prepared is None:return bool(entry.get('full')) or self.canvas.zoom is None
        if spec is None:return prepared['bounds'] is None
        if prepared['bounds']==spec['bounds']:
            return all(a>=b for a,b in zip(prepared['size'],spec['size']))
        # A sufficiently detailed whole-frame preview can also cover a smaller view.
        if prepared['bounds'] is None and self.canvas.source_size is not None:
            w,h=self.canvas.source_size;x0,y0,x1,y1=spec['bounds']
            return prepared['size'][0]*(x1-x0)/w>=spec['size'][0] and prepared['size'][1]*(y1-y0)/h>=spec['size'][1]
        return False

    def legacy_view(self,variant,saturation,reference=False):
        if not reference and variant.get('preview') and variant.get('preview_saturation',1.)==saturation:
            spec=variant.get('preview_spec')
            return {'path':variant['preview'],'spec':spec,
                'full':variant.get('preview_full_resolution',False) or bool(spec and spec['bounds'] is not None),'saturation':saturation}
        if saturation==1. and variant.get('reference_preview'):
            spec=variant.get('reference_preview_spec')
            return {'path':variant['reference_preview'],'spec':variant.get('reference_preview_spec'),
                'full':variant.get('reference_full_resolution',False) or bool(spec and spec['bounds'] is not None),'saturation':1.}
        return None

    def find_view(self,variant,saturation):
        spec=self.requested_view_spec()
        for entry in reversed(variant.get('_views',[])):
            if entry['saturation']==saturation and self.view_matches(entry,spec):return entry
        entry=self.legacy_view(variant,saturation,reference=self.tabs.currentIndex()==1)
        return entry if entry is not None and self.view_matches(entry,spec) else None

    def remember_view(self,variant,path,saturation,spec):
        entry={'path':path,'saturation':float(saturation),'spec':spec,'full':spec['bounds'] is not None}
        views=[item for item in variant.get('_views',[]) if item['path']!=path]
        variant['_views']=(views+[entry])[-6:]
        return entry

    def view_image(self,entry):
        if entry is None:return None
        return self.cached_image(entry['path'],entry.get('full',False))

    def schedule_fast_preview(self):
        if not hasattr(self,'tabs') or self.busy or self.selected not in self.variants:return
        self._wanted_preview=None
        if not self.preview_timer.isActive():self.preview_timer.start()

    def update_view_preview(self):
        if self.tabs.currentIndex()==1:self.update_fast_preview()
        else:self.ensure_preview()

    def preview_region(self,reference):
        if self.canvas.before_bounds is not None:return None,None
        if self.canvas.zoom is None:
            area=self.canvas.image_area(1);ratio=reference.width()/reference.height()
            width=min(1000,reference.width(),max(1,round(min(area.width(),area.height()*ratio)*self.canvas.devicePixelRatioF())))
            return None,(width,max(1,round(width/ratio)))
        area=self.canvas.image_area(1);rect=self.canvas.image_rect(reference,area)
        w,h=reference.width(),reference.height()
        x0=max(0,math.floor((area.left()-rect.left())*w/rect.width()))
        y0=max(0,math.floor((area.top()-rect.top())*h/rect.height()))
        x1=min(w,math.ceil((area.right()+1-rect.left())*w/rect.width()))
        y1=min(h,math.ceil((area.bottom()+1-rect.top())*h/rect.height()))
        x1,y1=max(x0+1,x1),max(y0+1,y1)
        fit=(max(1,round((x1-x0)*self.canvas.zoom)),max(1,round((y1-y0)*self.canvas.zoom))) if self.canvas.zoom<1. else None
        return (x0,y0,x1,y1),fit

    def update_fast_preview(self):
        if self.busy or self.tabs.currentIndex()!=1 or self.selected not in self.variants:return
        variant=self.variants[self.selected]
        if not self.reference_ready(variant):self.update_saturation();return
        reference=self.view_image(self.find_view(variant,1.))
        settings=self.adjustment_settings()
        if settings==DEFAULT_ADJUSTMENTS:
            self.fast_preview.invalidate();self._wanted_preview=None;self._local_preview=None
            self.refresh_canvas();self.status.setText('Výchozí nastavení · oba obrazy jsou stejné.');return
        crop,fit=self.preview_region(reference)
        context=(self.selected,reference.cacheKey(),tuple(settings.items()),crop,fit)
        if self._local_preview is not None and self._local_preview[0]==context:
            self.refresh_canvas();return
        self._wanted_preview=context
        self.fast_preview.request(reference,settings,crop=crop,fit=fit,context=context)

    def fast_preview_ready(self,context,image,crop,seconds):
        if self.busy or self.tabs.currentIndex()!=1 or self._wanted_preview is None:return
        if context[:2]!=self._wanted_preview[:2] or context[3:]!=self._wanted_preview[3:]:return
        self._local_preview=(context,image,crop)
        self.canvas.after=image;self.canvas.after_crop=crop;self.canvas.after_bounds=self.canvas.before_bounds;self.canvas.update()
        self.status.setText(f'Náhled připraven · {seconds*1000:.0f} ms')

    def stop_worker(self):
        self.debounce.stop();self.preview_timer.stop();self.clear_preview_memory()
        self.expected_stop=True;pid=int(self.process.processId()) or self._worker_pid
        self.process.kill();self.process.waitForFinished(2000)
        if pid:cleanup_preview_buffers(ROOT/'runtime'/'preview-buffers',pid)
        self._worker_pid=0
        self.output_buffer=''

    def toggle_negative(self,enabled):
        self.stop_worker();self.variants={};self.selected=0;self.canvas.after=None
        if self.source:
            try:self._set_before(self.source)
            except Exception as exc:self.show_error(str(exc))
        self.refresh_canvas();self.progress.setValue(0);self.set_busy(False)
        self.status.setText('Negativ je převeden na pozitiv. Můžete jej uložit nebo kolorovat.' if enabled else 'Původní vstup. Barevné varianty vytvořte znovu.')

    def extension(self):return ['.png','.tiff','.jpg','.heic'][self.format.currentIndex()]
    def selected_color_space(self):return ['adobe-rgb','srgb'][self.color_space.currentIndex()]
    def refresh_variant_buttons(self):
        visible=max(self.seed_count.value(),max(self.variants,default=-1)+1)
        for index,button in enumerate(self.variant_buttons):
            button.setVisible(index<visible)
            button.setEnabled(not self.busy and index in self.variants)
            button.setChecked(index==self.selected and index in self.variants)
    def seed_count_changed(self,count):
        try:self.seeds.setText(', '.join(map(str,resize_seeds(self.seeds.text(),count))))
        except ValueError:pass  # Preserve unfinished manual input for correction.
        noun='variantu' if count==1 else 'varianty' if count<=4 else 'variant'
        self.generate_button.setText(f'Vytvořit {count} {noun}')
        self.refresh_variant_buttons()
    def set_busy(self,busy):
        self.busy=busy
        if busy:self.preview_timer.stop();self.fast_preview.invalidate();self._wanted_preview=None
        for control in self.controls:control.setEnabled(not busy)
        self.refresh_variant_buttons()
        self.save_button.setEnabled(not busy and (bool(self.variants) or bool(self.source and self.negative_button.isChecked())))
        self.save_button.setText('Uložit pozitiv…' if self.negative_button.isChecked() and not self.variants else
            'Uložit úpravy…' if self.tabs.currentIndex()==1 else 'Uložit kolorování…')
        self.cancel_button.setEnabled(busy)
    def choose_photo(self):
        photo_filter='Fotografie ('+' '.join('*'+extension for extension in sorted(EXTENSIONS))+')'
        path,_=QFileDialog.getOpenFileName(self,'Otevřít fotografii',str(self.last_photo_dir if self.last_photo_dir.is_dir() else Path.home()),photo_filter)
        if path:self.open_photo(path)

    def remember_directory(self,key,directory):
        if not directory:return
        path=Path(directory).resolve()
        if not path.is_dir():return
        if key=='photo/last_directory':self.last_photo_dir=path
        elif key=='output/last_directory':self.result_dir=path
        self.settings.setValue(key,str(path));self.settings.sync()

    def open_photo(self,path):
        if self.busy:return
        self.stop_worker()
        try:self._set_before(path,refresh=False)
        except Exception as exc:self.show_error(str(exc)); return
        self.source=str(Path(path).resolve()); self.file_label.setText(Path(path).name)
        self.remember_directory('photo/last_directory',Path(self.source).parent)
        self.variants={};self.selected=0;self.batch_mode=False;self.refresh_canvas()
        self.progress.setValue(0); self.status.setText('Fotografie je otevřená. Zvolte počet variant a spusťte kolorování.')
        self.set_busy(False)
    def _set_before(self,path,refresh=True):
        full=self.canvas.zoom is not None
        image=image_preview(path,max_size=None if full else 1600)
        with Image.open(path) as source:
            w,h=source.size
            if source.getexif().get(274) in (5,6,7,8):w,h=h,w
        if self.negative_button.isChecked():image.invertPixels()
        self._original_preview=image;self.canvas.source_size=(w,h);self.canvas.pan=QPointF();self._full_before=full
        if refresh:self.refresh_canvas()

    def apply_zoom(self,value):
        self.canvas.set_zoom(value)
        index=self.zoom_combo.findData(value);self.zoom_combo.blockSignals(True)
        self.zoom_combo.setCurrentIndex(max(0,index));self.zoom_combo.blockSignals(False)
        if value is not None and self.source and not self._full_before:
            try:
                self._original_preview=image_preview(self.source,max_size=None)
                if self.negative_button.isChecked():self._original_preview.invertPixels()
                self._full_before=True
            except Exception as exc:
                self.apply_zoom(None);self.show_error(str(exc));return
        self.refresh_canvas()
        if self.selected in self.variants:self.ensure_preview()

    def options(self):
        seeds=parse_seeds(self.seeds.text(),self.seed_count.value())
        prompt=self.prompt.toPlainText().strip()
        if not prompt:raise ValueError('Doplňte pokyny pro kolorování.')
        return {'resolution':RESOLUTIONS[self.resolution.currentIndex()],'seeds':seeds,'prompt':prompt,
                'saturation':self.saturation.value()/100,'extension':self.extension(),
                'color_space':self.selected_color_space(),'negative':self.negative_button.isChecked(),**self.render_options()}
    def ensure_worker(self):
        if self.process.state()==QProcess.ProcessState.NotRunning:
            self.output_buffer=''; self.expected_stop=False
            self.process.start(sys.executable,['-m','kolor.worker'])
            if not self.process.waitForStarted(3000):raise RuntimeError('Výpočetní proces se nepodařilo spustit.')
            self._worker_pid=int(self.process.processId())
    def send(self,request):
        try:
            self.ensure_worker(); self.set_busy(True)
            self.process.write((json.dumps(request,ensure_ascii=False)+'\n').encode())
        except Exception as exc:self.set_busy(False); self.show_error(str(exc))
    def generate(self):
        if not self.source:self.choose_photo()
        if not self.source:return
        try:options={**self.options(),'saturation':self.saturation.value()/100,'adjustments':None}
        except ValueError as exc:self.show_error(str(exc)); return
        self.debounce.stop()
        self.clear_preview_memory();self.variants={};self.refresh_canvas();self.batch_mode=False
        self.job_dir=ROOT/'runtime'/'sessions'/uuid.uuid4().hex
        self.current_saturation=self.saturation.value()/100
        spec=self.fit_view_spec()
        self.send({'action':'colorize','source':self.source,'output_dir':str(self.job_dir),'save_all':False,
            'preview_transport':'memory',**({'preview_spec':spec} if spec is not None else {}),**options})
    def choose_batch(self):
        try:options={**self.options(),'saturation':1.,'adjustments':None}
        except ValueError as exc:self.show_error(str(exc)); return
        dialog=BatchDialog(self,options,self.result_dir,self.last_photo_dir,self.result_dir)
        accepted=dialog.exec()==QDialog.DialogCode.Accepted
        source=dialog.input_path.text();target=dialog.output_path.text()
        # Folder choices are browsing preferences, even if the batch is cancelled.
        self.remember_directory('photo/last_directory',source)
        self.remember_directory('output/last_directory',target)
        if not accepted:return
        self.debounce.stop();self.preview_timer.stop();self.clear_preview_memory()
        self.result_dir=Path(target);self.batch_mode=True;self.batch_index=0;self.batch_total=1;self.variants={}
        self.saturation.blockSignals(True);self.saturation.setValue(100);self.saturation.blockSignals(False)
        self.saturation_label.setText('Sytost · 100 %');self.current_saturation=1.;self.tabs.setCurrentIndex(0)
        self.status.setText('Spouštím dávkové zpracování…');self.progress.setValue(0);self.refresh_canvas()
        self.send({'action':'batch','input_dir':source,'output_dir':target,**options})
    def base_preview_ready(self,variant):
        return self.find_view(variant,self.saturation.value()/100) is not None

    def reference_ready(self,variant):
        return self.find_view(variant,1.) is not None

    def adjusted_preview_ready(self,variant):
        if self.adjustment_settings()==DEFAULT_ADJUSTMENTS:return self.reference_ready(variant)
        return bool(variant.get('adjusted_preview')) and variant.get('adjustments')==self.adjustment_settings() and self.view_matches(
            {'path':variant['adjusted_preview'],'spec':variant.get('adjusted_preview_spec'),
             'full':variant.get('adjusted_full_resolution',False) or bool((variant.get('adjusted_preview_spec') or {}).get('bounds'))},self.requested_view_spec())

    def refresh_canvas(self):
        variant=self.variants.get(self.selected,{})
        self.canvas.after_crop=None;self.canvas.before_bounds=None;self.canvas.after_bounds=None
        self.canvas.before_fallback=None;self.canvas.after_fallback=None
        if self.tabs.currentIndex()==0:
            saturation=self.saturation.value()/100
            entry=self.find_view(variant,saturation) or self.legacy_view(variant,saturation)
            if entry is None and variant.get('preview'):
                entry={'path':variant['preview'],'spec':variant.get('preview_spec'),'full':variant.get('preview_full_resolution',False)}
            self.canvas.before=self._original_preview;self.canvas.after=self.view_image(entry)
            if entry is not None:
                self.canvas.after_bounds=(entry.get('spec') or {}).get('bounds')
                fallback=self.legacy_view(variant,saturation)
                if self.canvas.after_bounds is not None and fallback is not None:self.canvas.after_fallback=self.view_image(fallback)
            self.canvas.before_label='Pozitiv z negativu' if self.negative_button.isChecked() else 'Originál'
            self.canvas.after_label='Kolorováno'
            self.canvas.empty_message='Přetáhněte sem fotografii\nnebo ji otevřete tlačítkem vlevo.'
        else:
            entry=self.find_view(variant,1.) or self.legacy_view(variant,1.,reference=True)
            reference=self.view_image(entry)
            self.canvas.before=reference
            self.canvas.before_bounds=(entry.get('spec') or {}).get('bounds') if entry is not None else None
            if self.canvas.before_bounds is not None:self.canvas.before_fallback=self.view_image(self.legacy_view(variant,1.,reference=True))
            self.canvas.after=reference;self.canvas.after_bounds=self.canvas.before_bounds
            self.canvas.after_fallback=self.canvas.before_fallback
            if self.adjustment_settings()!=DEFAULT_ADJUSTMENTS and self.adjusted_preview_ready(variant):
                self.canvas.after_bounds=(variant.get('adjusted_preview_spec') or {}).get('bounds')
                self.canvas.after=self.cached_image(variant['adjusted_preview'],
                    variant.get('adjusted_full_resolution',False) or self.canvas.after_bounds is not None)
            if reference is not None and self._local_preview is not None:
                crop,fit=self.preview_region(reference)
                context=(self.selected,reference.cacheKey(),tuple(self.adjustment_settings().items()),crop,fit)
                if self._local_preview[0]==context:
                    self.canvas.after=self._local_preview[1];self.canvas.after_crop=self._local_preview[2]
                    self.canvas.after_bounds=self.canvas.before_bounds
            if reference is not None and self.adjustment_settings()!=DEFAULT_ADJUSTMENTS:
                crop,fit=self.preview_region(reference)
                context=(self.selected,reference.cacheKey(),tuple(self.adjustment_settings().items()),crop,fit)
                if self._local_preview is None or self._local_preview[0]!=context:
                    cached=self.fast_preview.cached(reference,self.adjustment_settings(),crop=crop,fit=fit)
                    if cached is not None:
                        self.fast_preview.invalidate();self._wanted_preview=None
                        self._local_preview=(context,cached,crop)
                        self.canvas.after=cached;self.canvas.after_crop=crop;self.canvas.after_bounds=self.canvas.before_bounds
            self.canvas.before_label='Varianta · sytost 100 %';self.canvas.after_label='Upraveno'
            self.canvas.empty_message='Nejprve vytvořte barevnou variantu.\nPotom zde upravíte sytost, jas, kontrast a teplotu.'
        self.canvas.update()

    def ensure_preview(self):
        if self.busy or self.selected not in self.variants:return
        variant=self.variants[self.selected]
        if self.tabs.currentIndex()==1:
            if not self.reference_ready(variant):self.update_saturation()
            else:self.schedule_fast_preview()
        # Callers already refreshed the canvas. Avoid decoding an oversized
        # uncached image twice merely to confirm that its preview is ready.
        elif not self.base_preview_ready(variant):self.update_saturation()

    def select_variant(self,index):
        if self.busy or index not in self.variants:return
        self.selected=index
        for i,button in enumerate(self.variant_buttons):button.setChecked(i==index)
        self.refresh_canvas();self.ensure_preview()

    def saturation_changed(self,value):
        self.saturation_label.setText(f'Sytost · {value} %')
        if self.variants and not self.busy:self.debounce.start()
    def update_saturation(self):
        if self.busy or self.selected not in self.variants:return
        self.debounce.stop()
        if self.tabs.currentIndex()==1 and self.reference_ready(self.variants[self.selected]):
            self.schedule_fast_preview();return
        self.status.setText('Připravuji referenci pro rychlé úpravy…' if self.tabs.currentIndex()==1 else 'Připravuji čisté kolorování…')
        options=self.render_options()
        if self.tabs.currentIndex()==1:options['adjustments']=dict(DEFAULT_ADJUSTMENTS)
        spec=self.requested_view_spec()
        self.send({'action':'render','variant':self.selected,
                   'full_resolution':self.canvas.zoom is not None,
                   'output_dir':str(self.result_dir),'preview_only':True,'preview_transport':'memory',
                   **({'preview_spec':spec} if spec is not None else {}),**options})
    def save_selected(self):
        start=self.result_dir if self.result_dir.is_dir() else ROOT/'vysledky'
        target=QFileDialog.getExistingDirectory(self,'Uložit upravenou fotografii' if self.tabs.currentIndex()==1 else 'Uložit kolorovanou fotografii',str(start))
        if not target:return
        self.remember_directory('output/last_directory',target)
        self.debounce.stop()
        if self.negative_button.isChecked() and not self.variants:
            self.send({'action':'save_positive','source':self.source,'output_dir':target,
                'extension':self.extension(),'color_space':self.selected_color_space()});return
        self.send({'action':'render','variant':self.selected,
                   'output_dir':target,'extension':self.extension(),'color_space':self.selected_color_space(),**self.render_options()})
    def open_results(self):QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.result_dir)))
    def change_mode(self,index):
        self.debounce.stop();self.preview_timer.stop();self.fast_preview.invalidate();self._wanted_preview=None;self.adjustment_box.setVisible(index==1)
        self.saturation.setVisible(index==0);self.saturation_label.setVisible(index==0)
        self.sidebar_scroll.verticalScrollBar().setValue(0)
        self.canvas.overlay=False;self.canvas.clamp_pan()
        self.refresh_canvas();self.set_busy(self.busy);self.ensure_preview()
    def read_errors(self):
        data=bytes(self.process.readAllStandardError())
        with (ROOT/'runtime'/'worker.log').open('ab') as f:f.write(data)
    def read_output(self):
        self.output_buffer+=bytes(self.process.readAllStandardOutput()).decode('utf-8',errors='replace')
        while '\n' in self.output_buffer:
            line,self.output_buffer=self.output_buffer.split('\n',1)
            if line.startswith('KOLOR:'):
                try:self.handle_event(json.loads(line[6:]))
                except Exception as exc:self.show_error('Chyba zobrazení výsledku: '+str(exc)); self.set_busy(False)
    def handle_event(self,event):
        kind=event['type']
        if kind=='progress':
            fraction=event.get('fraction')
            if fraction is not None:
                if self.batch_mode:fraction=(self.batch_index+fraction)/self.batch_total
                self.progress.setValue(round(fraction*100))
            self.status.setText(event['text'])
        elif kind=='batch_progress':
            self.clear_preview_memory()
            self.batch_index=event['index']; self.batch_total=event['total']; self.variants={}; self.source=event['file']
            try:self._set_before(event['file'])
            except Exception:self.canvas.before=None
            self.canvas.after=None; self.canvas.update(); self.file_label.setText(Path(event['file']).name)
        elif kind=='variant':
            old=self.variants.get(event['variant'],{})
            self._image_cache.invalidate([old.get(key) for key in ('preview','reference_preview','adjusted_preview')]
                +[event.get('preview'),event.get('adjusted_preview')])
            self.accept_preview_buffers(event)
            saturation=event.get('saturation',self.current_saturation)
            item={**event,'preview_saturation':saturation,'preview_full_resolution':False}
            if saturation==1.:item.update(reference_preview=event['preview'],reference_full_resolution=False)
            if event.get('adjusted_preview'):item.update(adjustments=event['adjustments'],adjusted_full_resolution=False)
            if event.get('preview_spec') is not None:
                self.remember_view(item,event['preview'],saturation,event['preview_spec'])
                if saturation==1.:item['reference_preview_spec']=event['preview_spec']
                if event.get('adjusted_preview'):item['adjusted_preview_spec']=event['preview_spec']
            self.variants[event['variant']]=item
            self.variant_buttons[event['variant']].setToolTip(f"Seed {event['stats']['seed']} · {event['stats']['generation_seconds']:.1f} s")
            self.refresh_variant_buttons()
            if event['variant']==0:self.selected=0;self.refresh_canvas()
        elif kind in {'done','batch_done'}:
            self.set_busy(False); self.progress.setValue(100)
            if kind=='batch_done':
                if self.variants:self.select_variant(0)
                self.status.setText(f'Dávka dokončena: {event["completed"]} fotografií, chyb: {len(event["errors"])}. Výsledky: {self.result_dir}')
                if event['errors']:self.show_error('\n'.join(Path(e['source']).name+': '+e['message'] for e in event['errors']))
            else:
                self.current_saturation=self.saturation.value()/100; self.select_variant(0)
                if not self.busy:self.status.setText(f'Připraveno variant: {len(self.variants)}. Vyberte barvy, upravte sytost a uložte výsledek.')
        elif kind=='preview':
            self._image_cache.invalidate([event.get('path'),event.get('base_path')])
            self.accept_preview_buffers(event)
            self.fast_preview.invalidate();self._wanted_preview=None
            full=event.get('full_resolution',False);index=event.get('variant',self.selected)
            self.set_busy(False)
            if index not in self.variants:return
            item=self.variants[index];settings=event.get('adjustments')
            base_path=event.get('base_path',event['path'])
            spec=event.get('preview_spec')
            if spec is not None:
                self.remember_view(item,base_path,event['saturation'],spec)
                if spec['bounds'] is None:
                    if settings is None:item.update(preview=base_path,preview_saturation=event['saturation'],preview_full_resolution=False,preview_spec=spec)
                    if event['saturation']==1.:item.update(reference_preview=base_path,reference_full_resolution=False,reference_preview_spec=spec)
                if settings is not None:
                    item.update(adjusted_preview=event['path'],adjusted_full_resolution=False,
                        adjusted_preview_spec=spec,adjustments=validate_adjustments(**settings))
            elif settings is None:
                item.pop('preview_spec',None)
                item.update(preview=base_path,preview_saturation=event['saturation'],preview_full_resolution=full)
                if event['saturation']==1.:
                    item.pop('reference_preview_spec',None)
                    item.update(reference_preview=base_path,reference_full_resolution=full)
            else:
                item.pop('reference_preview_spec',None);item.pop('adjusted_preview_spec',None)
                item.update(reference_preview=base_path,reference_full_resolution=full,
                    adjusted_preview=event['path'],adjusted_full_resolution=full,adjustments=validate_adjustments(**settings))
            self.refresh_canvas()
            self.status.setText(event.get('stats',{}).get('warning') or 'Náhled připraven.')
            # Tabs and zoom can change while the old preview is being rendered.
            self.ensure_preview()
        elif kind=='saved':
            self.set_busy(False); self.status.setText(('Uložen pozitiv: ' if event.get('positive_only') else 'Uloženo: ')+event['path'])
            self.ensure_preview()
        elif kind=='error':
            self.debounce.stop()
            if event.get('code')=='memory_limit':self.clear_preview_memory();self.variants={};self.refresh_canvas()
            self.set_busy(False);self.status.setText('Úloha se nepodařila.');self.show_error(event['message'])
    def cancel(self):
        self.stop_worker()
        self.variants={};self.refresh_canvas();self.set_busy(False);self.progress.setValue(0)
        self.status.setText('Úloha byla zrušena. Rozpracovaná fotografie se neuloží; hotové soubory zůstávají zachované.')
    def worker_finished(self,code,status):
        if self._worker_pid:cleanup_preview_buffers(ROOT/'runtime'/'preview-buffers',self._worker_pid)
        self._worker_pid=0
        if not self.expected_stop:
            self.clear_preview_memory()
            self.preview_timer.stop();self.fast_preview.invalidate();self._wanted_preview=None;self._local_preview=None
            was_busy=self.busy;self.variants={};self.refresh_canvas();self.debounce.stop();self.set_busy(False)
            if was_busy:self.show_error('Výpočetní proces byl ukončen. Podrobnosti jsou v runtime/worker.log. Zkuste menší rozlišení.')
    def process_error(self,error):
        if error==QProcess.ProcessError.FailedToStart:self.set_busy(False); self.show_error('Výpočetní proces nelze spustit.')
    def show_error(self,message):QMessageBox.warning(self,'bicolor',message)
    def dragEnterEvent(self,event):
        if not self.busy and event.mimeData().hasUrls():event.acceptProposedAction()
    def dropEvent(self,event):
        paths=[u.toLocalFile() for u in event.mimeData().urls() if Path(u.toLocalFile()).suffix.lower() in EXTENSIONS]
        if paths:self.open_photo(paths[0]); event.acceptProposedAction()
    def closeEvent(self,event):
        self.stop_worker();self.fast_preview.close();event.accept()


def main():
    # Refresh immediately before Qt scans plugins, after library imports.
    from bootstrap import repair
    repair()
    app=QApplication(sys.argv); app.setApplicationName('bicolor'); app.setOrganizationName('bicolor')
    app.setWindowIcon(QIcon(str(ROOT/'bicolor.app/Contents/Resources/LokalniKolor-icon.png')))
    window=Window(); window.show()
    for arg in sys.argv[1:]:
        if Path(arg).is_file() and Path(arg).suffix.lower() in EXTENSIONS:window.open_photo(arg); break
    sys.exit(app.exec())

if __name__=='__main__':main()
