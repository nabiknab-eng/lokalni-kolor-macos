"""Pillow HEIF bridge backed by macOS ImageIO, without bundled HEVC codecs."""
import io
from pathlib import Path
import subprocess
import tempfile

from PIL import Image


HELPER=Path(__file__).resolve().parents[1]/'vendor'/'macos-heif-arm64'
_BRANDS={b'heic',b'heix',b'hevc',b'hevx',b'heim',b'heis',b'hevm',b'hevs',b'mif1',b'msf1'}


def _accept(prefix):
    if prefix[4:8]!=b'ftyp':return False
    brands=[prefix[index:index+4] for index in range(8,len(prefix)-3,4)]
    return not any(value in {b'avif',b'avis'} for value in brands) and any(value in _BRANDS for value in brands)


def _convert(data,mode,quality=95):
    if not HELPER.is_file():raise OSError('Chybí nativní podpora HEIC. Ověřte úplnost instalace bicolor.')
    with tempfile.TemporaryDirectory(prefix='bicolor-heif-') as directory:
        source=Path(directory)/('input.heic' if mode=='decode' else 'input.png')
        target=Path(directory)/('output.png' if mode=='decode' else 'output.heic')
        profile=Path(directory)/'profile.icc'
        source.write_bytes(data)
        result=subprocess.run([str(HELPER),mode,str(source),str(target),str(quality/100),str(profile)],
            capture_output=True,timeout=90)
        if result.returncode:
            detail=result.stderr.decode('utf-8',errors='replace').strip()
            raise OSError('macOS nedokázal převést HEIC'+(': '+detail if detail else '.'))
        return target.read_bytes(),profile.read_bytes() if profile.exists() else None


def _open(fp,filename):
    fp.seek(0)
    data,profile=_convert(fp.read(),'decode')
    image=Image.open(io.BytesIO(data))
    image.format='HEIF'
    image.info['bit_depth']=8
    if profile:image.info['icc_profile']=profile
    return image


def _save(image,fp,filename):
    options=image.encoderinfo
    profile=options.get('icc_profile',image.info.get('icc_profile'))
    quality=options.get('quality',95)
    if not isinstance(quality,(int,float)) or not 0<=quality<=100:quality=95
    png=io.BytesIO()
    image.save(png,format='PNG',icc_profile=profile)
    data,_=_convert(png.getvalue(),'encode',quality)
    fp.write(data)


def register_heif_opener():
    Image.register_open('HEIF',_open,_accept)
    Image.register_save('HEIF',_save)
    Image.register_extensions('HEIF',['.heic','.heif','.hif'])
    Image.register_mime('HEIF','image/heic')
