"""CIELAB D65. Originální L je pevné i při mapování do sRGB gamutu.

Veškerá geometrie výstupu pochází z originálu; z návrhu se čte pouze a,b.
Barevné hranice přesto mohou být chybné, protože nejsou z B&W určitelné.
"""
from dataclasses import dataclass
import cv2
import numpy as np

# IEC sRGB matrix, inverse computed from the SAME matrix for reversible L.
RGB_XYZ = np.array([[.4124564,.3575761,.1804375],
                    [.2126729,.7151522,.0721750],
                    [.0193339,.1191920,.9503041]], dtype=np.float64)
XYZ_RGB = np.linalg.inv(RGB_XYZ)
WHITE = RGB_XYZ @ np.ones(3)
DELTA = 6 / 29


def srgb_to_linear(rgb):
    v = np.asarray(rgb, dtype=np.float64)
    return np.where(v <= .04045, v / 12.92, ((v + .055) / 1.055) ** 2.4)


def linear_to_srgb(rgb):
    return np.where(rgb <= .0031308, 12.92 * rgb,
                    1.055 * np.maximum(rgb, 0) ** (1 / 2.4) - .055)


def rgb_to_lab(rgb):
    xyz = (srgb_to_linear(rgb) @ RGB_XYZ.T) / WHITE
    f = np.where(xyz > DELTA**3, np.cbrt(xyz), xyz / (3*DELTA**2) + 4/29)
    return np.stack((116*f[...,1]-16, 500*(f[...,0]-f[...,1]),
                     200*(f[...,1]-f[...,2])), axis=-1)


def lab_to_linear(lab):
    fy = (lab[...,0]+16) / 116
    f = np.stack((fy + lab[...,1]/500, fy, fy - lab[...,2]/200), axis=-1)
    xyz = np.where(f > DELTA, f**3, 3*DELTA**2*(f-4/29)) * WHITE
    return xyz @ XYZ_RGB.T


def gamut_rgb(lightness, ab, saturation=1.0):
    """Reduce chroma along a constant hue/L ray; never clip L into gamut."""
    if not 0 <= saturation <= 1.5:
        raise ValueError('Sytost musí být 0–150 %.')
    lab = np.concatenate((lightness[...,None], np.asarray(ab, dtype=np.float64)*saturation), axis=-1)
    lin = lab_to_linear(lab)
    outside = np.any((lin < -1e-10) | (lin > 1+1e-10), axis=-1)
    count = int(outside.sum())
    if count:
        values = lab[outside].copy()
        lo = np.zeros(len(values)); hi = np.ones(len(values))
        for _ in range(22):
            mid = (lo+hi)/2
            trial = values.copy(); trial[:,1:] *= mid[:,None]
            v = lab_to_linear(trial)
            good = np.all((v >= -1e-10) & (v <= 1+1e-10), axis=-1)
            lo = np.where(good, mid, lo); hi = np.where(good, hi, mid)
        values[:,1:] *= lo[:,None]
        lin[outside] = lab_to_linear(values)
    return np.clip(linear_to_srgb(lin), 0, 1).astype(np.float32), count


def guided_filter(guide, chroma, radius=5, epsilon=.0004):
    """Scalar-guide local linear filtering (He et al.); only filter a,b."""
    guide = np.ascontiguousarray(guide, dtype=np.float32)
    p = np.ascontiguousarray(chroma, dtype=np.float32)
    k = (2*radius+1,)*2
    mean = lambda a: cv2.boxFilter(a, -1, k, borderType=cv2.BORDER_REFLECT)
    mean_i = mean(guide); mean_p = mean(p)
    var_i = np.maximum(mean(guide*guide)-mean_i*mean_i, 0)
    cov = mean(guide[...,None]*p)-mean_i[...,None]*mean_p
    coeff = cov/(var_i[...,None]+epsilon)
    bias = mean_p-coeff*mean_i[...,None]
    return np.clip(mean(coeff)*guide[...,None]+mean(bias), -128, 128)


def align_chroma(reference_l, proposal_lab):
    """Conservative global translation, applied to proposal only, never origin."""
    h,w = reference_l.shape
    ref = cv2.GaussianBlur((reference_l/100).astype(np.float32),(0,0),1.2)
    target = cv2.GaussianBlur((proposal_lab[...,0]/100).astype(np.float32),(0,0),1.2)
    def correlation(a,b):
        return float(np.corrcoef(a.ravel(),b.ravel())[0,1]) if a.std() > 1e-5 and b.std() > 1e-5 else 0.
    before = correlation(ref,target)
    info = {'applied':False,'dx':0.,'dy':0.,'correlation_before':before}
    if ref.std() < .01 or target.std() < .01:
        return proposal_lab[...,1:].astype(np.float32), info
    try:
        warp = np.eye(2,3,dtype=np.float32)
        score, warp = cv2.findTransformECC(ref,target,warp,cv2.MOTION_TRANSLATION,
            (cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,60,1e-5),None,5)
        shifted = cv2.warpAffine(proposal_lab,warp,(w,h),
            flags=cv2.INTER_LINEAR|cv2.WARP_INVERSE_MAP,borderMode=cv2.BORDER_REFLECT)
        after = correlation(ref, cv2.GaussianBlur((shifted[...,0]/100).astype(np.float32),(0,0),1.2))
        if score > .7 and after > before+.003 and abs(warp[0,2]) <= w*.025 and abs(warp[1,2]) <= h*.025:
            info.update(applied=True,dx=float(warp[0,2]),dy=float(warp[1,2]),correlation_after=after)
            return shifted[...,1:].astype(np.float32), info
    except cv2.error:
        pass
    return proposal_lab[...,1:].astype(np.float32), info


@dataclass
class ColorMap:
    ab: np.ndarray
    diagnostics: dict
    guide: np.ndarray | None = None


def refine_chroma_edges(guide,ab,confidence):
    """Keep nearby colors on the same original edge; distrust changed AI detail."""
    radius=3;h,w=guide.shape
    g=np.pad(guide,radius,mode='edge');p=np.pad(ab,((radius,radius),(radius,radius),(0,0)),mode='edge')
    c=np.pad(confidence,radius,mode='edge')
    result=np.zeros_like(ab);total=np.zeros_like(guide)
    for dy in range(-radius,radius+1):
        for dx in range(-radius,radius+1):
            region=(slice(radius+dy,radius+dy+h),slice(radius+dx,radius+dx+w))
            weight=np.exp(-((g[region]-guide)/4.)**2/2-(dx*dx+dy*dy)/8)*c[region]
            result+=p[region]*weight[...,None];total+=weight
    return result/np.maximum(total[...,None],1e-12)


def upsample_chroma_edges(color_map,reference_l,width,height,start):
    """Joint bilateral upsampling on one bounded strip, guided by original L*."""
    sh,sw=color_map.guide.shape
    xs=(np.arange(width,dtype=np.float32)+.5)*sw/width-.5
    ys=(np.arange(start,start+len(reference_l),dtype=np.float32)+.5)*sh/height-.5
    ix=np.floor(xs).astype(np.int32);iy=np.floor(ys).astype(np.int32)
    result=np.zeros((*reference_l.shape,2),np.float32);total=np.zeros(reference_l.shape,np.float32)
    for dy in (-1,0,1,2):
        yy=np.clip(iy+dy,0,sh-1);distance_y=(ys-(iy+dy))**2
        for dx in (-1,0,1,2):
            xx=np.clip(ix+dx,0,sw-1)
            spatial=distance_y[:,None]+(xs-(ix+dx))[None,:]**2
            difference=color_map.guide[yy[:,None],xx[None,:]]-reference_l
            weight=np.exp(-spatial/(2*.8**2)-difference*difference/(2*6.**2)).astype(np.float32)
            result+=color_map.ab[yy[:,None],xx[None,:]]*weight[...,None];total+=weight
    # Extreme contrast can leave all nearby samples unlike the target. Fall
    # back to the nearest sample rather than making a false neutral contour.
    nearest=color_map.ab[np.clip(np.rint(ys).astype(int),0,sh-1)[:,None],
                         np.clip(np.rint(xs).astype(int),0,sw-1)[None,:]]
    return np.where((total>1e-12)[...,None],result/np.maximum(total[...,None],1e-12),nearest)


def prepare_colors(original_rgb, proposal_rgb, align=True):
    h,w = proposal_rgb.shape[:2]
    small = cv2.resize(original_rgb,(w,h),interpolation=cv2.INTER_AREA)
    original_lab = rgb_to_lab(small)
    proposal_lab = rgb_to_lab(proposal_rgb)
    ab, registration = align_chroma(original_lab[...,0],proposal_lab) if align else (
        proposal_lab[...,1:].astype(np.float32), {'applied':False})
    guide=original_lab[...,0].astype(np.float32)
    proposal_l=proposal_lab[...,0].astype(np.float32)
    if registration.get('applied'):
        warp=np.array([[1,0,registration['dx']],[0,1,registration['dy']]],np.float32)
        proposal_l=cv2.warpAffine(proposal_l,warp,(w,h),flags=cv2.INTER_LINEAR|cv2.WARP_INVERSE_MAP,borderMode=cv2.BORDER_REFLECT)
    # Local disagreement is evidence of changed proposal geometry. Prefer
    # nearby trustworthy colors inside the same original luminance region.
    difference=cv2.GaussianBlur(proposal_l,(0,0),.6)-cv2.GaussianBlur(guide,(0,0),.6)
    confidence=np.maximum(np.exp(-difference*difference/(2*8.**2)),.001).astype(np.float32)
    ab=refine_chroma_edges(guide,ab,confidence)
    from skimage.metrics import structural_similarity
    ssim = float(structural_similarity(original_lab[...,0],proposal_lab[...,0],data_range=100))
    return ColorMap(ab, {'raw_l_ssim':ssim,'alignment':registration,
        'edge_protection':'joint-bilateral-confidence-v1',
        'uncertain_chroma_pixels':int((confidence<.5).sum()),
        'warning': 'Návrh výrazně mění strukturu. Zkontrolujte barevné hranice.' if ssim < .65 else None},guide)


def render_colors(original_rgb, color_map, saturation=1., cancel=None):
    """Joint guided upsampling in overlapping strips; full-resolution original L."""
    h,w = original_rgb.shape[:2]
    small_ab = color_map.ab if isinstance(color_map,ColorMap) else color_map
    # Avoid a full-resolution float64 Lab tensor for high resolution scans.
    edge_map=isinstance(color_map,ColorMap) and color_map.guide is not None
    ab=None if edge_map else cv2.resize(small_ab,(w,h),interpolation=cv2.INTER_LINEAR)
    result = np.empty((h,w,3),dtype=np.float32)
    radius = max(2, min(12, round(w/small_ab.shape[1]*3)))
    halo = 2*radius+2
    max_error = 0.; gamut_count = 0
    for y in range(0,h,192):
        if cancel and cancel():
            raise InterruptedError('Úloha zrušena.')
        start = max(0,y-halo); end = min(h,y+192+halo)
        l = rgb_to_lab(original_rgb[start:end])[...,0]
        filtered=(upsample_chroma_edges(color_map,l,w,h,start) if edge_map else
                  guided_filter((l/100).astype(np.float32),ab[start:end],radius))
        region = slice(y-start,min(y+192,h)-start)
        rgb, compressed = gamut_rgb(l[region],filtered[region],saturation)
        result[y:min(y+192,h)] = rgb
        gamut_count += compressed
        max_error = max(max_error,float(np.max(np.abs(rgb_to_lab(rgb)[...,0]-l[region]))))
    return result, {'max_L_error_float':max_error,'gamut_compressed_pixels':gamut_count,
                    'width':w,'height':h,'saturation':saturation,
                    'luminance_reference':'original','max_L_edit_from_original':0.}
