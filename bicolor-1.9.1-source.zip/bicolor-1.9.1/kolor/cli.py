"""Optional CLI for repeatable checks; the .app is the normal entry point."""
import argparse
import json
from pathlib import Path
from .runtime import DEFAULT_PROMPT,RESOLUTIONS
from .profiles import COLOR_SPACES
from .seeds import DEFAULT_SEEDS,MAX_VARIANTS

def main():
    p=argparse.ArgumentParser(description='Lokální kolorování přes Metal; žádné cloudové API.')
    p.add_argument('source',type=Path); p.add_argument('--output',type=Path,required=True)
    p.add_argument('--resolution',type=int,choices=RESOLUTIONS,default=512)
    p.add_argument('--color-space',choices=COLOR_SPACES,default='srgb')
    p.add_argument('--seeds',type=int,nargs='+',default=list(DEFAULT_SEEDS),help=f'1–{MAX_VARIANTS} různých seedů; každý vytvoří jednu variantu.')
    p.add_argument('--negative',action='store_true',help='Černobílý negativ nejprve digitálně převrátit.')
    p.add_argument('--saturation',type=float,default=1.)
    p.add_argument('--prompt',default=DEFAULT_PROMPT); p.add_argument('--format',choices=['png','jpg','tiff','heic'],default='png')
    a=p.parse_args()
    from .engine import Engine
    def emit(event):print(json.dumps(event,ensure_ascii=False),flush=True)
    engine=Engine(emit)
    options={'resolution':a.resolution,'seeds':a.seeds,'prompt':a.prompt,'saturation':a.saturation,
             'extension':'.'+a.format,'color_space':a.color_space,'negative':a.negative}
    if a.source.is_dir():
        from .batch import run_batch
        result=run_batch(engine,a.source,a.output,emit=emit,**options)
        if result['errors']:raise SystemExit(1)
    else:engine.colorize(a.source,a.output,**options)

if __name__=='__main__':main()
