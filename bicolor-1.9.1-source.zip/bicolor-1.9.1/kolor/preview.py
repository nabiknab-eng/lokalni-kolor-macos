"""One cancellable local preview job and bounded caches for repeated variants."""
from collections import OrderedDict
import threading
import time
import cv2
import numpy as np
from PySide6.QtCore import QObject,QRunnable,QThreadPool,Signal
from PySide6.QtGui import QImage
from .color import rgb_to_lab
from .adjustments import apply_adjustments,validate_adjustments


class _ByteLRU:
    """Caller holds FastPreview's lock; sizes include actual sample/row buffers."""
    def __init__(self,max_bytes):
        self.max_bytes=max_bytes;self.bytes_used=0;self.items=OrderedDict()

    def get(self,key):
        item=self.items.get(key)
        if item is None:return None
        self.items.move_to_end(key);return item[0]

    def put(self,key,value,size):
        if size>self.max_bytes:return
        old=self.items.pop(key,None)
        if old is not None:self.bytes_used-=old[1]
        while self.items and self.bytes_used+size>self.max_bytes:
            _,(_,removed)=self.items.popitem(last=False);self.bytes_used-=removed
        self.items[key]=(value,size);self.bytes_used+=size

    def clear(self):
        self.items.clear();self.bytes_used=0


class _Signals(QObject):
    done=Signal(object)


class _Job(QRunnable):
    def __init__(self,owner,request):
        super().__init__();self.owner=owner;self.request=request;self.signals=_Signals()

    def run(self):
        revision,epoch,rgb,key,crop,fit,settings,context=self.request
        start=time.perf_counter();image=None;error=None
        cancelled=lambda:not self.owner.active or revision!=self.owner.revision
        try:
            if cancelled():raise InterruptedError()
            prepared_key=('prepared',key,crop,fit)
            prepared=self.owner._get_prepared(prepared_key)
            if prepared is None:
                part=rgb if crop is None else rgb[crop[1]:crop[3],crop[0]:crop[2]]
                part=part.astype(np.float32)/255
                if fit is not None:part=cv2.resize(part,fit,interpolation=cv2.INTER_AREA)
                lab=rgb_to_lab(part)
                part.setflags(write=False);lab.setflags(write=False)
                prepared=(part,lab)
                if cancelled():raise InterruptedError()
                self.owner._store_prepared(prepared_key,prepared,epoch)
            part,lab=prepared
            result=apply_adjustments(part,settings,lab=lab,cancel=cancelled)
            if cancelled():raise InterruptedError()
            pixels=np.ascontiguousarray(np.rint(result*255),dtype=np.uint8)
            image=QImage(pixels.data,pixels.shape[1],pixels.shape[0],pixels.strides[0],QImage.Format.Format_RGB888).copy()
            self.owner._store_output(self.owner._output_key(key,crop,fit,settings),image,epoch,revision)
        except InterruptedError:pass
        except Exception as exc:error=str(exc)
        self.signals.done.emit((revision,context,image,crop,time.perf_counter()-start,error))


class FastPreview(QObject):
    ready=Signal(object,object,object,float)
    failed=Signal(str)

    def __init__(self,parent=None,*,max_bytes=64*1024**2,output_max_bytes=None):
        super().__init__(parent);self.pool=QThreadPool(self);self.pool.setMaxThreadCount(1)
        self.revision=0;self.active=True;self.running=False;self.pending=None
        self.source_key=None;self.job=None
        self.max_bytes=max(0,int(max_bytes))
        output_max_bytes=self.max_bytes//4 if output_max_bytes is None else int(output_max_bytes)
        self.output_max_bytes=min(self.max_bytes,max(0,output_max_bytes))
        self.prepared_max_bytes=self.max_bytes-self.output_max_bytes
        # A large RGB/Lab working base must not evict the small finished images.
        self._lock=threading.RLock();self._epoch=0
        self._prepared_cache=_ByteLRU(self.prepared_max_bytes)
        self._output_cache=_ByteLRU(self.output_max_bytes)

    @property
    def bytes_used(self):
        with self._lock:return self._prepared_cache.bytes_used+self._output_cache.bytes_used

    @property
    def prepared_bytes(self):
        with self._lock:return self._prepared_cache.bytes_used

    @property
    def output_bytes(self):
        with self._lock:return self._output_cache.bytes_used

    @staticmethod
    def _output_key(key,crop,fit,settings):
        return (key,crop,fit,tuple(sorted(settings.items())))

    def _get_prepared(self,key):
        with self._lock:return self._prepared_cache.get(key)

    def _store_prepared(self,key,value,epoch):
        with self._lock:
            if self.active and epoch==self._epoch:
                self._prepared_cache.put(key,value,sum(item.nbytes for item in value))

    def _store_output(self,key,image,epoch,revision):
        with self._lock:
            if self.active and epoch==self._epoch and revision==self.revision:
                self._output_cache.put(key,QImage(image),image.sizeInBytes())

    def cached(self,image,settings,*,crop=None,fit=None):
        """Return an independent QImage handle for an exact finished preview hit.

        The pixel storage is implicitly shared; Qt detaches a caller's later
        mutation. Context/variant identity is supplied by the current GUI call,
        never recovered from the earlier request that produced these pixels.
        """
        settings=validate_adjustments(**settings)
        crop=None if crop is None else tuple(crop);fit=None if fit is None else tuple(fit)
        with self._lock:
            result=self._output_cache.get(self._output_key(image.cacheKey(),crop,fit,settings))
            return QImage(result) if self.active and result is not None else None

    def invalidate(self):
        """Cancel pending publication while retaining reusable variant pixels."""
        self.revision+=1;self.pending=None

    def clear(self):
        """Start a new photo/session; an old worker cannot repopulate the cache."""
        self.invalidate();self.source_key=None
        with self._lock:
            self._epoch+=1;self._prepared_cache.clear();self._output_cache.clear()

    def request(self,image,settings,*,crop=None,fit=None,context=None):
        if not self.active:return
        start=time.perf_counter();settings=validate_adjustments(**settings)
        crop=None if crop is None else tuple(crop);fit=None if fit is None else tuple(fit)
        key=image.cacheKey();cached=self.cached(image,settings,crop=crop,fit=fit)
        if cached is not None:
            self.invalidate();self.source_key=key
            self.ready.emit(context,cached,crop,time.perf_counter()-start)
            return
        if key!=self.source_key:
            self.invalidate();self.source_key=key
        rgb_key=('rgb',key);rgb=self._get_prepared(rgb_key)
        if rgb is None:
            converted=image.convertToFormat(QImage.Format.Format_RGB888)
            rows=np.frombuffer(converted.constBits(),dtype=np.uint8).reshape(converted.height(),converted.bytesPerLine())
            rgb=rows[:,:converted.width()*3].reshape(converted.height(),converted.width(),3).copy()
            rgb.setflags(write=False)
            with self._lock:self._prepared_cache.put(rgb_key,rgb,rgb.nbytes)
        with self._lock:epoch=self._epoch
        self.pending=(self.revision,epoch,rgb,key,crop,fit,settings,context)
        if not self.running:self._start()

    def _start(self):
        if self.pending is None or not self.active:return
        request=self.pending;self.pending=None;self.running=True
        self.job=_Job(self,request);self.job.signals.done.connect(self._done);self.pool.start(self.job)

    def _done(self,result):
        self.running=False;revision,context,image,crop,seconds,error=result
        if self.active and revision==self.revision:
            if error:self.failed.emit(error)
            elif image is not None:self.ready.emit(context,image,crop,seconds)
        self.job=None
        self._start()

    def close(self):
        self.active=False;self.clear();self.pool.waitForDone(3000)
