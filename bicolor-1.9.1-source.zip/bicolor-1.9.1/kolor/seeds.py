"""Shared seed limits and predictable resizing for the native UI."""
MAX_VARIANTS=3
SEED_LIMIT=2**32
DEFAULT_SEEDS=(42,43,44)


def validate_seeds(seeds,count=None):
    values=list(seeds)
    if not 1<=len(values)<=MAX_VARIANTS:
        raise ValueError(f'Zvolte 1 až {MAX_VARIANTS} různých seedů.')
    if any(type(seed) is not int or not 0<=seed<SEED_LIMIT for seed in values):
        raise ValueError('Seed musí být celé číslo od 0 do 4294967295.')
    if len(set(values))!=len(values):
        raise ValueError('Každý seed musí být jiný.')
    if count is not None and len(values)!=count:
        raise ValueError(f'Pro zvolený počet variant zadejte přesně {count} seedů oddělených čárkami.')
    return values


def parse_seeds(text,count=None):
    try:values=[int(value.strip()) for value in text.split(',')]
    except ValueError:raise ValueError('Zadejte celá čísla seedů oddělená čárkami.') from None
    return validate_seeds(values,count)


def resize_seeds(text,count):
    if type(count) is not int or not 1<=count<=MAX_VARIANTS:
        raise ValueError(f'Počet variant musí být 1–{MAX_VARIANTS}.')
    values=parse_seeds(text)[:count]
    candidate=values[-1]
    while len(values)<count:
        candidate=(candidate+1)%SEED_LIMIT
        if candidate not in values:values.append(candidate)
    return values
