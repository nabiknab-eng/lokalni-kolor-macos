"""Reversible digital B&W negative input; no film-mask or tone correction."""
import numpy as np


def prepare_input(rgb, negative=False):
    if not isinstance(negative,bool):raise ValueError('Volba negativu musí být ano/ne.')
    return np.subtract(np.float32(1.),rgb,dtype=np.float32) if negative else rgb
