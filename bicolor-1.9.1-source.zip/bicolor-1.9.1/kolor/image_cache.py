"""Byte-bounded display images, with separate budgets for fit and full views.

Only image decoding is cached. The caller must invalidate a path after the
worker overwrites that file; cache hits deliberately do not touch the disk.
"""
from collections import OrderedDict
import os


class PreviewImageCache:
    def __init__(self,max_bytes=128*1024**2,small_max_bytes=None):
        if isinstance(max_bytes,bool) or not isinstance(max_bytes,int) or max_bytes<0:
            raise ValueError('Image cache limit must be a non-negative integer.')
        if small_max_bytes is None:small_max_bytes=max_bytes//4
        if isinstance(small_max_bytes,bool) or not isinstance(small_max_bytes,int) or not 0<=small_max_bytes<=max_bytes:
            raise ValueError('Small image limit must fit inside the total cache limit.')
        self.max_bytes=max_bytes;self.small_max_bytes=small_max_bytes
        self.full_max_bytes=max_bytes-small_max_bytes
        self._images={False:OrderedDict(),True:OrderedDict()}
        self._bytes={False:0,True:0}

    @staticmethod
    def _path(path):
        # Normalize Path/str and relative aliases without stat or file reads.
        return os.path.normpath(os.path.abspath(os.fspath(path)))

    @property
    def bytes_used(self):return self._bytes[False]+self._bytes[True]

    @property
    def small_bytes(self):return self._bytes[False]

    @property
    def full_bytes(self):return self._bytes[True]

    def __len__(self):return sum(len(images) for images in self._images.values())

    def keys(self):
        return tuple((path,full) for full,images in self._images.items() for path in images)

    def __contains__(self,key):
        path,full=key
        return self._path(path) in self._images[bool(full)]

    def get(self,path,full,loader):
        full=bool(full);key=self._path(path);images=self._images[full]
        if key in images:
            images.move_to_end(key);return images[key][0]
        image=loader(path,full)
        self.put(path,full,image)
        return image

    def peek(self,path,full=False):
        """Return an already decoded frame without attempting file I/O."""
        images=self._images[bool(full)];key=self._path(path)
        if key not in images:return None
        images.move_to_end(key)
        return images[key][0]

    def put(self,path,full,image):
        """Retain pixels received directly from the worker within the same budget."""
        full=bool(full);key=self._path(path);images=self._images[full]
        old=images.pop(key,None)
        if old is not None:self._bytes[full]-=old[1]
        size=int(image.sizeInBytes())
        limit=self.full_max_bytes if full else self.small_max_bytes
        # A huge detail must not flush useful thumbnails, nor empty details
        # that already fit. Null images are not retained as zero-cost entries.
        if size<=0 or size>limit:return False
        while self._bytes[full]+size>limit:
            _,(_,removed)=images.popitem(last=False);self._bytes[full]-=removed
        images[key]=(image,size);self._bytes[full]+=size
        return True

    def invalidate(self,paths):
        if isinstance(paths,(str,bytes,os.PathLike)):paths=(paths,)
        for path in paths:
            if path is None:continue
            key=self._path(path)
            for full,images in self._images.items():
                entry=images.pop(key,None)
                if entry is not None:self._bytes[full]-=entry[1]

    def clear(self):
        for images in self._images.values():images.clear()
        self._bytes={False:0,True:0}
