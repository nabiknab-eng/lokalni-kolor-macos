"""Float32 ICC transforms using LittleCMS already bundled in the Pillow wheel.

The Adobe RGB profile comes from macOS ColorSync, not from a redistributed
copy. Conversion changes RGB samples before the selected profile is embedded.
"""
import ctypes as C
import io
from functools import lru_cache
from pathlib import Path
import numpy as np
import PIL
from PIL import ImageCms

COLOR_SPACES = ('srgb', 'adobe-rgb')
SRGB_PROFILE = ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
ADOBE_PROFILE_PATH = Path('/System/Library/ColorSync/Profiles/AdobeRGB1998.icc')
RGB_SIGNATURE = 0x52474220
GRAY_SIGNATURE = 0x47524159
# lcms2.h: FLOAT_SH(1) | COLORSPACE_SH(PT_RGB/GRAY) | CHANNELS_SH(n) | BYTES_SH(4)
RGB_FLOAT = (1 << 22) | (4 << 16) | (3 << 3) | 4
GRAY_FLOAT = (1 << 22) | (3 << 16) | (1 << 3) | 4


@lru_cache(maxsize=1)
def _cms():
    library = Path(PIL.__file__).parent / '.dylibs/liblcms2.2.dylib'
    if not library.is_file():
        raise RuntimeError('Chybí LittleCMS z instalačního balíčku Pillow. Spusťte Instalovat.command.')
    cms = C.CDLL(str(library))
    signatures = {
        'cmsOpenProfileFromMem': ([C.c_void_p, C.c_uint32], C.c_void_p),
        'cmsCloseProfile': ([C.c_void_p], C.c_int),
        'cmsGetColorSpace': ([C.c_void_p], C.c_uint32),
        'cmsCreateTransform': ([C.c_void_p, C.c_uint32, C.c_void_p, C.c_uint32,
                                C.c_uint32, C.c_uint32], C.c_void_p),
        'cmsDoTransform': ([C.c_void_p, C.c_void_p, C.c_void_p, C.c_uint32], None),
        'cmsDeleteTransform': ([C.c_void_p], None),
    }
    for name, (arguments, result) in signatures.items():
        function = getattr(cms, name)
        function.argtypes = arguments
        function.restype = result
    return cms


@lru_cache(maxsize=2)
def export_profile(color_space='srgb'):
    if color_space == 'srgb':
        return SRGB_PROFILE
    if color_space != 'adobe-rgb':
        raise ValueError('Barevný prostor musí být sRGB nebo Adobe RGB (1998).')
    try:
        profile = ADOBE_PROFILE_PATH.read_bytes()
        description = ImageCms.getProfileDescription(ImageCms.ImageCmsProfile(io.BytesIO(profile)))
        if 'adobe' not in description.lower():
            raise ValueError('Neočekávaný systémový ICC profil.')
        return profile
    except Exception as exc:
        raise RuntimeError('Systémový profil Adobe RGB (1998) není dostupný v ColorSync.') from exc


def convert_profile(rgb, source_profile, target_profile):
    """Convert RGB (or repeated gray) in strips, without an 8-bit intermediate."""
    source = np.asarray(rgb, dtype=np.float32)
    if source.ndim != 3 or source.shape[-1] != 3 or not np.isfinite(source).all():
        raise ValueError('ICC převod vyžaduje konečné RGB hodnoty.')
    if source_profile == target_profile:
        return source
    cms = _cms()
    source_buffer = C.create_string_buffer(source_profile)
    target_buffer = C.create_string_buffer(target_profile)
    src = dst = transform = None
    try:
        src = cms.cmsOpenProfileFromMem(source_buffer, len(source_profile))
        dst = cms.cmsOpenProfileFromMem(target_buffer, len(target_profile))
        if not src or not dst:
            raise ValueError('ICC profil nelze načíst.')
        signature = cms.cmsGetColorSpace(src)
        if signature not in (RGB_SIGNATURE, GRAY_SIGNATURE) or cms.cmsGetColorSpace(dst) != RGB_SIGNATURE:
            raise ValueError('Pro tento vstup je potřeba RGB nebo šedotónový ICC profil.')
        transform = cms.cmsCreateTransform(src, GRAY_FLOAT if signature == GRAY_SIGNATURE else RGB_FLOAT,
                                           dst, RGB_FLOAT, 1, 0)  # relative colorimetric
        if not transform:
            raise ValueError('ICC převod nelze vytvořit.')
        result = np.empty(source.shape, dtype=np.float32)
        for y in range(0, source.shape[0], 192):
            block = source[y:y+192]
            if signature == GRAY_SIGNATURE:
                block = block[..., 0]
            block = np.ascontiguousarray(block)
            output = result[y:y+192]
            cms.cmsDoTransform(transform, C.c_void_p(block.ctypes.data),
                               C.c_void_p(output.ctypes.data), block.shape[0]*source.shape[1])
        if not np.isfinite(result).all():
            raise ValueError('ICC převod vytvořil neplatné hodnoty.')
        return np.clip(result, 0, 1)
    finally:
        if transform: cms.cmsDeleteTransform(transform)
        if dst: cms.cmsCloseProfile(dst)
        if src: cms.cmsCloseProfile(src)


def encode_output(rgb, color_space='srgb'):
    profile = export_profile(color_space)
    return convert_profile(rgb, SRGB_PROFILE, profile), profile
