"""Private mapped RGB buffers for worker-to-window display previews.

Pixels are quantized exactly as in the PNG preview path, but never compressed.
The worker retains each buffer until the window copies it and acknowledges its
token. The fixed directory comes from the installation, never from an event.
"""
import mmap
import os
from pathlib import Path
import re
import stat
import uuid

import numpy as np


MAX_PREVIEW_PIXELS=8_000_000
DEFAULT_PENDING_BYTES=64*1024**2
_TOKEN=re.compile(r'^[0-9a-f]{32}$')


def _integer(value,name,maximum):
    if isinstance(value,bool) or not isinstance(value,int) or not 0<value<=maximum:
        raise ValueError(f'Invalid preview {name}.')
    return value


def _descriptor(value):
    if not isinstance(value,dict) or value.get('kind')!='rgb8-mmap':
        raise ValueError('Invalid preview buffer type.')
    token=value.get('token')
    if not isinstance(token,str) or not _TOKEN.fullmatch(token):
        raise ValueError('Invalid preview buffer token.')
    pid=_integer(value.get('pid'),'producer',2**31-1)
    width=_integer(value.get('width'),'width',MAX_PREVIEW_PIXELS)
    height=_integer(value.get('height'),'height',MAX_PREVIEW_PIXELS)
    if width*height>MAX_PREVIEW_PIXELS:
        raise ValueError('Preview buffer exceeds the display limit.')
    size=_integer(value.get('nbytes'),'size',MAX_PREVIEW_PIXELS*3)
    if size!=width*height*3:
        raise ValueError('Preview buffer dimensions do not match its size.')
    return token,pid,width,height,size


def memory_path(descriptor):
    token,*_=_descriptor(descriptor)
    return 'memory://'+token


def read_preview_buffer(descriptor,directory):
    """Return an independent RGB8 array; no mapping remains after this call."""
    token,pid,width,height,size=_descriptor(descriptor)
    path=Path(directory)/f'{pid}-{token}.rgb'
    flags=os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)
    fd=os.open(path,flags)
    try:
        info=os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_size!=size:
            raise ValueError('Preview buffer has an invalid size or file type.')
        with mmap.mmap(fd,size,access=mmap.ACCESS_READ) as buffer:
            return np.ndarray((height,width,3),dtype=np.uint8,buffer=buffer).copy()
    finally:
        os.close(fd)


def cleanup_preview_buffers(directory,pid):
    """Remove only a stopped worker's strict PID/token filenames.

    The window calls this after cancellation or an unexpected process exit.
    Other application instances have different producer PIDs.
    """
    pid=_integer(pid,'producer',2**31-1)
    directory=Path(directory)
    if not directory.is_dir():return
    pattern=re.compile(rf'^{pid}-[0-9a-f]{{32}}\.rgb$')
    for path in directory.iterdir():
        if pattern.fullmatch(path.name):
            try:path.unlink()
            except FileNotFoundError:pass


class PreviewBufferStore:
    """One producer's bounded unacknowledged display buffers."""
    def __init__(self,directory,max_bytes=DEFAULT_PENDING_BYTES):
        if isinstance(max_bytes,bool) or not isinstance(max_bytes,int) or max_bytes<0:
            raise ValueError('Invalid preview buffer budget.')
        self.directory=Path(directory);self.max_bytes=max_bytes
        self.pid=os.getpid();self.pending={};self.bytes_pending=0

    def publish(self,rgb):
        if not isinstance(rgb,np.ndarray) or rgb.ndim!=3 or rgb.shape[2]!=3:
            raise ValueError('Preview pixels must have three RGB channels.')
        height,width=rgb.shape[:2];size=int(width*height*3)
        if width*height>MAX_PREVIEW_PIXELS or self.bytes_pending+size>self.max_bytes or len(self.pending)>=128:
            raise BufferError('Preview buffers exceed the pending memory budget.')
        if min(width,height)<=0:raise ValueError('Preview dimensions must be positive.')
        pixels=np.ascontiguousarray(np.rint(np.clip(rgb,0,1)*255),dtype=np.uint8)
        self.directory.mkdir(parents=True,exist_ok=True,mode=0o700)
        token=uuid.uuid4().hex;path=self.directory/f'{self.pid}-{token}.rgb'
        fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_RDWR,0o600)
        try:
            os.ftruncate(fd,size)
            with mmap.mmap(fd,size,access=mmap.ACCESS_WRITE) as buffer:
                buffer[:]=memoryview(pixels).cast('B')
        except BaseException:
            path.unlink(missing_ok=True);raise
        finally:
            os.close(fd)
        self.pending[token]=(path,size);self.bytes_pending+=size
        return {'kind':'rgb8-mmap','token':token,'pid':self.pid,
            'width':int(width),'height':int(height),'nbytes':size}

    def release(self,tokens):
        if isinstance(tokens,str):tokens=(tokens,)
        if not isinstance(tokens,(list,tuple)) or len(tokens)>1024:
            raise ValueError('Invalid preview acknowledgement.')
        for token in tokens:
            if not isinstance(token,str) or not _TOKEN.fullmatch(token):
                raise ValueError('Invalid preview acknowledgement token.')
            entry=self.pending.pop(token,None)
            if entry is not None:
                path,size=entry
                path.unlink(missing_ok=True);self.bytes_pending-=size

    def close(self):
        self.release(tuple(self.pending))
