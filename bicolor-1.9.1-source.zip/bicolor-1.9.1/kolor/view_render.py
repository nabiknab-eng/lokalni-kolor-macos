"""Display-size/visible-region color transfer; the full export path is separate.

The same luminance-guided chroma weights and gamut mapping are used as in the
export. A 1:1 visible crop samples the global original/map coordinates, while a
smaller view first downsamples its original RGB. The latter is deliberately a
display approximation, not a replacement for the full-resolution export.
"""
import numbers
import cv2
import numpy as np
from .color import ColorMap,rgb_to_lab,gamut_rgb,guided_filter

MAX_VIEW_PIXELS=8_000_000


def _integers(values,length,name):
    if not isinstance(values,(tuple,list)) or len(values)!=length:
        raise ValueError(f'Neplatné {name} náhledu.')
    if any(isinstance(v,bool) or not isinstance(v,numbers.Integral) for v in values):
        raise ValueError(f'Neplatné {name} náhledu.')
    return tuple(int(v) for v in values)


def validate_view_spec(source_size,spec=None,max_side=1400):
    """Return JSON-safe global bounds and output pixels, without reading a file."""
    width,height=_integers(source_size,2,'rozměry zdroje')
    if width<1 or height<1:raise ValueError('Neplatné rozměry zdroje náhledu.')
    if spec is None:
        scale=min(1.,max_side/max(width,height))
        return {'bounds':None,'size':[max(1,round(width*scale)),max(1,round(height*scale))]}
    if not isinstance(spec,dict) or set(spec)-{'bounds','size'}:
        raise ValueError('Neplatné nastavení náhledu.')
    bounds=spec.get('bounds')
    if bounds is None:x0,y0,x1,y1=0,0,width,height
    else:
        x0,y0,x1,y1=_integers(bounds,4,'souřadnice výřezu')
        if not 0<=x0<x1<=width or not 0<=y0<y1<=height:
            raise ValueError('Výřez náhledu je mimo fotografii.')
    size=spec.get('size',[x1-x0,y1-y0])
    ow,oh=_integers(size,2,'velikost')
    if ow<1 or oh<1 or ow*oh>MAX_VIEW_PIXELS:
        raise ValueError('Náhled přesahuje povolenou velikost.')
    # Upscaling is a painter operation, not a reason to transfer more pixels.
    if ow>x1-x0 or oh>y1-y0:
        raise ValueError('Náhled nesmí mít více pixelů než jeho zdrojový výřez.')
    return {'bounds':None if bounds is None else [x0,y0,x1,y1],'size':[ow,oh]}


def _coordinates(bounds,size,source_size,map_size,start=0,rows=None):
    x0,y0,x1,y1=bounds;ow,oh=size;width,height=source_size;sw,sh=map_size
    rows=oh-start if rows is None else rows
    # float32 and operation order reproduce the export's 1:1 pixel centers.
    xs=((np.arange(ow,dtype=np.float32)+.5)*((x1-x0)/ow)+x0)*sw/width-.5
    ys=((np.arange(start,start+rows,dtype=np.float32)+.5)*((y1-y0)/oh)+y0)*sh/height-.5
    return xs,ys


def _joint_chroma(color_map,lightness,bounds,size,source_size,start):
    sh,sw=color_map.guide.shape
    xs,ys=_coordinates(bounds,size,source_size,(sw,sh),start,len(lightness))
    ix=np.floor(xs).astype(np.int32);iy=np.floor(ys).astype(np.int32)
    result=np.zeros((*lightness.shape,2),np.float32);total=np.zeros(lightness.shape,np.float32)
    for dy in (-1,0,1,2):
        yy=np.clip(iy+dy,0,sh-1);distance_y=(ys-(iy+dy))**2
        for dx in (-1,0,1,2):
            xx=np.clip(ix+dx,0,sw-1)
            spatial=distance_y[:,None]+(xs-(ix+dx))[None,:]**2
            difference=color_map.guide[yy[:,None],xx[None,:]]-lightness
            weight=np.exp(-spatial/(2*.8**2)-difference*difference/(2*6.**2)).astype(np.float32)
            result+=color_map.ab[yy[:,None],xx[None,:]]*weight[...,None];total+=weight
    nearest=color_map.ab[np.clip(np.rint(ys).astype(int),0,sh-1)[:,None],
                        np.clip(np.rint(xs).astype(int),0,sw-1)[None,:]]
    return np.where((total>1e-12)[...,None],result/np.maximum(total[...,None],1e-12),nearest)


def _linear_chroma(ab,bounds,size,source_size):
    """Bilinear global map samples without allocating a full-size chroma field."""
    sh,sw=ab.shape[:2]
    xs,ys=_coordinates(bounds,size,source_size,(sw,sh))
    ix=np.floor(xs).astype(np.int32);iy=np.floor(ys).astype(np.int32)
    ax=(xs-ix).astype(np.float32);ay=(ys-iy).astype(np.float32)
    xlo=np.clip(ix,0,sw-1);xhi=np.clip(ix+1,0,sw-1)
    ylo=np.clip(iy,0,sh-1);yhi=np.clip(iy+1,0,sh-1)
    upper=ab[ylo[:,None],xlo[None,:]]*(1-ax)[None,:,None]+ab[ylo[:,None],xhi[None,:]]*ax[None,:,None]
    lower=ab[yhi[:,None],xlo[None,:]]*(1-ax)[None,:,None]+ab[yhi[:,None],xhi[None,:]]*ax[None,:,None]
    return upper*(1-ay)[:,None,None]+lower*ay[:,None,None]


def render_view(original_rgb,color_map,saturation=1.,*,bounds=None,size=None,cancel=None):
    """Render only requested output pixels, retaining global chroma alignment.

    Bounds use original source pixels with an exclusive right/bottom edge.
    Size is the number of output pixels; ``None`` uses the natural crop size.
    A full-image fit is requested by bounds=None and a smaller size.
    """
    if not 0<=saturation<=1.5:raise ValueError('Sytost musí být 0–150 %.')
    h,w=original_rgb.shape[:2]
    requested={'bounds':bounds}
    if size is not None:requested['size']=size
    spec=validate_view_spec((w,h),requested)
    bounds=(0,0,w,h) if spec['bounds'] is None else tuple(spec['bounds'])
    x0,y0,x1,y1=bounds;ow,oh=spec['size']
    source=original_rgb[y0:y1,x0:x1]
    natural=(ow==x1-x0 and oh==y1-y0)
    rgb=source if natural else cv2.resize(source,(ow,oh),interpolation=cv2.INTER_AREA)
    edge_map=isinstance(color_map,ColorMap) and color_map.guide is not None
    ab=color_map.ab if isinstance(color_map,ColorMap) else color_map
    legacy_l=legacy_filtered=None
    if not edge_map:
        # Old maps without a luminance guide need a halo because the guided
        # filter depends on neighboring target pixels. Normal Klein maps use
        # the joint path above and never allocate this enlarged fallback view.
        radius=max(2,min(12,round(w/ab.shape[1]*3)))
        if natural:
            halo=2*radius+2
            bx0,by0=max(0,x0-halo),max(0,y0-halo)
            bx1,by1=min(w,x1+halo),min(h,y1+halo)
            expanded=(bx0,by0,bx1,by1);expanded_size=(bx1-bx0,by1-by0)
            legacy_l=rgb_to_lab(original_rgb[by0:by1,bx0:bx1])[...,0]
            expanded_ab=_linear_chroma(ab,expanded,expanded_size,(w,h))
            filtered=guided_filter((legacy_l/100).astype(np.float32),expanded_ab,radius)
            region=(slice(y0-by0,y1-by0),slice(x0-bx0,x1-bx0))
            legacy_l=legacy_l[region];legacy_filtered=filtered[region]
        else:
            legacy_l=rgb_to_lab(rgb)[...,0]
            sampled=_linear_chroma(ab,bounds,(ow,oh),(w,h))
            scaled_radius=max(2,min(12,round(radius*ow/(x1-x0))))
            legacy_filtered=guided_filter((legacy_l/100).astype(np.float32),sampled,scaled_radius)
    result=np.empty((oh,ow,3),np.float32);gamut_count=0;max_error=0.
    for start in range(0,oh,192):
        if cancel and cancel():raise InterruptedError('Náhled byl nahrazen novějším nastavením.')
        stop=min(oh,start+192)
        lightness=rgb_to_lab(rgb[start:stop])[...,0] if edge_map else legacy_l[start:stop]
        filtered=_joint_chroma(color_map,lightness,bounds,(ow,oh),(w,h),start) if edge_map else legacy_filtered[start:stop]
        part,count=gamut_rgb(lightness,filtered,saturation);result[start:stop]=part;gamut_count+=count
        max_error=max(max_error,float(np.max(np.abs(rgb_to_lab(part)[...,0]-lightness))))
    return result,{'width':ow,'height':oh,'saturation':saturation,'source_width':w,'source_height':h,
        'render_scope':'preview','preview_spec':spec,'preview_approximation':not natural,
        'gamut_compressed_pixels':gamut_count,'max_L_error_float':max_error,
        'luminance_reference':'display-original' if not natural else 'original-crop',
        'max_L_edit_from_original':0.}
