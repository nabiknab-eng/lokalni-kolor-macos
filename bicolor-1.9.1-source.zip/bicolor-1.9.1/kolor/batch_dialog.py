"""Explicit input, output and start for batch processing."""
from pathlib import Path
from PySide6.QtWidgets import QDialog,QVBoxLayout,QLabel,QLineEdit,QPushButton,QFileDialog,QDialogButtonBox
from .batch import input_files


class BatchDialog(QDialog):
    def __init__(self,parent,options,result_dir,input_dir=None,output_dir=None):
        super().__init__(parent);self.setWindowTitle('Dávkové zpracování');self.resize(620,420)
        self.options={**options,'saturation':1.,'adjustments':None};self.result_dir=str(result_dir);layout=QVBoxLayout(self)
        intro=QLabel('Vyberte, odkud se mají fotografie načíst a kam se uloží výsledky. Dávka začne až tlačítkem Spustit dávku.')
        intro.setWordWrap(True);layout.addWidget(intro)
        self.input_path=QLineEdit();self.output_path=QLineEdit()
        for title,field,caption,slot in [
            ('1. Vstupní složka — původní fotografie',self.input_path,'Vybrat vstupní složku…',self.choose_input),
            ('2. Výstupní složka — uložené výsledky',self.output_path,'Vybrat výstupní složku…',self.choose_output)]:
            layout.addWidget(QLabel(title));field.setReadOnly(True);field.setPlaceholderText('Složka zatím není vybraná')
            layout.addWidget(field);button=QPushButton(caption);button.clicked.connect(slot);layout.addWidget(button)
        self.summary=QLabel();self.summary.setWordWrap(True);layout.addWidget(self.summary)
        self.buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel)
        self.start_button=self.buttons.button(QDialogButtonBox.StandardButton.Ok);self.start_button.setText('Spustit dávku')
        self.buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Zrušit')
        self.buttons.accepted.connect(self.start);self.buttons.rejected.connect(self.reject);layout.addWidget(self.buttons)
        for field,path in [(self.input_path,input_dir),(self.output_path,output_dir)]:
            if path and Path(path).is_dir():field.setText(str(path))
        self.input_path.textChanged.connect(self.refresh);self.output_path.textChanged.connect(self.refresh);self.refresh()

    def choose_input(self):
        path=QFileDialog.getExistingDirectory(self,'VSTUP — složka původních fotografií',self.input_path.text())
        if path:self.input_path.setText(path)

    def choose_output(self):
        path=QFileDialog.getExistingDirectory(self,'VÝSTUP — složka pro uložení výsledků',self.output_path.text() or self.result_dir)
        if path:self.output_path.setText(path)

    def refresh(self):
        source=self.input_path.text();target=self.output_path.text();count=0
        try:
            if source and Path(source).is_dir():count=len(input_files(source))
        except OSError:pass
        valid=bool(count and target and Path(target).is_dir());self.start_button.setEnabled(valid)
        if not source:text='Nejprve vyberte vstupní složku s fotografiemi.'
        elif not count:text='Ve vstupní složce nejsou podporované vstupní fotografie. Podsložky se neprocházejí.'
        elif not target:text=f'Počet vstupních fotografií: {count}. Nyní vyberte výstupní složku pro výsledky.'
        elif not Path(target).is_dir():text='Výstupní složka již není dostupná. Vyberte ji znovu.'
        else:
            variants=len(self.options['seeds']);mode='čisté kolorování, sytost 100 %'
            text=f'Fotografií: {count}. Variant na fotografii: {variants}. Celkem barevných výsledků: {count*variants} ({mode}). Uloží se jen hotové kolorované varianty ve zvoleném formátu, bez dalších úprav a pracovních souborů. Po stisknutí Spustit dávku začne výpočet. Originály se nepřepisují.'
        self.summary.setText(text)

    def start(self):
        self.refresh()
        if self.start_button.isEnabled():self.accept()
