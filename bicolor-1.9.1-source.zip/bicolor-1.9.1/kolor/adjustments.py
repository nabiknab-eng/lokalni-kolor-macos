"""Independent, non-destructive corrections of the 100% colorized variant."""
import math
import numpy as np
from .color import rgb_to_lab,gamut_rgb

DEFAULT_ADJUSTMENTS={'saturation':1.,'brightness':0.,'contrast':0.,'temperature':0.}


def validate_adjustments(saturation=1.,brightness=0.,contrast=0.,temperature=0.):
    values={'saturation':saturation,'brightness':brightness,'contrast':contrast,'temperature':temperature}
    for name,low,high in [('saturation',0,1.5),('brightness',-50,50),('contrast',-100,100),('temperature',-100,100)]:
        value=values[name]
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not low<=value<=high:
            raise ValueError('Neplatná hodnota úpravy: '+name)
    return {name:float(value) for name,value in values.items()}


def apply_adjustments(base,settings=None,*,lab=None,cancel=None):
    settings=validate_adjustments(**(settings or {}))
    if settings==DEFAULT_ADJUSTMENTS:return base
    result=np.empty_like(base,dtype=np.float32)
    for y in range(0,base.shape[0],192):
        if cancel is not None and cancel():raise InterruptedError('Náhled byl nahrazen novějším nastavením.')
        part=rgb_to_lab(base[y:y+192]) if lab is None else lab[y:y+192]
        lightness=np.clip(50+(part[...,0]-50)*(1+settings['contrast']/100)+settings['brightness'],0,100)
        # Relative warm/cool shift, not an invented Kelvin measurement of the photo.
        ab=part[...,1:]+np.array([4.,20.])*settings['temperature']/100
        result[y:y+192],_=gamut_rgb(lightness,ab,settings['saturation'])
    return result
