"""Best-effort diagnostic versions must never block image processing."""
from importlib import metadata
import json
from .runtime import ROOT


def package_version(name):
    """Return (version, provenance); the bundled pin is a fallback, not a probe."""
    try:
        version = metadata.version(name)
        if version:
            return version, 'installed_metadata'
    except (metadata.PackageNotFoundError, OSError, ValueError):
        pass
    if name == 'mflux':
        try:
            pin = json.loads((ROOT/'vendor'/'MFLUX-REVISION.json').read_text())
            version = pin.get('package_version')
            if isinstance(version, str) and version:
                return version, 'bundled_manifest'
        except (OSError, ValueError, AttributeError):
            pass
    return None, 'unavailable'
