"""All caches remain local to the installation. Runtime never uses the network."""
import os
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT/'modely'/'flux2-klein-4b-4bit'
MODEL_REPO = 'mlx-community/flux2-klein-4b-4bit'
MODEL_REVISION = '860e87183ceb29e39627c0612ebd66d8ea66e68c'
RESOLUTIONS = (512, 768, 1024)
DEFAULT_PROMPT = ('Colorize this historical black and white photograph with realistic, natural and historically plausible colors. '
    'Preserve the exact composition, facial identities, expressions, clothing, architecture, geometry, lighting and photographic appearance. '
    'Do not restore, sharpen, smooth, redesign or add details. Avoid exaggerated saturation and modern cinematic grading.')


def configure():
    for key, relative in [('HF_HOME','runtime/huggingface'),('XDG_CACHE_HOME','runtime/cache'),('MPLCONFIGDIR','runtime/matplotlib')]:
        path = ROOT/relative; path.mkdir(parents=True,exist_ok=True)
        os.environ[key] = str(path)
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
    os.environ['DO_NOT_TRACK'] = '1'
    os.environ['TOKENIZERS_PARALLELISM'] = 'false'
    os.environ['USE_TORCH'] = '0'
