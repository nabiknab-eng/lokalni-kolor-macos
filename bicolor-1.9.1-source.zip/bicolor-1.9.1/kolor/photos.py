"""Profile-aware input and exclusive, atomic output publication."""
import io
import os
from pathlib import Path
import struct
import tempfile
import zlib
import cv2
import numpy as np
from PIL import Image, ImageCms, ImageOps
from .native_heif import register_heif_opener
import tifffile
from .profiles import SRGB_PROFILE, convert_profile, encode_output

# Register once for all Pillow users, including the GUI's thumbnail decoder.
# The decoder selects the HEIF primary image and applies container orientation.
register_heif_opener()

INPUT_EXTENSIONS = {'.jpg','.jpeg','.jpe','.jfif','.png','.tif','.tiff',
                    '.heic','.heif','.hif','.bmp','.webp','.avif'}
OUTPUT_EXTENSIONS = {'.jpg','.jpeg','.png','.tif','.tiff','.heic','.heif'}
EXTENSIONS = INPUT_EXTENSIONS  # Existing batch, drag/drop and launch callers.


def validate_input_image(im):
    """Validate the selected still image before decoding its full pixel buffer.

    HEIF containers can include several images; Pillow already selects the
    primary image. Other multipage/animated inputs need an explicit selection.
    """
    if getattr(im,'n_frames',1) != 1 and im.format != 'HEIF':
        raise ValueError('Vícestránkové a animované fotografie nejsou podporovány. Vyexportujte jednotlivé snímky.')
    if im.width*im.height > 80_000_000:
        raise ValueError('Fotografie přesahuje limit 80 milionů pixelů pro 16 GB RAM.')
    if 'A' in im.getbands() and im.getchannel('A').getextrema()[0] < 255:
        raise ValueError('Průhledné fotografie nejprve slučte s pozadím.')
    if im.mode == 'P' and 'transparency' in im.info and im.convert('RGBA').getchannel('A').getextrema()[0] < 255:
        raise ValueError('Průhledné fotografie nejprve slučte s pozadím.')


def load_photo(path):
    path = Path(path)
    if path.suffix.lower() not in EXTENSIONS:
        raise ValueError('Podporované formáty jsou JPEG, PNG, TIFF, HEIC/HEIF, BMP, WebP a AVIF.')
    with Image.open(path) as im:
        validate_input_image(im)
        orientation = im.getexif().get(274,1)
        icc = im.info.get('icc_profile')
        # Only PNG/TIFF use this 16-bit path. HEIF's container transforms are
        # handled by its Pillow decoder, so a second decoder must not rotate it.
        raw = (cv2.imdecode(np.frombuffer(path.read_bytes(),np.uint8),cv2.IMREAD_UNCHANGED)
               if im.format in {'PNG','TIFF'} else None)
        if raw is not None and raw.dtype == np.uint16:
            arr = raw.astype(np.float32)/65535
            if arr.ndim == 2:
                arr = np.repeat(arr[...,None],3,axis=-1)
            elif arr.shape[-1] == 4:
                if np.min(arr[...,3]) < 1:
                    raise ValueError('Průhledné fotografie nejprve slučte s pozadím.')
                arr = arr[...,:3][...,::-1].copy()
            else:
                arr = arr[...,:3][...,::-1].copy()
            if icc:
                try: arr = convert_profile(arr,icc,SRGB_PROFILE)
                except Exception as exc:
                    raise ValueError('16bitový vstupní ICC profil nelze bezpečně převést do sRGB.') from exc
            # Apply EXIF orientation without quantizing 16-bit samples.
            if orientation == 2: arr = arr[:,::-1]
            elif orientation == 3: arr = arr[::-1,::-1]
            elif orientation == 4: arr = arr[::-1]
            elif orientation == 5: arr = arr.transpose(1,0,2)
            elif orientation == 6: arr = np.rot90(arr,3)
            elif orientation == 7: arr = arr.transpose(1,0,2)[::-1,::-1]
            elif orientation == 8: arr = np.rot90(arr,1)
            return np.ascontiguousarray(arr)
        im = ImageOps.exif_transpose(im)
        if icc:
            try:
                source_profile = ImageCms.ImageCmsProfile(io.BytesIO(icc))
                if source_profile.profile.xcolor_space.strip() == 'GRAY':
                    im = im.convert('L')
                elif im.mode not in {'RGB','CMYK','L'}:
                    im = im.convert('RGB')
                im = ImageCms.profileToProfile(im,source_profile,
                    ImageCms.createProfile('sRGB'),outputMode='RGB',renderingIntent=1)
            except Exception as exc:
                raise ValueError('Vstupní ICC profil nelze bezpečně převést do sRGB.') from exc
        else:
            im = im.convert('RGB')
        return np.asarray(im,dtype=np.float32)/255


def _png16(rgb, profile=SRGB_PROFILE):
    data = np.rint(np.clip(rgb,0,1)*65535).astype(np.uint16)
    ok, encoded = cv2.imencode('.png',np.ascontiguousarray(data[...,::-1]),[cv2.IMWRITE_PNG_COMPRESSION,4])
    if not ok: raise OSError('PNG se nepodařilo zapsat.')
    blob = encoded.tobytes()
    payload = b'ICC profile\x00\x00'+zlib.compress(profile)
    chunk = b'iCCP'+payload
    chunk = struct.pack('>I',len(payload))+chunk+struct.pack('>I',zlib.crc32(chunk)&0xffffffff)
    return blob[:33]+chunk+blob[33:]


def save_photo(rgb, source, directory, extension='.png', suffix='_kolor', color_space='srgb'):
    """Create unique name; even a racing writer can never replace an existing file."""
    source = Path(source).resolve()
    directory = Path(directory).resolve(); directory.mkdir(parents=True,exist_ok=True)
    extension = extension.lower()
    if extension not in OUTPUT_EXTENSIONS: raise ValueError('Nepodporovaný formát výstupu.')
    rgb, profile = encode_output(rgb,color_space)
    if extension in {'.jpg','.jpeg'}:
        b = io.BytesIO()
        Image.fromarray(np.rint(np.clip(rgb,0,1)*255).astype(np.uint8)).save(
            b,format='JPEG',quality=98,subsampling=0,icc_profile=profile)
        blob = b.getvalue()
    elif extension == '.png':
        blob = _png16(rgb,profile)
    elif extension in {'.heic','.heif'}:
        b = io.BytesIO()
        Image.fromarray(np.rint(np.clip(rgb,0,1)*255).astype(np.uint8)).save(
            b,format='HEIF',quality=95,chroma=444,icc_profile=profile,
            save_nclx_profile=False)
        blob = b.getvalue()
    else:
        b = io.BytesIO()
        tifffile.imwrite(b,np.rint(np.clip(rgb,0,1)*65535).astype(np.uint16),
            photometric='rgb',metadata=None,extratags=[(34675,'B',len(profile),profile,False)])
        blob = b.getvalue()
    fd,tmp = tempfile.mkstemp(prefix='.kolor-',dir=directory)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(blob); f.flush(); os.fsync(f.fileno())
        for index in range(100000):
            stem = source.stem+suffix+(f'_{index+1}' if index else '')
            candidate = directory/(stem+extension)
            if candidate.resolve() == source: continue
            try:
                os.link(tmp,candidate)  # atomic no-clobber publication on the same filesystem
                return candidate
            except FileExistsError:
                continue
        raise OSError('Nepodařilo se najít volný název souboru.')
    finally:
        Path(tmp).unlink(missing_ok=True)
