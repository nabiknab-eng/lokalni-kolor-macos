#!/bin/zsh
ROOT="${0:A:h}"
cd "$ROOT"
"$ROOT/.python/bin/python3" "$ROOT/bootstrap.py" --repair-only
"$ROOT/.venv/bin/python" "$ROOT/scripts/check_installation.py"
if [[ -t 0 ]]; then read '?Stiskněte Enter…'; fi
