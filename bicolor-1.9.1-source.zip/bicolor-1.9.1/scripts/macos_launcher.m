// Native app identity for LaunchServices/TCC; Python remains inside this process.
// This launcher changes no privacy settings and never grants its own permissions.
#import <Cocoa/Cocoa.h>
#include <Python.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int fail(NSString *message) {
    NSAlert *alert = [[NSAlert alloc] init];
    alert.messageText = @"bicolor nelze spustit";
    alert.informativeText = message;
    [alert addButtonWithTitle:@"OK"];
    [alert runModal];
    return 1;
}

int main(int argc, char **argv) {
    @autoreleasepool {
        NSString *bundle = [[NSBundle mainBundle] bundlePath];
        NSString *root = [bundle stringByDeletingLastPathComponent];
        NSString *python = [root stringByAppendingPathComponent:@".venv/bin/python"];
        NSString *runtime = [root stringByAppendingPathComponent:@"runtime"];
        const char *rootPath = [root fileSystemRepresentation];
        if (chdir(rootPath) != 0) {
            return fail(@"Aplikace nemá přístup ke své složce. Ponechte celou složku bicolor-1.9.1 pohromadě a případně povolte této aplikaci přístup k Dokumentům v Nastavení systému → Soukromí a zabezpečení → Soubory a složky.");
        }
        NSError *error = nil;
        if (![[NSFileManager defaultManager] createDirectoryAtPath:runtime withIntermediateDirectories:YES attributes:nil error:&error]) {
            return fail([NSString stringWithFormat:@"Nelze otevřít pracovní složku: %@", error.localizedDescription]);
        }
        NSFileManager *files = [NSFileManager defaultManager];
        NSString *basePython = [root stringByAppendingPathComponent:@".python/bin/python3.12"];
        NSString *venvConfig = [root stringByAppendingPathComponent:@".venv/pyvenv.cfg"];
        if (![files isExecutableFileAtPath:basePython] || ![files fileExistsAtPath:venvConfig]) {
            return fail(@"Nejprve ve stejné složce spusťte Instalovat.command a nechte instalaci dokončit. Potom otevřete bicolor.app.");
        }
        // Repair before Python initializes, so moving the complete installation
        // cannot select its old standard library or virtual environment.
        NSString *configuration = [NSString stringWithFormat:@"home = %@/.python/bin\ninclude-system-site-packages = false\nversion = 3.12.15\nexecutable = %@\n", root, basePython];
        NSString *currentConfiguration = [NSString stringWithContentsOfFile:venvConfig encoding:NSUTF8StringEncoding error:nil];
        if (![configuration isEqualToString:currentConfiguration] && ![configuration writeToFile:venvConfig atomically:YES encoding:NSUTF8StringEncoding error:&error]) {
            return fail(@"Nelze aktualizovat prostředí Pythonu. Celá instalační složka musí být dostupná pro zápis.");
        }
        for (NSString *name in @[@"python", @"python3", @"python3.12"]) {
            NSString *path = [[root stringByAppendingPathComponent:@".venv/bin"] stringByAppendingPathComponent:name];
            NSString *destination = [files destinationOfSymbolicLinkAtPath:path error:nil];
            if (destination && ![destination isEqualToString:@"../../.python/bin/python3.12"]) {
                if (![files removeItemAtPath:path error:&error] || ![files createSymbolicLinkAtPath:path withDestinationPath:@"../../.python/bin/python3.12" error:&error]) {
                    return fail(@"Nelze obnovit cestu k Pythonu. Spusťte znovu Instalovat.command ve stejné složce.");
                }
            }
        }
        BOOL check = argc > 1 && strcmp(argv[1], "--launcher-check") == 0;
        BOOL repair = argc > 1 && strcmp(argv[1], "--repair-only") == 0;
        if (!check) {
            NSString *logPath = [runtime stringByAppendingPathComponent:@"aplikace.log"];
            if (!freopen([logPath fileSystemRepresentation], "a", stdout)) {
                return fail(@"macOS nepovolil zápis do pracovní složky aplikace. Povolte aplikaci bicolor přístup k Dokumentům v Nastavení systému → Soukromí a zabezpečení → Soubory a složky a spusťte ji znovu.");
            }
            dup2(fileno(stdout), fileno(stderr));
        }
        unsetenv("PYTHONHOME");
        setenv("PYTHONPATH", rootPath, 1);
        setenv("PYTHONDONTWRITEBYTECODE", "1", 1);
        NSString *cache = [runtime stringByAppendingPathComponent:@"pycache"];
        setenv("PYTHONPYCACHEPREFIX", [cache fileSystemRepresentation], 1);
        char **args = calloc((size_t)argc + 4, sizeof(char *));
        if (!args) return fail(@"Není dost paměti pro spuštění aplikace.");
        int count = 0;
        args[count++] = strdup([python fileSystemRepresentation]);
        if (check) {
            args[count++] = "-c";
            args[count++] = "import json,sys,kolor; from pathlib import Path; print(json.dumps({'executable':sys.executable,'prefix':sys.prefix,'version':kolor.__version__,'root':str(Path(kolor.__file__).resolve().parents[1])}))";
        } else if (repair) {
            args[count++] = strdup([[root stringByAppendingPathComponent:@"bootstrap.py"] fileSystemRepresentation]);
            args[count++] = "--repair-only";
        } else {
            args[count++] = "-m";
            args[count++] = "kolor.gui";
            for (int index = 1; index < argc; ++index) {
                if (strncmp(argv[index], "-psn_", 5) != 0) args[count++] = argv[index];
            }
        }
        // argv[0] selects the separate venv. Keep the native executable alive
        // instead of exec'ing zsh/python so macOS retains the app's identity.
        return Py_BytesMain(count, args);
    }
}
