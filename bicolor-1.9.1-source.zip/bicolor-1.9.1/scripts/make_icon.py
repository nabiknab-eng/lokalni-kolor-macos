"""Render the supplied vector artwork; no external image assets or services."""
from pathlib import Path
import struct
import tempfile
from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication,QImage,QPainter
from PySide6.QtSvg import QSvgRenderer

ROOT=Path(__file__).resolve().parents[1]
app=QGuiApplication([])
renderer=QSvgRenderer(str(ROOT/'assets/bicolor-icon-1.9.1.svg'))
resources=ROOT/'bicolor.app/Contents/Resources'
with tempfile.TemporaryDirectory() as temp:
    iconset=Path(temp)/'bicolor.iconset';iconset.mkdir()
    chunks=[]
    tags={(16,1):b'icp4',(16,2):b'ic11',(32,1):b'icp5',(32,2):b'ic12',
          (128,1):b'ic07',(128,2):b'ic13',(256,1):b'ic08',(256,2):b'ic14',
          (512,1):b'ic09',(512,2):b'ic10'}
    for points in [16,32,128,256,512]:
        for scale in [1,2]:
            size=points*scale;image=QImage(size,size,QImage.Format.Format_ARGB32_Premultiplied)
            image.fill(Qt.GlobalColor.transparent);painter=QPainter(image)
            renderer.render(painter);painter.end()
            path=iconset/f'icon_{points}x{points}{"@2x" if scale==2 else ""}.png'
            if not image.save(str(path)):raise RuntimeError('PNG icon could not be rendered.')
            png=path.read_bytes();chunks.append(tags[points,scale]+struct.pack('>I',len(png)+8)+png)
            if size==1024:
                image.save(str(resources/'LokalniKolor-icon.png'))
                image.save(str(ROOT/'assets/bicolor-icon-1.9.1.png'))
    content=b''.join(chunks)
    (resources/'LokalniKolor.icns').write_bytes(b'icns'+struct.pack('>I',len(content)+8)+content)
