"""Build an allowlisted public package; never include user/model/runtime data."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from kolor import __version__ as VERSION
FOLDERS=['kolor','scripts','licenses','bicolor.app']
FILES=['bootstrap.py','Instalovat.command','Spustit.command','Diagnostika.command',
       'README.md','INSTALACE.md','NAVOD.md','CHANGELOG.md','THIRD_PARTY_NOTICES.md',
       'requirements.lock','.gitignore']
VENDOR=['MFLUX-LICENSE.txt','MFLUX-REVISION.json','mflux-0.23.0-py3-none-any.whl','macos-heif-arm64']

def digest(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def copytree(source,target):
    shutil.copytree(source,target,copy_function=shutil.copyfile,
        ignore=shutil.ignore_patterns('__pycache__','.DS_Store','*.pyc'))

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--cache',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--offline',action='store_true')
    parser.add_argument('--source-only',action='store_true')
    args=parser.parse_args();args.cache.mkdir(parents=True,exist_ok=True);args.output.mkdir(parents=True,exist_ok=True)
    pin=json.loads((ROOT/'scripts/python-runtime.json').read_text())
    runtime=args.cache/'python-runtime.tar.gz'
    if not args.source_only:
        if not runtime.is_file() or digest(runtime)!=pin['sha256']:
            raise RuntimeError('Pinned CPython archive missing or damaged; prepare cache before publishing.')
    with tempfile.TemporaryDirectory(prefix='bicolor-release-',dir=args.cache) as temporary:
        stage=Path(temporary)/f'bicolor-{VERSION}';stage.mkdir()
        for folder in FOLDERS:copytree(ROOT/folder,stage/folder)
        for name in FILES:shutil.copyfile(ROOT/name,stage/name)
        copytree(ROOT/'assets/ui',stage/'assets/ui')
        for extension in ['svg','png']:
            shutil.copyfile(ROOT/f'assets/bicolor-icon-{VERSION}.{extension}',stage/f'assets/bicolor-icon-{VERSION}.{extension}')
        (stage/'modely').mkdir();shutil.copyfile(ROOT/'modely/LICENSE-Apache-2.0.txt',stage/'modely/LICENSE-Apache-2.0.txt')
        (stage/'vendor').mkdir()
        for name in VENDOR:shutil.copyfile(ROOT/'vendor'/name,stage/'vendor'/name)
        if not args.source_only:
            shutil.copyfile(runtime,stage/'vendor/python-runtime.tar.gz')
        for path in stage.rglob('*'):
            if path.is_file():path.chmod(0o755 if path.suffix=='.command' or path.name in {'LokalniKolor','macos-heif-arm64'} else 0o644)
        if not args.source_only:
            manifest={'version':VERSION,'files':{str(path.relative_to(stage)):digest(path)
                for path in sorted(stage.rglob('*')) if path.is_file()}}
            (stage/'bundle-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
        filename=f'bicolor-{VERSION}-'+('source.zip' if args.source_only else 'macOS-arm64.zip')
        target=args.output/filename
        with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as archive:
            for path in sorted(stage.rglob('*')):
                if path.is_file():archive.write(path,path.relative_to(stage.parent))
        checksum=digest(target)
        target.with_suffix('.zip.sha256').write_text(f'{checksum}  {target.name}\n')
        print(json.dumps({'file':str(target),'bytes':target.stat().st_size,'sha256':checksum}),flush=True)

if __name__=='__main__':main()
