// bicolor's native HEIC bridge. Uses only frameworks provided by macOS.
// Build: clang -O2 -fobjc-arc -arch arm64 -mmacosx-version-min=26.0
//   -framework Foundation -framework CoreGraphics -framework ImageIO
//   scripts/macos_heif.m -o vendor/macos-heif-arm64
#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <ImageIO/ImageIO.h>

static int fail(NSString *message) {
    fprintf(stderr, "%s\n", [message UTF8String]);
    return 2;
}

static CGImageRef eightBitImage(CGImageRef image,NSInteger orientation) {
    size_t width=CGImageGetWidth(image), height=CGImageGetHeight(image);
    CGColorSpaceRef space=CGImageGetColorSpace(image);
    CGColorSpaceModel model=space ? CGColorSpaceGetModel(space) : kCGColorSpaceModelUnknown;
    CGColorSpaceRef fallback=NULL;
    if (model!=kCGColorSpaceModelRGB && model!=kCGColorSpaceModelMonochrome) {
        fallback=CGColorSpaceCreateWithName(kCGColorSpaceSRGB);space=fallback;
        model=kCGColorSpaceModelRGB;
    }
    size_t channels=model==kCGColorSpaceModelMonochrome ? 2 : 4;
    size_t stride=width*channels;
    CGContextRef context=CGBitmapContextCreate(NULL,width,height,8,stride,space,
        (CGBitmapInfo)kCGImageAlphaPremultipliedLast);
    if (!context) { if (fallback) CGColorSpaceRelease(fallback);return NULL; }
    CGContextSetBlendMode(context,kCGBlendModeCopy);
    CGContextDrawImage(context,CGRectMake(0,0,width,height),image);
    BOOL swapped=orientation>=5 && orientation<=8;
    size_t outputWidth=swapped ? height : width, outputHeight=swapped ? width : height;
    CGContextRef oriented=NULL;
    if (orientation>=2 && orientation<=8) {
        oriented=CGBitmapContextCreate(NULL,outputWidth,outputHeight,8,outputWidth*channels,space,
            (CGBitmapInfo)kCGImageAlphaPremultipliedLast);
        if (!oriented) { CGContextRelease(context);if (fallback) CGColorSpaceRelease(fallback);return NULL; }
        const uint8_t *src=CGBitmapContextGetData(context);
        uint8_t *dst=CGBitmapContextGetData(oriented);
        for (size_t y=0;y<outputHeight;y++) for (size_t x=0;x<outputWidth;x++) {
            size_t sx=x,sy=y;
            switch (orientation) {
                case 2:sx=width-1-x;break;
                case 3:sx=width-1-x;sy=height-1-y;break;
                case 4:sy=height-1-y;break;
                case 5:sx=y;sy=x;break;
                case 6:sx=y;sy=height-1-x;break;
                case 7:sx=width-1-y;sy=height-1-x;break;
                case 8:sx=width-1-y;sy=x;break;
            }
            memcpy(dst+(y*outputWidth+x)*channels,src+(sy*width+sx)*channels,channels);
        }
    }
    CGImageRef result=CGBitmapContextCreateImage(oriented ?: context);
    if (oriented) CGContextRelease(oriented);
    CGContextRelease(context);
    if (fallback) CGColorSpaceRelease(fallback);
    return result;
}

int main(int argc,const char *argv[]) {
    @autoreleasepool {
        if (argc<4) return fail(@"Usage: macos-heif-arm64 decode|encode input output [quality]");
        NSString *mode=[NSString stringWithUTF8String:argv[1]];
        if (![mode isEqualToString:@"decode"] && ![mode isEqualToString:@"encode"])
            return fail(@"Unknown operation.");
        NSURL *sourceURL=[NSURL fileURLWithPath:[NSString stringWithUTF8String:argv[2]]];
        CGImageSourceRef source=CGImageSourceCreateWithURL((__bridge CFURLRef)sourceURL,NULL);
        if (!source) return fail(@"macOS cannot read this image.");
        size_t index=CGImageSourceGetPrimaryImageIndex(source);
        NSDictionary *properties=CFBridgingRelease(CGImageSourceCopyPropertiesAtIndex(source,index,NULL));
        unsigned long long width=[properties[(__bridge NSString *)kCGImagePropertyPixelWidth] unsignedLongLongValue];
        unsigned long long height=[properties[(__bridge NSString *)kCGImagePropertyPixelHeight] unsignedLongLongValue];
        if (!width || !height || width>80000000ULL || height>80000000ULL || width*height>80000000ULL) {
            CFRelease(source);return fail(@"The image exceeds the 80-million-pixel limit.");
        }
        NSDictionary *options=@{(__bridge NSString *)kCGImageSourceShouldCache:@NO,
                                (__bridge NSString *)kCGImageSourceShouldAllowFloat:@NO};
        CGImageRef decoded=CGImageSourceCreateImageAtIndex(source,index,(__bridge CFDictionaryRef)options);
        CFRelease(source);
        if (!decoded) return fail(@"macOS failed to decode the primary image.");
        if (CGImageGetWidth(decoded)>80000000ULL/CGImageGetHeight(decoded)) {
            CGImageRelease(decoded);return fail(@"The image exceeds the 80-million-pixel limit.");
        }
        NSInteger orientation=[mode isEqualToString:@"decode"] ? [properties[(__bridge NSString *)kCGImagePropertyOrientation] integerValue] : 1;
        CGImageRef image=eightBitImage(decoded,orientation);CGImageRelease(decoded);
        if (!image) return fail(@"macOS failed to prepare the 8-bit image.");
        if (argc>5) {
            NSData *profile=CFBridgingRelease(CGColorSpaceCopyICCData(CGImageGetColorSpace(image)));
            if (profile) [profile writeToFile:[NSString stringWithUTF8String:argv[5]] atomically:YES];
        }
        NSURL *targetURL=[NSURL fileURLWithPath:[NSString stringWithUTF8String:argv[3]]];
        CFStringRef type=[mode isEqualToString:@"decode"] ? CFSTR("public.png") : CFSTR("public.heic");
        CGImageDestinationRef target=CGImageDestinationCreateWithURL((__bridge CFURLRef)targetURL,type,1,NULL);
        if (!target) { CGImageRelease(image);return fail(@"macOS cannot create the requested output format."); }
        double quality=argc>4 ? atof(argv[4]) : .95;
        if (!isfinite(quality) || quality<0 || quality>1) quality=.95;
        NSDictionary *outputProperties=@{
            (__bridge NSString *)kCGImagePropertyOrientation:@1,
            (__bridge NSString *)kCGImageDestinationLossyCompressionQuality:@(quality)
        };
        CGImageDestinationAddImage(target,image,(__bridge CFDictionaryRef)outputProperties);
        bool success=CGImageDestinationFinalize(target);
        CFRelease(target);CGImageRelease(image);
        return success ? 0 : fail(@"macOS failed to write the image.");
    }
}
