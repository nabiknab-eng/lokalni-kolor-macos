#!/bin/zsh
ROOT="${0:A:h}"
exec open "$ROOT/Lokální Kolor.app"
