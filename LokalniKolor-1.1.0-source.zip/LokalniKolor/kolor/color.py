"""CIELAB D65. Originální L je pevné i při mapování do sRGB gamutu.

Veškerá geometrie výstupu pochází z originálu; z návrhu se čte pouze a,b.
Barevné hranice přesto mohou být chybné, protože nejsou z B&W určitelné.
"""
from dataclasses import dataclass
import cv2
import numpy as np

# IEC sRGB matrix, inverse computed from the SAME matrix for reversible L.
RGB_XYZ = np.array([[.4124564,.3575761,.1804375],
                    [.2126729,.7151522,.0721750],
                    [.0193339,.1191920,.9503041]], dtype=np.float64)
XYZ_RGB = np.linalg.inv(RGB_XYZ)
WHITE = RGB_XYZ @ np.ones(3)
DELTA = 6 / 29


def srgb_to_linear(rgb):
    v = np.asarray(rgb, dtype=np.float64)
    return np.where(v <= .04045, v / 12.92, ((v + .055) / 1.055) ** 2.4)


def linear_to_srgb(rgb):
    return np.where(rgb <= .0031308, 12.92 * rgb,
                    1.055 * np.maximum(rgb, 0) ** (1 / 2.4) - .055)


def rgb_to_lab(rgb):
    xyz = (srgb_to_linear(rgb) @ RGB_XYZ.T) / WHITE
    f = np.where(xyz > DELTA**3, np.cbrt(xyz), xyz / (3*DELTA**2) + 4/29)
    return np.stack((116*f[...,1]-16, 500*(f[...,0]-f[...,1]),
                     200*(f[...,1]-f[...,2])), axis=-1)


def lab_to_linear(lab):
    fy = (lab[...,0]+16) / 116
    f = np.stack((fy + lab[...,1]/500, fy, fy - lab[...,2]/200), axis=-1)
    xyz = np.where(f > DELTA, f**3, 3*DELTA**2*(f-4/29)) * WHITE
    return xyz @ XYZ_RGB.T


def gamut_rgb(lightness, ab, saturation=1.0):
    """Reduce chroma along a constant hue/L ray; never clip L into gamut."""
    if not 0 <= saturation <= 1.5:
        raise ValueError('Sytost musí být 0–150 %.')
    lab = np.concatenate((lightness[...,None], np.asarray(ab, dtype=np.float64)*saturation), axis=-1)
    lin = lab_to_linear(lab)
    outside = np.any((lin < -1e-10) | (lin > 1+1e-10), axis=-1)
    count = int(outside.sum())
    if count:
        values = lab[outside].copy()
        lo = np.zeros(len(values)); hi = np.ones(len(values))
        for _ in range(22):
            mid = (lo+hi)/2
            trial = values.copy(); trial[:,1:] *= mid[:,None]
            v = lab_to_linear(trial)
            good = np.all((v >= -1e-10) & (v <= 1+1e-10), axis=-1)
            lo = np.where(good, mid, lo); hi = np.where(good, hi, mid)
        values[:,1:] *= lo[:,None]
        lin[outside] = lab_to_linear(values)
    return np.clip(linear_to_srgb(lin), 0, 1).astype(np.float32), count


def guided_filter(guide, chroma, radius=5, epsilon=.0004):
    """Scalar-guide local linear filtering (He et al.); only filter a,b."""
    guide = np.ascontiguousarray(guide, dtype=np.float32)
    p = np.ascontiguousarray(chroma, dtype=np.float32)
    k = (2*radius+1,)*2
    mean = lambda a: cv2.boxFilter(a, -1, k, borderType=cv2.BORDER_REFLECT)
    mean_i = mean(guide); mean_p = mean(p)
    var_i = np.maximum(mean(guide*guide)-mean_i*mean_i, 0)
    cov = mean(guide[...,None]*p)-mean_i[...,None]*mean_p
    coeff = cov/(var_i[...,None]+epsilon)
    bias = mean_p-coeff*mean_i[...,None]
    return np.clip(mean(coeff)*guide[...,None]+mean(bias), -128, 128)


def align_chroma(reference_l, proposal_lab):
    """Conservative global translation, applied to proposal only, never origin."""
    h,w = reference_l.shape
    ref = cv2.GaussianBlur((reference_l/100).astype(np.float32),(0,0),1.2)
    target = cv2.GaussianBlur((proposal_lab[...,0]/100).astype(np.float32),(0,0),1.2)
    def correlation(a,b):
        return float(np.corrcoef(a.ravel(),b.ravel())[0,1]) if a.std() > 1e-5 and b.std() > 1e-5 else 0.
    before = correlation(ref,target)
    info = {'applied':False,'dx':0.,'dy':0.,'correlation_before':before}
    if ref.std() < .01 or target.std() < .01:
        return proposal_lab[...,1:].astype(np.float32), info
    try:
        warp = np.eye(2,3,dtype=np.float32)
        score, warp = cv2.findTransformECC(ref,target,warp,cv2.MOTION_TRANSLATION,
            (cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,60,1e-5),None,5)
        shifted = cv2.warpAffine(proposal_lab,warp,(w,h),
            flags=cv2.INTER_LINEAR|cv2.WARP_INVERSE_MAP,borderMode=cv2.BORDER_REFLECT)
        after = correlation(ref, cv2.GaussianBlur((shifted[...,0]/100).astype(np.float32),(0,0),1.2))
        if score > .7 and after > before+.003 and abs(warp[0,2]) <= w*.025 and abs(warp[1,2]) <= h*.025:
            info.update(applied=True,dx=float(warp[0,2]),dy=float(warp[1,2]),correlation_after=after)
            return shifted[...,1:].astype(np.float32), info
    except cv2.error:
        pass
    return proposal_lab[...,1:].astype(np.float32), info


@dataclass
class ColorMap:
    ab: np.ndarray
    diagnostics: dict


def prepare_colors(original_rgb, proposal_rgb, align=True):
    h,w = proposal_rgb.shape[:2]
    small = cv2.resize(original_rgb,(w,h),interpolation=cv2.INTER_AREA)
    original_lab = rgb_to_lab(small)
    proposal_lab = rgb_to_lab(proposal_rgb)
    ab, registration = align_chroma(original_lab[...,0],proposal_lab) if align else (
        proposal_lab[...,1:].astype(np.float32), {'applied':False})
    guide = (original_lab[...,0]/100).astype(np.float32)
    ab = guided_filter(guide,ab, radius=4)
    from skimage.metrics import structural_similarity
    ssim = float(structural_similarity(original_lab[...,0],proposal_lab[...,0],data_range=100))
    return ColorMap(ab, {'raw_l_ssim':ssim,'alignment':registration,
        'warning': 'Návrh výrazně mění strukturu. Zkontrolujte barevné hranice.' if ssim < .65 else None})


def render_colors(original_rgb, color_map, saturation=1., cancel=None):
    """Joint guided upsampling in overlapping strips; full-resolution original L."""
    h,w = original_rgb.shape[:2]
    small_ab = color_map.ab if isinstance(color_map,ColorMap) else color_map
    # Avoid a full-resolution float64 Lab tensor for high resolution scans.
    ab = cv2.resize(small_ab,(w,h),interpolation=cv2.INTER_LINEAR)
    result = np.empty((h,w,3),dtype=np.float32)
    radius = max(2, min(12, round(w/small_ab.shape[1]*3)))
    halo = 2*radius+2
    max_error = 0.; gamut_count = 0
    for y in range(0,h,192):
        if cancel and cancel():
            raise InterruptedError('Úloha zrušena.')
        start = max(0,y-halo); end = min(h,y+192+halo)
        l = rgb_to_lab(original_rgb[start:end])[...,0]
        filtered = guided_filter((l/100).astype(np.float32),ab[start:end],radius)
        region = slice(y-start,min(y+192,h)-start)
        rgb, compressed = gamut_rgb(l[region],filtered[region],saturation)
        result[y:min(y+192,h)] = rgb
        gamut_count += compressed
        max_error = max(max_error,float(np.max(np.abs(rgb_to_lab(rgb)[...,0]-l[region]))))
    return result, {'max_L_error_float':max_error,'gamut_compressed_pixels':gamut_count,
                    'width':w,'height':h,'saturation':saturation}
