"""Native Qt macOS UI. MLX runs only in a resident child process."""
import json
from pathlib import Path
import sys
import time
import uuid
import numpy as np
from PIL import Image,ImageOps,ImageCms
import io
from PySide6.QtCore import Qt,QProcess,QTimer,QRect,QUrl
from PySide6.QtGui import QImage,QPainter,QColor,QPen,QDesktopServices,QAction
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,
    QLabel,QPushButton,QComboBox,QLineEdit,QPlainTextEdit,QSlider,QProgressBar,QFileDialog,
    QMessageBox,QScrollArea,QTabBar,QFrame)
from .runtime import ROOT,DEFAULT_PROMPT,configure
from .photos import EXTENSIONS


def image_preview(path):
    # GUI uses only a display thumbnail; full precision images live in the worker.
    with Image.open(path) as source:
        if source.width*source.height>80_000_000:raise ValueError('Fotografie přesahuje limit 80 milionů pixelů.')
        source.draft('RGB',(1600,1600))
        im=ImageOps.exif_transpose(source)
        icc=source.info.get('icc_profile')
        im.thumbnail((1600,1600),Image.Resampling.LANCZOS)
        if im.mode.startswith('I'):
            im=Image.fromarray(np.rint(np.clip(np.asarray(im,dtype=np.float32)/65535,0,1)*255).astype(np.uint8))
        if icc and im.mode in ('RGB','CMYK','L'):
            try:im=ImageCms.profileToProfile(im,ImageCms.ImageCmsProfile(io.BytesIO(icc)),ImageCms.createProfile('sRGB'),outputMode='RGB')
            except Exception:im=im.convert('RGB')
        else:im=im.convert('RGB')
        arr=np.ascontiguousarray(im,dtype=np.uint8)
    return QImage(arr.data,arr.shape[1],arr.shape[0],arr.strides[0],QImage.Format.Format_RGB888).copy()


class CompareCanvas(QWidget):
    def __init__(self):
        super().__init__(); self.before=None; self.after=None; self.overlay=False; self.position=.5
        self.setMinimumSize(400,320)
    def paintEvent(self,event):
        painter=QPainter(self); painter.fillRect(self.rect(),QColor('#1c2125'))
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        if self.before is None:
            painter.setPen(QColor('#c4cbd0'))
            painter.drawText(self.rect(),Qt.AlignmentFlag.AlignCenter,'Přetáhněte sem fotografii\nnebo ji otevřete tlačítkem vlevo.')
            return
        def fitted(image,area):
            size=image.size().scaled(area.size(),Qt.AspectRatioMode.KeepAspectRatio)
            return QRect(area.center().x()-size.width()//2,area.center().y()-size.height()//2,size.width(),size.height())
        if self.overlay and self.after is not None:
            area=self.rect().adjusted(16,40,-16,-16); rect=fitted(self.before,area)
            painter.drawImage(rect,self.before)
            x=rect.left()+round(rect.width()*self.position)
            painter.save(); painter.setClipRect(QRect(x,rect.top(),rect.right()-x+1,rect.height()))
            painter.drawImage(rect,self.after); painter.restore()
            painter.setPen(QPen(QColor('#ffffff'),2)); painter.drawLine(x,rect.top(),x,rect.bottom())
            painter.setBrush(QColor('white')); painter.drawEllipse(x-10,rect.center().y()-10,20,20)
            painter.setPen(QColor('#dce1e4'))
            painter.drawText(20,26,'Originál'); painter.drawText(self.width()-115,26,'Kolorováno')
        else:
            half=self.width()//2
            for i,(image,label) in enumerate([(self.before,'Originál'),(self.after,'Kolorováno')]):
                area=QRect(i*half+12,40,half-24,self.height()-56)
                painter.setPen(QColor('#dce1e4')); painter.drawText(i*half+20,26,label)
                if image is not None:painter.drawImage(fitted(image,area),image)
                else:
                    painter.setPen(QColor('#84929b'))
                    painter.drawText(area,Qt.AlignmentFlag.AlignCenter,'Vytvořte barevné varianty.')
    def mousePressEvent(self,event):
        self.mouseMoveEvent(event)
    def mouseMoveEvent(self,event):
        if self.overlay and event.buttons()&Qt.MouseButton.LeftButton:
            self.position=max(0,min(1,event.position().x()/self.width())); self.update()


class Window(QMainWindow):
    def __init__(self):
        super().__init__(); configure()
        self.setWindowTitle('Lokální Kolor'); self.resize(1180,790); self.setMinimumSize(960,680)
        self.setAcceptDrops(True)
        self.source=None; self.variants={}; self.selected=0; self.busy=False; self.batch_mode=False
        self.result_dir=ROOT/'vysledky'; self.result_dir.mkdir(exist_ok=True)
        self.output_buffer=''; self.expected_stop=False; self.current_saturation=1.
        self.process=QProcess(self); self.process.setWorkingDirectory(str(ROOT))
        self.process.readyReadStandardOutput.connect(self.read_output)
        self.process.readyReadStandardError.connect(self.read_errors)
        self.process.finished.connect(self.worker_finished)
        self.process.errorOccurred.connect(self.process_error)
        self.debounce=QTimer(self); self.debounce.setSingleShot(True); self.debounce.setInterval(250)
        self.debounce.timeout.connect(self.update_saturation)
        self.build_ui()
        action=QAction('Otevřít fotografii…',self); action.setShortcut('Ctrl+O'); action.triggered.connect(self.choose_photo)
        self.menuBar().addMenu('Soubor').addAction(action)
        help_menu=self.menuBar().addMenu('Nápověda')
        guide=QAction('Český návod',self); guide.triggered.connect(lambda:QDesktopServices.openUrl(QUrl.fromLocalFile(str(ROOT/'NAVOD.md')))); help_menu.addAction(guide)
        outputs=QAction('Otevřít výsledky',self); outputs.triggered.connect(self.open_results); help_menu.addAction(outputs)

    def build_ui(self):
        central=QWidget(); main=QHBoxLayout(central); main.setContentsMargins(0,0,0,0); main.setSpacing(0); self.setCentralWidget(central)
        scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setFixedWidth(314); scroll.setFrameShape(QFrame.Shape.NoFrame)
        sidebar=QWidget(); layout=QVBoxLayout(sidebar); layout.setContentsMargins(20,20,20,20); layout.setSpacing(10)
        title=QLabel('Lokální Kolor'); title.setStyleSheet('font-size:24px;font-weight:600;'); layout.addWidget(title)
        description=QLabel('Přirozené barvy.\nKresba a jas z originálu.'); description.setStyleSheet('color:#68727b;'); layout.addWidget(description)
        self.open_button=QPushButton('Otevřít fotografii…'); self.open_button.clicked.connect(self.choose_photo); layout.addWidget(self.open_button)
        self.batch_button=QPushButton('Zpracovat složku…'); self.batch_button.clicked.connect(self.choose_batch); layout.addWidget(self.batch_button)
        self.file_label=QLabel('JPEG, PNG nebo TIFF'); self.file_label.setWordWrap(True); self.file_label.setStyleSheet('color:#68727b;font-size:11px;'); layout.addWidget(self.file_label)
        layout.addWidget(QLabel('Velikost barevného návrhu'))
        self.resolution=QComboBox(); self.resolution.addItems(['512 px · doporučeno','768 px','1024 px']); layout.addWidget(self.resolution)
        layout.addWidget(QLabel('Tři seedy'))
        self.seeds=QLineEdit('42, 43, 44'); layout.addWidget(self.seeds)
        layout.addWidget(QLabel('Pokyny a doložené barvy'))
        self.prompt=QPlainTextEdit(DEFAULT_PROMPT); self.prompt.setMinimumHeight(125); self.prompt.setMaximumHeight(170); layout.addWidget(self.prompt)
        self.saturation_label=QLabel('Sytost · 100 %'); layout.addWidget(self.saturation_label)
        self.saturation=QSlider(Qt.Orientation.Horizontal); self.saturation.setRange(0,150); self.saturation.setValue(100)
        self.saturation.valueChanged.connect(self.saturation_changed); layout.addWidget(self.saturation)
        layout.addWidget(QLabel('Barevná varianta'))
        row=QHBoxLayout(); self.variant_buttons=[]
        for index in range(3):
            button=QPushButton(str(index+1)); button.setCheckable(True); button.setEnabled(False)
            button.clicked.connect(lambda checked=False,i=index:self.select_variant(i)); self.variant_buttons.append(button); row.addWidget(button)
        layout.addLayout(row)
        self.generate_button=QPushButton('Vytvořit 3 varianty'); self.generate_button.setDefault(True)
        self.generate_button.clicked.connect(self.generate); layout.addWidget(self.generate_button)
        format_row=QHBoxLayout(); self.format=QComboBox(); self.format.addItems(['PNG · 16 bitů','TIFF · 16 bitů','JPEG · 8 bitů'])
        format_row.addWidget(self.format); self.save_button=QPushButton('Uložit…'); self.save_button.clicked.connect(self.save_selected); self.save_button.setEnabled(False); format_row.addWidget(self.save_button); layout.addLayout(format_row)
        folder=QPushButton('Otevřít výsledky'); folder.clicked.connect(self.open_results); layout.addWidget(folder)
        note=QLabel('Barvy jsou odhad. Doložené barvy oděvů a předmětů doplňte do pokynů. Pro přesný jas ukládejte PNG nebo TIFF.')
        note.setWordWrap(True); note.setStyleSheet('font-size:11px;color:#68727b;'); layout.addWidget(note); layout.addStretch()
        scroll.setWidget(sidebar); main.addWidget(scroll)
        right=QWidget(); body=QVBoxLayout(right); body.setContentsMargins(18,16,18,16); body.setSpacing(12)
        self.tabs=QTabBar(); self.tabs.addTab('Vedle sebe'); self.tabs.addTab('Před / po'); self.tabs.currentChanged.connect(self.change_mode); body.addWidget(self.tabs)
        self.canvas=CompareCanvas(); body.addWidget(self.canvas,1)
        self.compare_slider=QSlider(Qt.Orientation.Horizontal); self.compare_slider.setRange(0,100); self.compare_slider.setValue(50)
        self.compare_slider.valueChanged.connect(self.move_comparison); self.compare_slider.setVisible(False); body.addWidget(self.compare_slider)
        self.status=QLabel('Připraveno · všechny fotografie se zpracovávají v tomto Macu.'); self.status.setWordWrap(True); body.addWidget(self.status)
        bottom=QHBoxLayout(); self.progress=QProgressBar(); self.progress.setRange(0,100); self.progress.setValue(0); self.progress.setTextVisible(False); bottom.addWidget(self.progress,1)
        self.cancel_button=QPushButton('Zrušit'); self.cancel_button.setEnabled(False); self.cancel_button.clicked.connect(self.cancel); bottom.addWidget(self.cancel_button); body.addLayout(bottom)
        main.addWidget(right,1)
        self.controls=[self.open_button,self.batch_button,self.generate_button,self.resolution,self.seeds,self.prompt,self.format,self.saturation]

    def extension(self):return ['.png','.tiff','.jpg'][self.format.currentIndex()]
    def set_busy(self,busy):
        self.busy=busy
        for control in self.controls:control.setEnabled(not busy)
        for index,button in enumerate(self.variant_buttons):button.setEnabled(not busy and index in self.variants)
        self.save_button.setEnabled(not busy and bool(self.variants)); self.cancel_button.setEnabled(busy)
    def choose_photo(self):
        path,_=QFileDialog.getOpenFileName(self,'Otevřít fotografii','','Fotografie (*.jpg *.jpeg *.png *.tif *.tiff)')
        if path:self.open_photo(path)
    def open_photo(self,path):
        if self.busy:return
        try:image=image_preview(path)
        except Exception as exc:self.show_error(str(exc)); return
        self.source=str(Path(path).resolve()); self.file_label.setText(Path(path).name)
        self.canvas.before=image; self.canvas.after=None; self.canvas.update(); self.variants={}; self.selected=0
        self.progress.setValue(0); self.status.setText('Fotografie je otevřená. Vytvořte tři barevné varianty.')
        self.set_busy(False)
    def options(self):
        try:seeds=[int(v.strip()) for v in self.seeds.text().split(',')]
        except ValueError:raise ValueError('Zadejte tři celá čísla oddělená čárkami.')
        if len(seeds)!=3 or len(set(seeds))!=3 or any(not 0<=s<2**32 for s in seeds):
            raise ValueError('Zadejte tři různé seedy od 0 do 4294967295.')
        prompt=self.prompt.toPlainText().strip()
        if not prompt:raise ValueError('Doplňte pokyny pro kolorování.')
        return {'resolution':[512,768,1024][self.resolution.currentIndex()],'seeds':seeds,'prompt':prompt,
                'saturation':self.saturation.value()/100,'extension':self.extension()}
    def ensure_worker(self):
        if self.process.state()==QProcess.ProcessState.NotRunning:
            self.output_buffer=''; self.expected_stop=False
            self.process.start(sys.executable,['-m','kolor.worker'])
            if not self.process.waitForStarted(3000):raise RuntimeError('Výpočetní proces se nepodařilo spustit.')
    def send(self,request):
        try:
            self.ensure_worker(); self.set_busy(True)
            self.process.write((json.dumps(request,ensure_ascii=False)+'\n').encode())
        except Exception as exc:self.set_busy(False); self.show_error(str(exc))
    def generate(self):
        if not self.source:self.choose_photo()
        if not self.source:return
        try:options=self.options()
        except ValueError as exc:self.show_error(str(exc)); return
        self.variants={}; self.canvas.after=None; self.canvas.update(); self.batch_mode=False
        self.job_dir=ROOT/'runtime'/'sessions'/uuid.uuid4().hex
        self.current_saturation=self.saturation.value()/100
        self.send({'action':'colorize','source':self.source,'output_dir':str(self.job_dir),'save_all':False,**options})
    def choose_batch(self):
        try:options=self.options()
        except ValueError as exc:self.show_error(str(exc)); return
        source=QFileDialog.getExistingDirectory(self,'Vyberte složku vstupních fotografií')
        if not source:return
        target=QFileDialog.getExistingDirectory(self,'Vyberte složku pro výsledky',str(self.result_dir))
        if not target:return
        self.result_dir=Path(target); self.batch_mode=True; self.batch_index=0; self.batch_total=1; self.variants={}
        self.send({'action':'batch','input_dir':source,'output_dir':target,**options})
    def select_variant(self,index):
        if self.busy or index not in self.variants:return
        self.selected=index
        for i,button in enumerate(self.variant_buttons):button.setChecked(i==index)
        variant=self.variants[index]
        if self.saturation.value()/100==variant.get('preview_saturation',1.):
            self.canvas.after=image_preview(variant['preview']); self.canvas.update()
        else:self.update_saturation()
    def saturation_changed(self,value):
        self.saturation_label.setText(f'Sytost · {value} %')
        if self.variants and not self.busy:self.debounce.start()
    def update_saturation(self):
        if self.busy or self.selected not in self.variants:return
        self.send({'action':'render','variant':self.selected,'saturation':self.saturation.value()/100,
                   'output_dir':str(self.result_dir),'preview_only':True})
    def save_selected(self):
        target=QFileDialog.getExistingDirectory(self,'Uložit kolorovanou fotografii',str(self.result_dir))
        if not target:return
        self.result_dir=Path(target)
        self.send({'action':'render','variant':self.selected,'saturation':self.saturation.value()/100,
                   'output_dir':target,'extension':self.extension()})
    def open_results(self):QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.result_dir)))
    def change_mode(self,index):
        self.canvas.overlay=index==1; self.canvas.update(); self.compare_slider.setVisible(index==1)
    def move_comparison(self,value):self.canvas.position=value/100; self.canvas.update()
    def read_errors(self):
        data=bytes(self.process.readAllStandardError())
        with (ROOT/'runtime'/'worker.log').open('ab') as f:f.write(data)
    def read_output(self):
        self.output_buffer+=bytes(self.process.readAllStandardOutput()).decode('utf-8',errors='replace')
        while '\n' in self.output_buffer:
            line,self.output_buffer=self.output_buffer.split('\n',1)
            if line.startswith('KOLOR:'):
                try:self.handle_event(json.loads(line[6:]))
                except Exception as exc:self.show_error('Chyba zobrazení výsledku: '+str(exc)); self.set_busy(False)
    def handle_event(self,event):
        kind=event['type']
        if kind=='progress':
            fraction=event.get('fraction',0)
            if self.batch_mode:fraction=(self.batch_index+fraction)/self.batch_total
            self.progress.setValue(round(fraction*100)); self.status.setText(event['text'])
        elif kind=='batch_progress':
            self.batch_index=event['index']; self.batch_total=event['total']; self.variants={}; self.source=event['file']
            try:self.canvas.before=image_preview(event['file'])
            except Exception:self.canvas.before=None
            self.canvas.after=None; self.canvas.update(); self.file_label.setText(Path(event['file']).name)
        elif kind=='variant':
            self.variants[event['variant']]={**event,'preview_saturation':self.saturation.value()/100}
            self.variant_buttons[event['variant']].setToolTip(f"Seed {event['stats']['seed']} · {event['stats']['generation_seconds']:.1f} s")
            if event['variant']==0:
                self.selected=0; self.canvas.after=image_preview(event['preview']); self.canvas.update()
        elif kind in {'done','batch_done'}:
            self.set_busy(False); self.progress.setValue(100)
            if kind=='batch_done':
                if self.variants:self.select_variant(0)
                self.status.setText(f'Dávka dokončena: {event["completed"]} fotografií, chyb: {len(event["errors"])}. Výsledky: {self.result_dir}')
                if event['errors']:self.show_error('\n'.join(Path(e['source']).name+': '+e['message'] for e in event['errors']))
            else:
                self.current_saturation=self.saturation.value()/100; self.select_variant(0)
                self.status.setText('Tři varianty jsou připravené. Vyberte barvy, upravte sytost a uložte výsledek.')
        elif kind=='preview':
            self.canvas.after=image_preview(event['path']); self.canvas.update(); self.set_busy(False)
            # This preview belongs only to this variant and this saturation.
            self.variants[self.selected]['preview']=event['path']
            self.variants[self.selected]['preview_saturation']=event['saturation']
            self.status.setText(f'Sytost upravena na {round(event["saturation"]*100)} %.')
        elif kind=='saved':
            self.set_busy(False); self.status.setText('Uloženo: '+event['path'])
        elif kind=='error':
            self.set_busy(False); self.status.setText('Úloha se nepodařila.'); self.show_error(event['message'])
    def cancel(self):
        self.debounce.stop(); self.expected_stop=True; self.process.kill(); self.process.waitForFinished(2000)
        self.variants={}; self.set_busy(False); self.progress.setValue(0)
        self.status.setText('Úloha byla zrušena. Rozpracovaná fotografie se neuloží; hotové soubory zůstávají zachované.')
    def worker_finished(self,code,status):
        if self.busy and not self.expected_stop:
            self.set_busy(False); self.show_error('Výpočetní proces byl ukončen. Podrobnosti jsou v runtime/worker.log. Zkuste menší rozlišení.')
    def process_error(self,error):
        if error==QProcess.ProcessError.FailedToStart:self.set_busy(False); self.show_error('Výpočetní proces nelze spustit.')
    def show_error(self,message):QMessageBox.warning(self,'Lokální Kolor',message)
    def dragEnterEvent(self,event):
        if not self.busy and event.mimeData().hasUrls():event.acceptProposedAction()
    def dropEvent(self,event):
        paths=[u.toLocalFile() for u in event.mimeData().urls() if Path(u.toLocalFile()).suffix.lower() in EXTENSIONS]
        if paths:self.open_photo(paths[0]); event.acceptProposedAction()
    def closeEvent(self,event):
        self.expected_stop=True; self.process.kill(); self.process.waitForFinished(1500); event.accept()


def main():
    app=QApplication(sys.argv); app.setApplicationName('Lokální Kolor'); app.setOrganizationName('Lokální Kolor')
    window=Window(); window.show()
    for arg in sys.argv[1:]:
        if Path(arg).is_file() and Path(arg).suffix.lower() in EXTENSIONS:window.open_photo(arg); break
    sys.exit(app.exec())

if __name__=='__main__':main()
