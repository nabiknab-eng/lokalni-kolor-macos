"""Profile-aware input and exclusive, atomic output publication."""
import io
import os
from pathlib import Path
import struct
import tempfile
import zlib
import cv2
import numpy as np
from PIL import Image, ImageCms, ImageOps
import tifffile

EXTENSIONS = {'.jpg','.jpeg','.png','.tif','.tiff'}
SRGB_PROFILE = ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()


def load_photo(path):
    path = Path(path)
    if path.suffix.lower() not in EXTENSIONS:
        raise ValueError('Podporované formáty jsou JPEG, PNG a TIFF.')
    with Image.open(path) as im:
        if getattr(im,'n_frames',1) != 1:
            raise ValueError('Vícestránkový TIFF není podporován. Vyexportujte jednotlivé snímky.')
        if im.width*im.height > 80_000_000:
            raise ValueError('Fotografie přesahuje limit 80 milionů pixelů pro 16 GB RAM.')
        if 'A' in im.getbands() and im.getextrema()[-1][0] < 255:
            raise ValueError('Průhledné fotografie nejprve slučte s pozadím.')
        orientation = im.getexif().get(274,1)
        icc = im.info.get('icc_profile')
        raw = cv2.imdecode(np.frombuffer(path.read_bytes(),np.uint8),cv2.IMREAD_UNCHANGED)
        if raw is not None and raw.dtype == np.uint16:
            if icc:
                desc = ImageCms.getProfileDescription(ImageCms.ImageCmsProfile(io.BytesIO(icc))).strip()
                if 'srgb' not in desc.lower():
                    raise ValueError('16bitový vstup s jiným ICC profilem převeďte do sRGB v editoru s 16bitovou správou barev.')
            arr = raw.astype(np.float32)/65535
            if arr.ndim == 2:
                arr = np.repeat(arr[...,None],3,axis=-1)
            elif arr.shape[-1] == 4:
                if np.min(arr[...,3]) < 1:
                    raise ValueError('Průhledné fotografie nejprve slučte s pozadím.')
                arr = arr[...,:3][...,::-1].copy()
            else:
                arr = arr[...,:3][...,::-1].copy()
            # Apply EXIF orientation without quantizing 16-bit samples.
            if orientation == 2: arr = arr[:,::-1]
            elif orientation == 3: arr = arr[::-1,::-1]
            elif orientation == 4: arr = arr[::-1]
            elif orientation == 5: arr = arr.transpose(1,0,2)
            elif orientation == 6: arr = np.rot90(arr,3)
            elif orientation == 7: arr = arr.transpose(1,0,2)[::-1,::-1]
            elif orientation == 8: arr = np.rot90(arr,1)
            return np.ascontiguousarray(arr)
        im = ImageOps.exif_transpose(im)
        if icc:
            try:
                im = ImageCms.profileToProfile(im,ImageCms.ImageCmsProfile(io.BytesIO(icc)),
                    ImageCms.createProfile('sRGB'),outputMode='RGB',renderingIntent=1)
            except Exception as exc:
                raise ValueError('Vstupní ICC profil nelze bezpečně převést do sRGB.') from exc
        else:
            im = im.convert('RGB')
        return np.asarray(im,dtype=np.float32)/255


def _png16(rgb):
    data = np.rint(np.clip(rgb,0,1)*65535).astype(np.uint16)
    ok, encoded = cv2.imencode('.png',np.ascontiguousarray(data[...,::-1]),[cv2.IMWRITE_PNG_COMPRESSION,4])
    if not ok: raise OSError('PNG se nepodařilo zapsat.')
    blob = encoded.tobytes()
    payload = b'sRGB IEC61966-2.1\x00\x00'+zlib.compress(SRGB_PROFILE)
    chunk = b'iCCP'+payload
    chunk = struct.pack('>I',len(payload))+chunk+struct.pack('>I',zlib.crc32(chunk)&0xffffffff)
    return blob[:33]+chunk+blob[33:]


def save_photo(rgb, source, directory, extension='.png', suffix='_kolor'):
    """Create unique name; even a racing writer can never replace an existing file."""
    source = Path(source).resolve()
    directory = Path(directory).resolve(); directory.mkdir(parents=True,exist_ok=True)
    extension = extension.lower()
    if extension not in EXTENSIONS: raise ValueError('Nepodporovaný formát výstupu.')
    if extension in {'.jpg','.jpeg'}:
        b = io.BytesIO()
        Image.fromarray(np.rint(np.clip(rgb,0,1)*255).astype(np.uint8)).save(
            b,format='JPEG',quality=98,subsampling=0,icc_profile=SRGB_PROFILE)
        blob = b.getvalue()
    elif extension == '.png':
        blob = _png16(rgb)
    else:
        b = io.BytesIO()
        tifffile.imwrite(b,np.rint(np.clip(rgb,0,1)*65535).astype(np.uint16),
            photometric='rgb',metadata=None,extratags=[(34675,'B',len(SRGB_PROFILE),SRGB_PROFILE,False)])
        blob = b.getvalue()
    fd,tmp = tempfile.mkstemp(prefix='.kolor-',dir=directory)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(blob); f.flush(); os.fsync(f.fileno())
        for index in range(100000):
            stem = source.stem+suffix+(f'_{index+1}' if index else '')
            candidate = directory/(stem+extension)
            if candidate.resolve() == source: continue
            try:
                os.link(tmp,candidate)  # atomic no-clobber publication on the same filesystem
                return candidate
            except FileExistsError:
                continue
        raise OSError('Nepodařilo se najít volný název souboru.')
    finally:
        Path(tmp).unlink(missing_ok=True)
