"""Lokální Kolor — barevný návrh MLX + přenos chromatičnosti."""
__version__ = '1.1.0'
