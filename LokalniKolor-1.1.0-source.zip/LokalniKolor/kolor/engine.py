"""Verified MFLUX 0.23.0 API; native Qwen3 encoder, resident 4bit weights."""
import gc
import json
import os
from pathlib import Path
import tempfile
import threading
import time
import cv2
import numpy as np
import psutil
from PIL import Image
from .runtime import configure, ROOT, MODEL_PATH, MODEL_REPO, MODEL_REVISION, DEFAULT_PROMPT
from .color import rgb_to_lab, gamut_rgb, prepare_colors, render_colors
from .photos import load_photo, save_photo
from .package_info import package_version


class RSSMonitor:
    def __enter__(self):
        self.peak = psutil.Process().memory_info().rss
        self.stop = threading.Event()
        def sample():
            while not self.stop.wait(.05):
                self.peak = max(self.peak,psutil.Process().memory_info().rss)
        self.thread = threading.Thread(target=sample,daemon=True); self.thread.start()
        return self
    def __exit__(self,*args):
        self.peak = max(self.peak,psutil.Process().memory_info().rss)
        self.stop.set(); self.thread.join()


class Engine:
    def __init__(self, emit=None):
        configure()
        self.emit = emit or (lambda event: None)
        self.model = None
        self.preview_maps = []
        self.original = None
        self.source = None
        self.load_stats = {}

    def load(self):
        if self.model is not None: return
        if not (MODEL_PATH/'REVISION.json').exists():
            raise FileNotFoundError('Model není kompletní. Spusťte Instalovat.command pro stažení a ověření vah.')
        self.emit({'type':'progress','fraction':0.,'text':'Načítám 4bitový FLUX.2 Klein do Metal GPU…'})
        started = time.perf_counter()
        import mlx.core as mx
        if not mx.metal.is_available():
            raise RuntimeError('Metal GPU není dostupné. Spusťte aplikaci přímo na Apple Silicon Macu.')
        mx.set_default_device(mx.gpu)
        mx.set_cache_limit(256*1024**2)
        mx.set_memory_limit(9*1024**3)
        from mflux.models.common.config import ModelConfig
        from mflux.models.flux2.variants import Flux2KleinEdit
        from mflux.callbacks.instances.memory_saver import MemorySaver
        with RSSMonitor() as monitor:
            class ResidentEdit(Flux2KleinEdit):
                def _encode_prompt_pair(self, **kwargs):
                    key=(kwargs['prompt'],kwargs.get('negative_prompt'),kwargs['guidance'])
                    if getattr(self,'_encoded_key',None)==key:
                        return self._encoded_pair
                    pair=super()._encode_prompt_pair(**kwargs)
                    mx.eval([value for value in pair if value is not None])
                    self._encoded_key=key; self._encoded_pair=pair
                    self.text_encoder=None
                    gc.collect(); mx.clear_cache()
                    return pair
            candidate = ResidentEdit(model_config=ModelConfig.flux2_klein_4b(),
                                       model_path=str(MODEL_PATH), quantize=4)
            candidate.callbacks.register(MemorySaver(model=candidate,keep_transformer=True,
                keep_text_encoder=True,num_seeds=3,cache_limit_bytes=256*1024**2))
            # Explicitly evaluate lazy loaded weights before timing inference.
            mx.eval(candidate.parameters())
        mlx_version, mlx_version_source = package_version('mlx')
        mflux_version, mflux_version_source = package_version('mflux')
        stats = {'load_seconds':time.perf_counter()-started,
            'load_peak_rss_bytes':monitor.peak,'device':str(mx.default_device()),
            'metal_available':mx.metal.is_available(),'metal_device':dict(mx.device_info()),
            'mlx_version':mlx_version,'mlx_version_source':mlx_version_source,
            'mflux_version':mflux_version,'mflux_version_source':mflux_version_source,
            'model_repo':MODEL_REPO,'model_revision':MODEL_REVISION,'quantization_bits':candidate.bits,'prompt_cache_low_ram':True,'mflux_commit':'a3b21fcaa88726b2267bd42bfc2e2d722f7d5a47'}
        # Publish ready state only after initialization and diagnostics finish.
        self.load_stats = stats
        self.model = candidate
        self.emit({'type':'loaded',**self.load_stats})

    def colorize(self, source, output_dir, resolution=512, seeds=(42,43,44), prompt=DEFAULT_PROMPT,
                 saturation=1., extension='.png', save_all=True):
        if resolution not in (512,768,1024): raise ValueError('Rozlišení musí být 512, 768 nebo 1024.')
        if not prompt.strip(): raise ValueError('Prompt nesmí být prázdný.')
        if not seeds or len(seeds)>3 or len(set(seeds))!=len(seeds):
            raise ValueError('Zvolte jeden až tři různé seedy.')
        if not all(isinstance(s,int) and 0 <= s < 2**32 for s in seeds):
            raise ValueError('Seed musí být celé číslo od 0 do 4294967295.')
        self.original = load_photo(source); self.source = str(Path(source).resolve())
        self.preview_maps = []
        output_dir = Path(output_dir); output_dir.mkdir(parents=True,exist_ok=True)
        if self.model is not None and self.model.text_encoder is None:
            if getattr(self.model,'_encoded_key',(None,))[0]!=prompt:
                # A changed prompt needs the native encoder again. Reinitialize
                # only in this case, never between photos sharing the prompt.
                self.model=None
                gc.collect()
                import mlx.core as mx
                mx.clear_cache()
        self.load()
        import mlx.core as mx
        h,w = self.original.shape[:2]
        scale = min(resolution/w,resolution/h)
        rw,rh = max(16,round(w*scale)),max(16,round(h*scale))
        pw,ph = ((rw+15)//16)*16,((rh+15)//16)*16
        small = cv2.resize(self.original,(rw,rh),interpolation=cv2.INTER_AREA if scale<1 else cv2.INTER_LINEAR)
        neutral,_ = gamut_rgb(rgb_to_lab(small)[...,0],np.zeros_like(small[...,:2]))
        reference = np.pad(neutral,((0,ph-rh),(0,pw-rw),(0,0)),mode='edge')
        results = []
        with tempfile.TemporaryDirectory(prefix='reference-',dir=ROOT/'runtime') as temp:
            ref = Path(temp)/'reference.png'
            Image.fromarray(np.rint(reference*255).astype(np.uint8)).save(ref)
            for index,seed in enumerate(seeds):
                self.emit({'type':'progress','fraction':index/len(seeds),
                    'text':f'Barevný návrh {index+1}/{len(seeds)}, seed {seed}…'})
                mx.clear_cache(); mx.reset_peak_memory(); gc.collect()
                started = time.perf_counter()
                engine = self
                class Progress:
                    def call_in_loop(self, t, **kwargs):
                        engine.emit({'type':'progress','fraction':(index+.1+.7*(int(t)+1)/4)/len(seeds),
                            'text':f'Varianta {index+1}/{len(seeds)} · krok {int(t)+1}/4'})
                callback = Progress(); self.model.callbacks.register(callback)
                try:
                    with RSSMonitor() as monitor:
                        generated = self.model.generate_image(seed=seed,prompt=prompt,num_inference_steps=4,
                            width=pw,height=ph,guidance=1.,image_paths=[str(ref)])
                        mx.synchronize()
                    generation_seconds = time.perf_counter()-started
                    peak = mx.get_peak_memory()
                finally:
                    self.model.callbacks.in_loop.remove(callback)
                proposal = np.asarray(generated.image.convert('RGB'),dtype=np.float32)[:rh,:rw]/255
                raw_path = save_photo(proposal,source,output_dir,'.png',f'_flux_seed{seed}')
                color_map = prepare_colors(self.original,proposal)
                self.preview_maps.append(color_map)
                self.emit({'type':'progress','fraction':(index+.85)/len(seeds),'text':'Přenáším pouze barvy v původním rozlišení…'})
                final_started = time.perf_counter()
                final, metrics = render_colors(self.original,color_map,saturation)
                final_path = save_photo(final,source,output_dir,extension,
                    '_kolor' if index==0 else f'_kolor_v{index+1}') if save_all else None
                # Small lossless preview for GUI; full source/map stay in resident worker.
                size = (min(1400,w),max(1,round(h*min(1400,w)/w)))
                preview = cv2.resize(final,size,interpolation=cv2.INTER_AREA)
                preview_path = save_photo(preview,source,output_dir,'.png',f'_nahled_v{index+1}')
                stats = {'seed':seed,'resolution':resolution,'inference_width':pw,'inference_height':ph,
                    'generation_seconds':generation_seconds,'transfer_seconds':time.perf_counter()-final_started,
                    'mlx_peak_bytes':peak,'rss_peak_bytes':monitor.peak,**metrics,**color_map.diagnostics}
                entry = {'variant':index,'raw':str(raw_path),'final':str(final_path) if final_path else None,
                         'preview':str(preview_path),'stats':stats}
                results.append(entry)
                self.emit({'type':'variant',**entry})
                del generated,proposal,final
                mx.clear_cache()
        report = {'source':self.source,'prompt':prompt,'saturation':saturation,
            'load':self.load_stats,'variants':results,'offline':True}
        self._save_json_unique(output_dir,Path(source).stem+'_mereni',report)
        self.emit({'type':'done','results':results})
        return report

    def render(self, variant, saturation, output_dir, extension='.png', preview_only=False):
        if not 0 <= variant < len(self.preview_maps): raise ValueError('Varianta není připravena.')
        final,stats = render_colors(self.original,self.preview_maps[variant],saturation)
        if preview_only:
            h,w = final.shape[:2]
            size = (min(1400,w),max(1,round(h*min(1400,w)/w)))
            preview = cv2.resize(final,size,interpolation=cv2.INTER_AREA)
            # A replaceable preview lives only in runtime, never among originals/results.
            path = ROOT/'runtime'/f'preview_v{variant}.png'
            Image.fromarray(np.rint(preview*255).astype(np.uint8)).save(path)
        else:
            path = save_photo(final,self.source,output_dir,extension)
        event = {'type':'preview' if preview_only else 'saved','path':str(path),'stats':stats,
                 'variant':variant,'saturation':saturation}
        self.emit(event)
        return event

    @staticmethod
    def _save_json_unique(directory,stem,value):
        for i in range(100000):
            target = directory/(stem+(f'_{i+1}' if i else '')+'.json')
            try:
                with target.open('x') as out: json.dump(value,out,ensure_ascii=False,indent=2)
                return target
            except FileExistsError: continue
