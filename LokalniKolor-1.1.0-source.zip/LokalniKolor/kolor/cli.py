"""Optional CLI for repeatable checks; the .app is the normal entry point."""
import argparse
import json
from pathlib import Path
from .runtime import DEFAULT_PROMPT

def main():
    p=argparse.ArgumentParser(description='Lokální kolorování přes Metal; žádné cloudové API.')
    p.add_argument('source',type=Path); p.add_argument('--output',type=Path,required=True)
    p.add_argument('--resolution',type=int,choices=[512,768,1024],default=512)
    p.add_argument('--seeds',type=int,nargs='+',default=[42,43,44]); p.add_argument('--saturation',type=float,default=1.)
    p.add_argument('--prompt',default=DEFAULT_PROMPT); p.add_argument('--format',choices=['png','jpg','tiff'],default='png')
    a=p.parse_args()
    from .engine import Engine
    def emit(event):print(json.dumps(event,ensure_ascii=False),flush=True)
    engine=Engine(emit)
    options={'resolution':a.resolution,'seeds':a.seeds,'prompt':a.prompt,'saturation':a.saturation,'extension':'.'+a.format}
    if a.source.is_dir():
        from .batch import run_batch
        result=run_batch(engine,a.source,a.output,emit=emit,**options)
        engine._save_json_unique(a.output,'davka',result)
        if result['errors']:raise SystemExit(1)
    else:engine.colorize(a.source,a.output,**options)

if __name__=='__main__':main()
