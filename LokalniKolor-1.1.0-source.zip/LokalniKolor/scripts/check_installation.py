"""Quick diagnostics, no inference or network requests."""
from pathlib import Path
import argparse
import json
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from kolor.runtime import configure,ROOT,MODEL_PATH
configure()


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--skip-model',action='store_true');args=parser.parse_args()
    from importlib.metadata import version
    import cv2,numpy,PIL,PySide6,psutil,jinja2
    import mlx.core as mx
    from mflux.models.flux2.variants import Flux2KleinEdit
    if not mx.metal.is_available():raise RuntimeError('Apple Metal GPU není dostupné.')
    if psutil.virtual_memory().total<15*1024**3:raise RuntimeError('Tato sestava je připravena pro 16 GB RAM nebo více.')
    mx.set_default_device(mx.gpu)
    matrix=mx.ones((32,32));result=matrix@matrix;mx.eval(result)
    assert result[0,0].item()==32
    if not args.skip_model and not (MODEL_PATH/'REVISION.json').exists():raise RuntimeError('Nejsou nainstalované váhy modelu.')
    info={'metal':True,'device':mx.device_info()['device_name'],'python':sys.version.split()[0],
        'mflux':version('mflux'),'mlx':version('mlx'),'model_present':(MODEL_PATH/'REVISION.json').exists()}
    print(json.dumps(info,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':main()
