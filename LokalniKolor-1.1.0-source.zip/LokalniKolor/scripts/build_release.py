"""Build a clean macOS arm64 installer ZIP on macOS or Linux, no model/user data."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

ROOT=Path(__file__).resolve().parents[1]
VERSION='1.1.0'
FOLDERS=['kolor','tests','vendor','scripts','modely','Lokální Kolor.app']
FILES=['bootstrap.py','Instalovat.command','Spustit.command','Diagnostika.command',
       'README.md','INSTALACE.md','NAVOD.md','NASTAVENI.md','SHRNUTI.md','THIRD-PARTY.md',
       'requirements.lock','pytest.ini','.gitignore']


def digest(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def main():
    p=argparse.ArgumentParser();p.add_argument('--cache',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--offline',action='store_true');p.add_argument('--source-only',action='store_true');a=p.parse_args();a.cache.mkdir(parents=True,exist_ok=True);a.output.mkdir(parents=True,exist_ok=True)
    pin=json.loads((ROOT/'scripts/python-runtime.json').read_text())
    if not a.source_only:
        runtime=a.cache/'python-runtime.tar.gz'
        if not runtime.exists() or digest(runtime)!=pin['sha256']:
            if a.offline:raise RuntimeError('Pinned Python runtime missing from offline cache')
            print('Downloading pinned CPython runtime',flush=True)
            urllib.request.urlretrieve(pin['url'],runtime)
        if digest(runtime)!=pin['sha256']:raise RuntimeError('Python runtime SHA-256 mismatch')
        wheels=a.cache/'wheelhouse';wheels.mkdir(exist_ok=True)
        subprocess.run([sys.executable,'-m','pip','download','--no-deps','--only-binary=:all:',
            '--platform','macosx_26_0_arm64','--python-version','312','--implementation','cp','--abi','cp312',
            '--dest',str(wheels),*(['--no-index','--find-links',str(wheels)] if a.offline else []),'-r',str(ROOT/'requirements.lock')],check=True)
    with tempfile.TemporaryDirectory(prefix='kolor-release-',dir=a.cache) as temp:
        stage=Path(temp)/'LokalniKolor';stage.mkdir()
        for folder in FOLDERS:
            shutil.copytree(ROOT/folder,stage/folder,ignore=shutil.ignore_patterns('__pycache__','.DS_Store','flux2-klein-4b-4bit'))
        for name in FILES:shutil.copy2(ROOT/name,stage/name)
        for path in stage.rglob('*'):
            if path.name.endswith('.command') or path.name=='LokalniKolor':path.chmod(0o755)
        if not a.source_only:
            shutil.copy2(runtime,stage/'vendor/python-runtime.tar.gz')
            shutil.copytree(wheels,stage/'wheelhouse')
            manifest={'version':VERSION,'files':{str(path.relative_to(stage)):digest(path)
                for folder in ['vendor','wheelhouse'] for path in sorted((stage/folder).rglob('*')) if path.is_file()}}
            (stage/'bundle-manifest.json').write_text(json.dumps(manifest,indent=2))
        filename=f'LokalniKolor-{VERSION}-'+('source.zip' if a.source_only else 'macOS-arm64.zip')
        output=a.output/filename
        with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as archive:
            for path in sorted(stage.rglob('*')):
                if path.is_file():archive.write(path,path.relative_to(stage.parent))
        checksum=digest(output)
        output.with_suffix('.zip.sha256').write_text(f'{checksum}  {output.name}\n')
        print(json.dumps({'file':str(output),'bytes':output.stat().st_size,'sha256':checksum}),flush=True)

if __name__=='__main__':main()
