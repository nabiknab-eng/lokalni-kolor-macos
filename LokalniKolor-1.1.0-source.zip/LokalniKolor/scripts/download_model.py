"""Pinned public weights, resumable downloads, SHA-256 and optional offline check."""
import argparse
import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT=Path(__file__).resolve().parents[1]
REPO='mlx-community/flux2-klein-4b-4bit'
REVISION='860e87183ceb29e39627c0612ebd66d8ea66e68c'
TARGET=ROOT/'modely/flux2-klein-4b-4bit'


def valid(entry,target):
    path=target/entry['path']
    if not path.is_file() or path.stat().st_size!=entry['size']:return False
    expected=entry.get('lfs',{}).get('oid')
    if expected:
        with path.open('rb') as stream:
            if hashlib.file_digest(stream,'sha256').hexdigest()!=expected:return False
    return True


def fetch(entry,target,offline=False):
    relative=entry['path'];destination=target/relative
    if valid(entry,target):print('Ověřeno:',relative,flush=True);return
    if offline:raise RuntimeError('Chybějící nebo poškozená offline váha: '+relative)
    destination.parent.mkdir(parents=True,exist_ok=True)
    partial=destination.with_name(destination.name+'.part')
    if partial.exists() and partial.stat().st_size>=entry['size']:partial.unlink()
    print('Stahuji:',relative,flush=True)
    subprocess.run(['curl','--fail','--location','--retry','4','--retry-delay','3',
        '--connect-timeout','30','--speed-time','120','--speed-limit','1024',
        '--silent','--show-error','--continue-at','-',
        f'https://huggingface.co/{REPO}/resolve/{REVISION}/{relative}',
        '--output',str(partial)],check=True)
    if partial.stat().st_size!=entry['size']:raise RuntimeError('Nesprávná velikost: '+relative)
    expected=entry.get('lfs',{}).get('oid')
    if expected:
        with partial.open('rb') as stream:
            if hashlib.file_digest(stream,'sha256').hexdigest()!=expected:
                partial.unlink();raise RuntimeError('Nesprávný SHA-256: '+relative)
    partial.replace(destination)
    print('Staženo a ověřeno:',relative,flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--offline',action='store_true');args=parser.parse_args()
    entries=json.loads((Path(__file__).parent/'model-manifest.json').read_text())
    entries=[e for e in entries if e['type']=='file' and e['path']!='.DS_Store']
    total=sum(e['size'] for e in entries)
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        futures=[pool.submit(fetch,e,TARGET,args.offline) for e in entries]
        pending=set(futures)
        while pending:
            done,pending=concurrent.futures.wait(pending,timeout=5)
            for future in done:future.result()
            if pending:
                current=0
                for entry in entries:
                    path=TARGET/entry['path'];partial=path.with_name(path.name+'.part')
                    for candidate in (path,partial):
                        if candidate.exists():current+=min(candidate.stat().st_size,entry['size']);break
                print(f'Model: {current/1e9:.2f} / {total/1e9:.2f} GB ({100*current/total:.0f} %)',flush=True)
    (TARGET/'REVISION.json').write_text(json.dumps({'repo':REPO,'revision':REVISION},indent=2))
    print('Model je kompletní. Další používání je offline.',flush=True)

if __name__=='__main__':main()
