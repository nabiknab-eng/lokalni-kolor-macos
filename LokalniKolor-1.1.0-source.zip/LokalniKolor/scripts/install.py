"""Install into this portable folder, without admin rights or system Python."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]


def sha256(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source,'sha256').hexdigest()


def verify_payload(root):
    manifest=root/'bundle-manifest.json'
    if not manifest.exists():return  # Source checkout uses the normal online pip installer.
    for relative,expected in json.loads(manifest.read_text())['files'].items():
        path=root/relative
        if Path(relative).is_absolute() or '..' in Path(relative).parts:
            raise ValueError('Neplatná cesta v instalačním manifestu.')
        if not path.is_file() or sha256(path)!=expected:
            raise RuntimeError(f'Poškozený instalační soubor: {relative}. Stáhněte ZIP znovu.')


def run(command,**kwargs):
    subprocess.run([str(v) for v in command],check=True,cwd=ROOT,**kwargs)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--offline',action='store_true',help='Nepovolí pip ani modelu stahování.')
    parser.add_argument('--skip-model',action='store_true',help='Vývojový režim: neinstaluje váhy.')
    parser.add_argument('--no-launch',action='store_true')
    args=parser.parse_args()
    if platform.system()!='Darwin' or platform.machine()!='arm64':
        raise RuntimeError('Je potřeba macOS na Apple Silicon.')
    if int(platform.mac_ver()[0].split('.')[0])<26:
        raise RuntimeError('Je potřeba macOS 26 nebo novější.')
    print('1/5 Ověřuji instalační balíček…',flush=True)
    verify_payload(ROOT)
    pin=json.loads((ROOT/'vendor/MFLUX-REVISION.json').read_text())
    wheel=ROOT/'vendor/mflux-0.23.0-py3-none-any.whl'
    if sha256(wheel)!=pin['wheel_sha256']:raise RuntimeError('Kontrolní součet MFLUX nesouhlasí.')
    if not (ROOT/'modely/flux2-klein-4b-4bit/REVISION.json').exists() and not args.skip_model:
        if shutil.disk_usage(ROOT).free<8*1024**3:raise RuntimeError('Uvolněte alespoň 8 GiB místa na disku.')
    print('2/5 Připravuji izolované prostředí Pythonu…',flush=True)
    python=ROOT/'.venv/bin/python'
    if not python.exists():run([sys.executable,'-m','venv',ROOT/'.venv'])
    run([sys.executable,ROOT/'bootstrap.py','--repair-only'])
    print('3/5 Instaluji přesně připnuté knihovny…',flush=True)
    options=['--no-index','--find-links',ROOT/'wheelhouse'] if (ROOT/'wheelhouse').is_dir() else []
    if args.offline and not options:raise RuntimeError('Offline instalace vyžaduje přibalenou složku wheelhouse.')
    run([python,'-m','pip','install','--no-deps',*options,'-r',ROOT/'requirements.lock'])
    run([python,'-m','pip','install','--no-index','--no-deps','--force-reinstall',wheel])
    print('4/5 Ověřuji Metal GPU a knihovny…',flush=True)
    run([python,ROOT/'scripts/check_installation.py','--skip-model'])
    print('5/5 Připravuji model FLUX.2 Klein 4B…',flush=True)
    if not args.skip_model:
        run([python,ROOT/'scripts/download_model.py',*(['--offline'] if args.offline else [])])
    state={'version':'1.1.0','python':sys.version.split()[0],'platform':platform.platform(),
           'installed_at':time.strftime('%Y-%m-%dT%H:%M:%S%z'),'model_installed':not args.skip_model}
    (ROOT/'runtime/installation.json').write_text(json.dumps(state,ensure_ascii=False,indent=2))
    print('\nInstalace je dokončena. Spouštějte Lokální Kolor.app dvojklikem.\nVáhy ani knihovny už při běžném použití internet nepotřebují.',flush=True)
    if not args.no_launch and not args.skip_model:run(['open',ROOT/'Lokální Kolor.app'])


if __name__=='__main__':
    try:main()
    except (Exception,KeyboardInterrupt) as exc:
        print('\nInstalace nebyla dokončena: '+str(exc),file=sys.stderr,flush=True)
        if sys.stdin.isatty():input('Stiskněte Enter pro zavření…')
        raise SystemExit(1)
