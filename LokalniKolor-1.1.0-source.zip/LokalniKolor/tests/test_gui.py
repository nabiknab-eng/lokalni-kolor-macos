import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import numpy as np
from PIL import Image
from PySide6.QtWidgets import QApplication
from kolor.gui import Window,image_preview
from kolor.runtime import ROOT

APP=QApplication.instance() or QApplication([])


def test_display_16bit_gray_does_not_clip_to_white(tmp_path):
    path=tmp_path/'gray.tiff'
    Image.fromarray(np.full((40,40),32768,np.uint16)).save(path)
    image=image_preview(path)
    assert 126 <= image.pixelColor(10,10).red() <= 129


def test_variant_saturation_cache_is_independent(tmp_path):
    window=Window(); requests=[]; window.send=lambda r: requests.append(r)
    path=tmp_path/'preview.png'; Image.new('RGB',(40,40),'gray').save(path)
    fixture=str(path)
    window.variants={0:{'preview':fixture,'preview_saturation':1.},
                     1:{'preview':fixture,'preview_saturation':.8}}
    window.saturation.setValue(100); window.debounce.stop()
    window.select_variant(0); assert not requests
    window.select_variant(1)
    assert requests[-1]['action']=='render' and requests[-1]['variant']==1
    assert requests[-1]['saturation']==1.
    window.close()
