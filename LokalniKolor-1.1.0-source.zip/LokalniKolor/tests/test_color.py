import numpy as np
from kolor.color import rgb_to_lab, gamut_rgb, prepare_colors, render_colors, guided_filter

def fixture():
    rng=np.random.default_rng(42)
    gray=rng.uniform(0,1,(73,111,1)).astype(np.float32)
    return np.repeat(gray,3,-1),rng.uniform(0,1,(32,48,3)).astype(np.float32)

def test_lab_roundtrip():
    rng=np.random.default_rng(7); rgb=rng.uniform(0,1,(50,80,3))
    lab=rgb_to_lab(rgb); back,_=gamut_rgb(lab[...,0],lab[...,1:])
    assert np.max(np.abs(rgb-back)) < 1e-6

def test_gamut_retains_lightness_at_extremes():
    lightness=np.linspace(0,100,1024).reshape(32,32)
    ab=np.full((32,32,2),150.)
    result,count=gamut_rgb(lightness,ab,1.5)
    assert count > 500
    assert result.min() >= 0 and result.max() <= 1
    assert np.max(np.abs(rgb_to_lab(result)[...,0]-lightness)) < 1e-5

def test_no_generated_luminance_or_geometry():
    original,proposal=fixture(); before=original.copy()
    colors=prepare_colors(original,proposal,align=False)
    result,stats=render_colors(original,colors)
    assert result.shape == original.shape
    assert np.array_equal(original,before)
    assert np.max(np.abs(rgb_to_lab(original)[...,0]-rgb_to_lab(result)[...,0])) < 1e-5
    assert stats['max_L_error_float'] < 1e-5

def test_zero_saturation_is_neutral_original():
    original,proposal=fixture()
    result,_=render_colors(original,prepare_colors(original,proposal),0)
    assert np.max(np.abs(original-result)) < 1e-6

def test_guidance_preserves_color_edge():
    guide=np.zeros((60,100),np.float32); guide[:,50:]=1
    ab=np.zeros((60,100,2),np.float32); ab[:,50:,0]=60
    filtered=guided_filter(guide,ab,radius=8)
    assert abs(filtered[30,49,0]) < 1
    assert filtered[30,50,0] > 59

def test_cancellation():
    import pytest
    original,proposal=fixture()
    with pytest.raises(InterruptedError):
        render_colors(original,prepare_colors(original,proposal),cancel=lambda:True)
