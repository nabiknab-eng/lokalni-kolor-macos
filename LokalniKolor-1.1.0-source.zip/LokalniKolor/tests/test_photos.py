import hashlib
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import pytest
from PIL import Image
from kolor.photos import save_photo,load_photo
from kolor.color import rgb_to_lab

@pytest.mark.parametrize('extension,tolerance',[('.png',.002),('.tiff',.002),('.jpg',1.)])
def test_save_dimensions_profile_and_lightness(tmp_path,extension,tolerance):
    ramp=np.linspace(.02,.98,77*53).reshape(53,77,1)
    rgb=np.repeat(ramp,3,-1).astype(np.float32)
    source=tmp_path/'original.png'; Image.fromarray(np.uint8(rgb*255)).save(source)
    checksum=hashlib.sha256(source.read_bytes()).hexdigest()
    path=save_photo(rgb,source,tmp_path,extension)
    assert path.name == 'original_kolor'+extension
    reloaded=load_photo(path)
    assert reloaded.shape == rgb.shape
    assert np.max(abs(rgb_to_lab(reloaded)[...,0]-rgb_to_lab(rgb)[...,0])) < tolerance
    with Image.open(path) as im: assert im.info.get('icc_profile')
    assert hashlib.sha256(source.read_bytes()).hexdigest() == checksum

def test_never_overwrite_existing_or_source_even_in_race(tmp_path):
    source=tmp_path/'foto.png'; rgb=np.full((20,30,3),.5,np.float32)
    Image.fromarray(np.uint8(rgb*255)).save(source)
    content=source.read_bytes()
    # Explicitly attempt to export with an empty suffix into the source directory.
    first=save_photo(rgb,source,tmp_path,'.png',suffix='')
    assert first != source
    with ThreadPoolExecutor(max_workers=5) as pool:
        paths=list(pool.map(lambda _: save_photo(rgb,source,tmp_path),range(8)))
    assert len(set(paths))==8
    assert source.read_bytes()==content

def test_16bit_input_keeps_precision(tmp_path):
    import cv2
    values=np.arange(10000,10600,dtype=np.uint16).reshape(20,30)
    path=tmp_path/'scan.tiff'; cv2.imwrite(str(path),values)
    result=load_photo(path)
    assert len(np.unique(result[...,0]))==600

def test_exif_orientation(tmp_path):
    img=Image.new('RGB',(30,20),'gray'); exif=Image.Exif(); exif[274]=6
    path=tmp_path/'rotated.jpg'; img.save(path,exif=exif)
    assert load_photo(path).shape == (30,20,3)
