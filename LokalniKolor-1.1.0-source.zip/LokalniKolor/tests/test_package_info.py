from importlib import metadata
import json
import sys
from types import ModuleType, SimpleNamespace
import pytest
from kolor import package_info
from kolor import engine as engine_module


def missing_metadata(name):
    raise metadata.PackageNotFoundError(name)


def test_installed_version_has_priority(monkeypatch):
    monkeypatch.setattr(metadata,'version',lambda name:'1.2.3')
    assert package_info.package_version('mflux')==('1.2.3','installed_metadata')


def test_missing_metadata_uses_bundled_pin(monkeypatch,tmp_path):
    monkeypatch.setattr(metadata,'version',missing_metadata)
    monkeypatch.setattr(package_info,'ROOT',tmp_path)
    (tmp_path/'vendor').mkdir()
    (tmp_path/'vendor/MFLUX-REVISION.json').write_text(json.dumps({'package_version':'0.23.0'}))
    assert package_info.package_version('mflux')==('0.23.0','bundled_manifest')
    assert package_info.package_version('mlx')==(None,'unavailable')


def test_absent_or_broken_pin_is_nonfatal(monkeypatch,tmp_path):
    monkeypatch.setattr(metadata,'version',missing_metadata)
    monkeypatch.setattr(package_info,'ROOT',tmp_path)
    assert package_info.package_version('mflux')==(None,'unavailable')
    (tmp_path/'vendor').mkdir()
    (tmp_path/'vendor/MFLUX-REVISION.json').write_text('broken json')
    assert package_info.package_version('mflux')==(None,'unavailable')


@pytest.fixture
def fake_backend(monkeypatch,tmp_path):
    """Exercise initialization lifecycle without importing real MLX into Qt tests."""
    calls={'constructed':0,'evaluated':0,'fail_eval':False}
    class Model:
        def __init__(self,**kwargs):
            calls['constructed']+=1
            self.bits=4
            self.callbacks=SimpleNamespace(register=lambda callback:None)
        def parameters(self):return {}
    def evaluate(values):
        calls['evaluated']+=1
        if calls['fail_eval']:
            calls['fail_eval']=False
            raise RuntimeError('simulated GPU initialization failure')
    mx=ModuleType('mlx.core')
    mx.metal=SimpleNamespace(is_available=lambda:True)
    mx.gpu='gpu'
    mx.set_default_device=mx.set_cache_limit=mx.set_memory_limit=lambda *args:None
    mx.eval=evaluate
    mx.default_device=lambda:'test GPU'
    mx.device_info=lambda:{'device_name':'test GPU'}
    mlx=ModuleType('mlx'); mlx.core=mx
    config=ModuleType('mflux.models.common.config')
    config.ModelConfig=SimpleNamespace(flux2_klein_4b=lambda:object())
    variants=ModuleType('mflux.models.flux2.variants'); variants.Flux2KleinEdit=Model
    saver=ModuleType('mflux.callbacks.instances.memory_saver'); saver.MemorySaver=lambda **kwargs:object()
    for name,module in [('mlx',mlx),('mlx.core',mx),('mflux.models.common.config',config),
        ('mflux.models.flux2.variants',variants),('mflux.callbacks.instances.memory_saver',saver)]:
        monkeypatch.setitem(sys.modules,name,module)
    monkeypatch.setattr(engine_module,'MODEL_PATH',tmp_path)
    (tmp_path/'REVISION.json').write_text('{}')
    monkeypatch.setattr(metadata,'version',missing_metadata)
    return calls


def test_first_load_succeeds_without_distribution_metadata(fake_backend):
    events=[]; engine=engine_module.Engine(events.append)
    engine.load()
    assert engine.model is not None
    assert engine.load_stats['mflux_version_source']=='bundled_manifest'
    assert engine.load_stats['mlx_version_source']=='unavailable'
    assert len([e for e in events if e['type']=='loaded'])==1
    engine.load()
    assert fake_backend['constructed']==1


def test_failed_initialization_does_not_leave_ready_model(fake_backend):
    events=[]; engine=engine_module.Engine(events.append)
    fake_backend['fail_eval']=True
    with pytest.raises(RuntimeError,match='simulated GPU'):
        engine.load()
    assert engine.model is None and engine.load_stats=={}
    assert not any(e['type']=='loaded' for e in events)
    engine.load()
    assert engine.model is not None and fake_backend['constructed']==2
    assert len([e for e in events if e['type']=='loaded'])==1
