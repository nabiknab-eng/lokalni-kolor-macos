import numpy as np
from skimage import data
from skimage.color import deltaE_ciede2000
from kolor.color import rgb_to_lab,gamut_rgb,prepare_colors,render_colors
from kolor.photos import save_photo,load_photo


def test_high_resolution_and_known_color_transfer(tmp_path):
    import cv2
    color=data.astronaut().astype(np.float32)/255
    lab=rgb_to_lab(color)
    gray,_=gamut_rgb(lab[...,0],np.zeros_like(color[...,:2]))
    original=cv2.resize(gray,(1073,785),interpolation=cv2.INTER_LINEAR)
    proposal=cv2.resize(color,(320,320),interpolation=cv2.INTER_AREA)
    final,stats=render_colors(original,prepare_colors(original,proposal))
    assert final.shape==(785,1073,3)
    assert stats['max_L_error_float'] < 1e-5
    path=save_photo(final,tmp_path/'scan.png',tmp_path,'.png')
    saved=load_photo(path)
    assert np.max(abs(rgb_to_lab(saved)[...,0]-rgb_to_lab(original)[...,0])) < .0016
    # Oracle chroma tests transfer independently of the AI's color guesses.
    final_small,_=render_colors(gray,prepare_colors(gray,color))
    error=deltaE_ciede2000(lab,rgb_to_lab(final_small)).mean()
    baseline=deltaE_ciede2000(lab,rgb_to_lab(gray)).mean()
    assert error < baseline*.35


def test_invented_proposal_detail_never_becomes_luminance():
    original=np.full((80,120,3),.5,np.float32)
    proposal=np.zeros_like(original); proposal[20:60,40:80]=(1,.01,.1)
    final,_=render_colors(original,prepare_colors(original,proposal,align=False),1.5)
    assert np.max(abs(rgb_to_lab(final)[...,0]-rgb_to_lab(original)[...,0])) < 1e-5
