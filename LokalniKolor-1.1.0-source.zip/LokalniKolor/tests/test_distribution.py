import hashlib
import importlib.util
import json
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]


def script(name):
    spec=importlib.util.spec_from_file_location('kolor_test_'+name,ROOT/'scripts'/f'{name}.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def test_payload_checksum_detects_corruption(tmp_path):
    installer=script('install')
    wheel=tmp_path/'wheelhouse/a.whl';wheel.parent.mkdir();wheel.write_bytes(b'known content')
    manifest=tmp_path/'bundle-manifest.json'
    manifest.write_text(json.dumps({'files':{'wheelhouse/a.whl':hashlib.sha256(wheel.read_bytes()).hexdigest()}}))
    installer.verify_payload(tmp_path)
    wheel.write_bytes(b'corrupt content')
    with pytest.raises(RuntimeError,match='Poškozený'):installer.verify_payload(tmp_path)


def test_payload_rejects_parent_paths(tmp_path):
    (tmp_path/'bundle-manifest.json').write_text(json.dumps({'files':{'../escape':'fake'}}))
    with pytest.raises(ValueError,match='Neplatná'):script('install').verify_payload(tmp_path)


def test_offline_model_check_never_starts_curl(monkeypatch,tmp_path):
    downloader=script('download_model')
    monkeypatch.setattr(downloader.subprocess,'run',lambda *a,**k:pytest.fail('offline mode used network'))
    entry={'path':'transformer/test.safetensors','size':4,'lfs':{'oid':hashlib.sha256(b'test').hexdigest()}}
    with pytest.raises(RuntimeError,match='offline'):downloader.fetch(entry,tmp_path,True)
    target=tmp_path/entry['path'];target.parent.mkdir();target.write_bytes(b'test')
    downloader.fetch(entry,tmp_path,True)
    target.write_bytes(b'bad!')
    with pytest.raises(RuntimeError,match='offline'):downloader.fetch(entry,tmp_path,True)


def test_release_excludes_private_directories():
    builder=script('build_release')
    assert not set(builder.FOLDERS)&{'runtime','vysledky','overeni','.venv','.python','.git'}
    assert 'modely' in builder.FOLDERS


def test_pinned_python_is_arm64_and_checksummed():
    pin=json.loads((ROOT/'scripts/python-runtime.json').read_text())
    assert 'aarch64-apple-darwin' in pin['url']
    assert len(pin['sha256'])==64 and pin['url'].startswith('https://github.com/astral-sh/')
