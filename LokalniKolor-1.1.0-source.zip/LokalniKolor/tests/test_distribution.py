import hashlib
import importlib.util
import json
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]


def script(name):
    spec=importlib.util.spec_from_file_location('kolor_test_'+name,ROOT/'scripts'/f'{name}.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def test_payload_checksum_detects_corruption(tmp_path):
    installer=script('install')
    wheel=tmp_path/'wheelhouse/a.whl';wheel.parent.mkdir();wheel.write_bytes(b'known content')
    manifest=tmp_path/'bundle-manifest.json'
    manifest.write_text(json.dumps({'files':{'wheelhouse/a.whl':hashlib.sha256(wheel.read_bytes()).hexdigest()}}))
    installer.verify_payload(tmp_path)
    wheel.write_bytes(b'corrupt content')
    with pytest.raises(RuntimeError,match='Poškozený'):installer.verify_payload(tmp_path)


def test_payload_rejects_parent_paths(tmp_path):
    (tmp_path/'bundle-manifest.json').write_text(json.dumps({'files':{'../escape':'fake'}}))
    with pytest.raises(ValueError,match='Neplatná'):script('install').verify_payload(tmp_path)


def test_offline_model_check_never_starts_curl(monkeypatch,tmp_path):
    downloader=script('download_model')
    monkeypatch.setattr(downloader.subprocess,'run',lambda *a,**k:pytest.fail('offline mode used network'))
    entry={'path':'transformer/test.safetensors','size':4,'lfs':{'oid':hashlib.sha256(b'test').hexdigest()}}
    with pytest.raises(RuntimeError,match='offline'):downloader.fetch(entry,tmp_path,True)
    target=tmp_path/entry['path'];target.parent.mkdir();target.write_bytes(b'test')
    downloader.fetch(entry,tmp_path,True)
    target.write_bytes(b'bad!')
    with pytest.raises(RuntimeError,match='offline'):downloader.fetch(entry,tmp_path,True)


def test_release_excludes_private_directories():
    builder=script('build_release')
    assert not set(builder.FOLDERS)&{'runtime','vysledky','overeni','.venv','.python','.git'}
    assert 'modely' in builder.FOLDERS


def test_pinned_python_is_arm64_and_checksummed():
    pin=json.loads((ROOT/'scripts/python-runtime.json').read_text())
    assert 'aarch64-apple-darwin' in pin['url']
    assert len(pin['sha256'])==64 and pin['url'].startswith('https://github.com/astral-sh/')


def test_macos_hidden_plugin_repair_keeps_quarantine_and_external_files(tmp_path):
    import os,stat,subprocess
    if not hasattr(os,'chflags'):pytest.skip('macOS file flags required')
    root=tmp_path/'.venv';root.mkdir()
    plugin=root/'cocoa.dylib';plugin.write_bytes(b'plugin')
    external=tmp_path/'external';external.write_bytes(b'outside')
    (root/'link').symlink_to(external)
    for path in [root,plugin,external]:os.chflags(path,path.stat().st_flags|stat.UF_HIDDEN)
    try:
        subprocess.run(['xattr','-w','com.apple.quarantine','0081;test;test;',str(plugin)],check=True)
        script('install').normalize_file_visibility(root)
        assert not plugin.stat().st_flags & stat.UF_HIDDEN
        assert not root.stat().st_flags & stat.UF_HIDDEN
        assert external.stat().st_flags & stat.UF_HIDDEN
        assert subprocess.check_output(['xattr','-p','com.apple.quarantine',str(plugin)]).strip()==b'0081;test;test;'
    finally:
        for path in [root,plugin,external]:os.chflags(path,path.stat().st_flags & ~stat.UF_HIDDEN)
