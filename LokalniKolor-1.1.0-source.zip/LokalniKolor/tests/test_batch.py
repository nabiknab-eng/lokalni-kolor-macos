"""Batch dispatch and cancellation contract, using a fake engine only in unit tests."""
from pathlib import Path
import pytest
from kolor.batch import input_files,run_batch

class FakeEngine:
    def __init__(self): self.calls=[]
    def colorize(self,**kwargs):
        self.calls.append(kwargs)
        if Path(kwargs['source']).stem=='broken': raise ValueError('bad image')
        return {'source':str(kwargs['source'])}

def test_batch_snapshots_inputs_and_continues_on_bad_file(tmp_path):
    for name in ['a.JPG','b.tiff','broken.png','notes.txt','a_kolor.png','a_flux_seed42.png','a_nahled_v1.png']:
        (tmp_path/name).touch()
    engine=FakeEngine(); result=run_batch(engine,tmp_path,tmp_path/'out')
    assert len(result['completed'])==2 and len(result['errors'])==1
    assert len(engine.calls)==3
    assert len(input_files(tmp_path))==3

def test_batch_cancel_between_images(tmp_path):
    for name in ['a.png','b.png']: (tmp_path/name).touch()
    engine=FakeEngine()
    with pytest.raises(InterruptedError):
        run_batch(engine,tmp_path,tmp_path/'out',cancel=lambda:len(engine.calls)>0)
    assert len(engine.calls)==1
