#!/bin/zsh
set -euo pipefail
ROOT="${0:A:h}"
cd "$ROOT"
export PIP_CACHE_DIR="$ROOT/runtime/pip-cache"
export PYTHONPYCACHEPREFIX="$ROOT/runtime/pycache"
export HF_HOME="$ROOT/runtime/huggingface"
export PIP_DISABLE_PIP_VERSION_CHECK=1
mkdir -p runtime
trap 'print "Instalace se nepodařila. Podrobnosti zůstávají v tomto okně."; if [[ -t 0 ]]; then read "?Stiskněte Enter…"; fi' ZERR
if [[ "$(uname -s)" != Darwin || "$(uname -m)" != arm64 ]]; then
  print 'Tento instalátor je určen pro macOS na Apple Silicon (M5).'
  exit 1
fi
MAJOR="$(sw_vers -productVersion | cut -d. -f1)"
if (( MAJOR < 26 )); then
  print 'Tato sestava vyžaduje macOS 26 nebo novější.'
  exit 1
fi
if [[ ! -x .python/bin/python3 ]]; then
  ARCHIVE="$ROOT/vendor/python-runtime.tar.gz"
  if [[ ! -f "$ARCHIVE" ]]; then
    print 'Stahuji přibalený Python z oficiálního zdroje…'
    curl --fail --location --retry 3 --connect-timeout 30 \
      'https://github.com/astral-sh/python-build-standalone/releases/download/20261021/cpython-3.12.15%2B20261021-aarch64-apple-darwin-install_only_stripped.tar.gz' \
      --output "$ARCHIVE.part"
    mv "$ARCHIVE.part" "$ARCHIVE"
  fi
  print '7b8d00b751db21cea87dc551a8f8165147c5fbc5251d5537d7e5497dde00a219  vendor/python-runtime.tar.gz' | shasum -a 256 -c -
  TMP_RUNTIME="$(mktemp -d "$ROOT/runtime/python-install.XXXXXX")"
  tar -xzf "$ARCHIVE" -C "$TMP_RUNTIME"
  mv "$TMP_RUNTIME/python" "$ROOT/.python"
  rmdir "$TMP_RUNTIME"
fi
exec "$ROOT/.python/bin/python3" "$ROOT/scripts/install.py" "$@"
