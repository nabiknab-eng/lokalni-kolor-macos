"""Finder launcher; keep the full installation together when moving it."""
import os
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent

def repair():
    config=ROOT/'.venv'/'pyvenv.cfg'
    if not config.exists():return False
    home=ROOT/'.python'/'bin'
    value=f'home = {home}\ninclude-system-site-packages = false\nversion = {sys.version.split()[0]}\nexecutable = {home / "python3.12"}\n'
    if config.read_text()!=value:config.write_text(value)
    return True

if __name__=='__main__':
    if not repair():raise SystemExit('Nejprve spusťte Instalovat.command.')
    if '--repair-only' not in sys.argv:
        os.chdir(ROOT)
        env=os.environ.copy();env.pop('PYTHONHOME',None);env['PYTHONPATH']=str(ROOT)
        exe=ROOT/'.venv/bin/python'
        os.execve(exe,[str(exe),'-m','kolor.gui',*sys.argv[1:]],env)
